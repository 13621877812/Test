//
//  MASTimeTableViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASTimeTableViewController.h"
#import "MASSlideView.h"
#import "MASNewsViewController.h"
#import <NSString+MJHHelper.h>
#import "MASDBHandle.h"
#import <MJHCategoriesHeader.h>
#import "AppDelegate.h"
#import "MJHAFNetworking.h"
#import "EKEventTool.h"
@interface MASTimeTableViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property (nonatomic, strong) UIBarButtonItem *sideItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;
@property (nonatomic, strong) UIBarButtonItem *rightItem;

@property (nonatomic, weak) IBOutlet UIButton *selectButton;
@property (nonatomic, weak) IBOutlet UIButton *calendarAddButton;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (nonatomic, weak) IBOutlet UIImageView *bgImageView;
@property (nonatomic, weak) IBOutlet UIButton *changeButton;
@property (nonatomic, weak) IBOutlet UIButton *calendarButton;
@property (nonatomic, weak) IBOutlet UIImageView *changeImageView;
@property (nonatomic, weak) IBOutlet UIImageView *canlendarImageView;
@property (strong, nonatomic) IBOutlet UIImageView *timetable_background;

@property(nonatomic,strong) UIImagePickerController *imagePicker; //声明全局的UIImagePickerController

@end

@implementation MASTimeTableViewController

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = NO;
    self.navigationItem.leftBarButtonItems = @[self.sideItem,self.titleItem];
    self.navigationItem.rightBarButtonItem = self.rightItem;
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    
    return self.bgImageView;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView {
    
    CGRect frame = self.bgImageView.frame;
    
    frame.origin.y = (self.scrollView.frame.size.height - self.bgImageView.frame.size.height) > 0 ? (self.scrollView.frame.size.height - self.bgImageView.frame.size.height) * 0.5 : 0;
    frame.origin.x = (self.scrollView.frame.size.width - self.bgImageView.frame.size.width) > 0 ? (self.scrollView.frame.size.width - self.bgImageView.frame.size.width) * 0.5 : 0;
    self.bgImageView.frame = frame;
    
    self.scrollView.contentSize = CGSizeMake(self.bgImageView.frame.size.width + 30, self.bgImageView.frame.size.height + 30);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.scrollView.minimumZoomScale = 1;
    self.scrollView.maximumZoomScale = 10;
    
    self.scrollView.delegate = self;
    
    //关键语句
    self.selectButton.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    self.selectButton.layer.borderColor = [UIColor colorWithRed:133/255.0 green:253/255.0 blue:15/255.0 alpha:1].CGColor;//设置边框颜色
    self.selectButton.layer.borderWidth = 3.0f;//设置边框颜色
    
    self.calendarAddButton.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    self.calendarAddButton.layer.borderColor = [UIColor colorWithRed:133/255.0 green:253/255.0 blue:15/255.0 alpha:1].CGColor;//设置边框颜色
    self.calendarAddButton.layer.borderWidth = 3.0f;//设置边框颜色
    
    //从数据库查询图片
    NSString *timeTable = [[MASDBHandle shareMASDBHandle] searchTimeTable:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    //如果路径存在，则加载图片。
    NSString *imagePath = [NSString creatPathInDocuments:timeTable];
    if(timeTable) {
        [self setImage:[UIImage imageWithContentsOfFile:imagePath]];
    }
}

- (void)sideAction {
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    [[MASSlideView shareYDSlideView] initSlideViewForView:self setString:adminNo eamilString:[NSString stringWithFormat:@"%@myemail.nyp.edu.sg@", adminNo]];
}

- (void)rightAction {
    //显示消息页面
    MASNewsViewController *controller = [[MASNewsViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}

- (UIBarButtonItem *)sideItem
{
    if (!_sideItem) {
        _sideItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_side"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(sideAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        btn.frame = CGRectMake(0, 0, 30, 30);
        _sideItem.customView = btn;
    }
    return _sideItem;
}

- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @"    Timetable";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:25]];
        label.frame = CGRectMake(50, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}
//设置右侧button
- (UIBarButtonItem *)rightItem
{
    if (!_rightItem) {
        _rightItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_alarm_icon"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(rightAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.frame = CGRectMake(0, 0, 30, 30);
        _rightItem.customView = btn;
    }
    return _rightItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)canlendarInsertClick:(id)sender {
    [self insertCalendar];
}
- (IBAction)addPhont:(id)sender {
    //初始化UIImagePickerController类
    UIImagePickerController * picker = [[UIImagePickerController alloc] init];
    //判断数据来源为相册
    picker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    //设置代理
    picker.delegate = self;
    //打开相册
    [self presentViewController:picker animated:YES completion:nil];
}
- (IBAction)calendarAdd:(id)sender {
    
    
    [self insertCalendar];
}
-(void)insertCalendar
{
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"Hint" message:@"Are you sure to insert？" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"Confirm" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self loadData];
    }];
    [alertVC addAction:cancelAction];
    [alertVC addAction:confirmAction];
    [self presentViewController:alertVC animated:YES completion:nil];
}

-(void)loadData
{
  
    //请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/allModules.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"AdminNo"];
    

    
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if ([responseObject[@"status"] isEqualToString:@"OK"]) {
          //删除日历
              [[EKEventTool sharedEventTool] deleteAllCreatedEvent];
         
            //处理数据
            NSMutableArray *eventArray=[NSMutableArray array];
            for (int i=0; i<7; i++) {
                NSMutableArray *array = [NSMutableArray array];
                [eventArray addObject:array];
            }
            
            [[responseObject allValues] enumerateObjectsUsingBlock:^(NSDictionary *dic, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([dic isKindOfClass:[NSDictionary class]]) {
                    NSInteger week =[dic[@"Date"] integerValue];
                    [eventArray[week] addObject:dic];
                }
            }];
            
            
            //构建事件
            for (int i=0; i<90; i++) {
                NSDate *date =[NSDate date];
                date = [date dateByAddingTimeInterval:24*60*60*i];
                NSLog(@"%@",date);
                NSDateFormatter *mFormatter = [[NSDateFormatter alloc] init];
                [mFormatter setDateFormat:@"yyyy/MM/dd"];
                NSString *dateStr = [mFormatter stringFromDate:date];
                
                NSArray *events =eventArray[[self getWeek:date]];
                
                [events enumerateObjectsUsingBlock:^(NSDictionary * event, NSUInteger idx, BOOL * _Nonnull stop) {
                    
                    
                    NSString *startTime = [NSString stringWithFormat:@"%@ %@",dateStr,event[@"BeginTime"]];
                    NSString *endTime = [NSString stringWithFormat:@"%@ %@",dateStr,event[@"EndTime"]];
                    NSString *title = [NSString stringWithFormat:@"%@ %@ %@",event[@"ModuleCode"],event[@"ModuleName"],event[@"TeacherName"]];
                    [self eventInsertCalendar:title beginTime:startTime endTime:endTime];
                }];
                
            }
            
            
        }
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internent Error"];
    }];
}

-(NSInteger)getWeek:(NSDate *)fromDate
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    
    NSInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |
    
    NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    
    comps = [calendar components:unitFlags fromDate:fromDate];
    
    
    return comps.weekday-1;
    
}
-(void)eventInsertCalendar:(NSString *)title beginTime:(NSString *)beginTime endTime:(NSString *)endTime
{
    
    EKEventModel *model = [[EKEventModel alloc]init];
    model.title = title;
    model.startDateStr = beginTime;
    model.endDateStr = endTime;
    model.allDay = NO;
    model.alarmStr=@"10分钟前";
    [[EKEventTool sharedEventTool]createEventWithEventModel:model];

}
//选择完成回调函数
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    //获取图片
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    [self dismissViewControllerAnimated:YES completion:nil];
    //使用数据缓冲区接收图片名字
    NSData *imgData=UIImageJPEGRepresentation(image, 1);
    NSString *imgNameStr=[NSString stringWithFormat:@"%.0f.jpg",[[NSDate date] timeIntervalSince1970]];
    NSString *imagePath = [NSString creatPathInDocuments:imgNameStr];
    [imgData writeToFile:imagePath atomically:YES];
    
    if([[MASDBHandle shareMASDBHandle] insertTimeTable:imgNameStr]){
        NSLog(@"TimeTable insert success");
    }else{
        NSLog(@"TimeTable insert fail");
    }
    [self setImage:image];
}

- (void)setImage:(UIImage *)image {
    self.bgImageView.image = image;
    self.timetable_background.hidden = YES;
    self.selectButton.hidden = YES;
    self.selectButton.enabled = NO;
    self.calendarAddButton.hidden = YES;
    self.calendarAddButton.enabled = NO;
    self.changeButton.hidden = NO;
    self.calendarButton.hidden = NO;
    self.changeImageView.hidden = NO;
    self.canlendarImageView.hidden = NO;
}

@end
