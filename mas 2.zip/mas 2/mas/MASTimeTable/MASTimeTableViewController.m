//
//  MASTimeTableViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASTimeTableViewController.h"
#import "MASSlideView.h"
#import "MASNewsViewController.h"
#import <NSString+MJHHelper.h>
#import "MASDBHandle.h"
#import <MJHCategoriesHeader.h>
#import "AppDelegate.h"
#import "MJHAFNetworking.h"
#import <EventKit/EventKit.h>
@interface MASTimeTableViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property (nonatomic, strong) UIBarButtonItem *sideItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;
@property (nonatomic, strong) UIBarButtonItem *rightItem;

@property (nonatomic, weak) IBOutlet UIButton *selectButton;
@property (nonatomic, weak) IBOutlet UIButton *calendarAddButton;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (nonatomic, weak) IBOutlet UIImageView *bgImageView;
@property (nonatomic, weak) IBOutlet UIButton *changeButton;
@property (nonatomic, weak) IBOutlet UIButton *calendarButton;
@property (nonatomic, weak) IBOutlet UIImageView *changeImageView;
@property (nonatomic, weak) IBOutlet UIImageView *canlendarImageView;
@property (strong, nonatomic) IBOutlet UIImageView *timetable_background;

@property(nonatomic,strong) UIImagePickerController *imagePicker; //声明全局的UIImagePickerController

@end

@implementation MASTimeTableViewController

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = NO;
    self.navigationItem.leftBarButtonItems = @[self.sideItem,self.titleItem];
    self.navigationItem.rightBarButtonItem = self.rightItem;
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    
    return self.bgImageView;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView {
    
    CGRect frame = self.bgImageView.frame;
    
    frame.origin.y = (self.scrollView.frame.size.height - self.bgImageView.frame.size.height) > 0 ? (self.scrollView.frame.size.height - self.bgImageView.frame.size.height) * 0.5 : 0;
    frame.origin.x = (self.scrollView.frame.size.width - self.bgImageView.frame.size.width) > 0 ? (self.scrollView.frame.size.width - self.bgImageView.frame.size.width) * 0.5 : 0;
    self.bgImageView.frame = frame;
    
    self.scrollView.contentSize = CGSizeMake(self.bgImageView.frame.size.width + 30, self.bgImageView.frame.size.height + 30);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.scrollView.minimumZoomScale = 1;
    self.scrollView.maximumZoomScale = 10;
    
    self.scrollView.delegate = self;
    
    //关键语句
    self.selectButton.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    self.selectButton.layer.borderColor = [UIColor colorWithRed:133/255.0 green:253/255.0 blue:15/255.0 alpha:1].CGColor;//设置边框颜色
    self.selectButton.layer.borderWidth = 3.0f;//设置边框颜色
    
    self.calendarAddButton.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    self.calendarAddButton.layer.borderColor = [UIColor colorWithRed:133/255.0 green:253/255.0 blue:15/255.0 alpha:1].CGColor;//设置边框颜色
    self.calendarAddButton.layer.borderWidth = 3.0f;//设置边框颜色
    
    //从数据库查询图片
    NSString *timeTable = [[MASDBHandle shareMASDBHandle] searchTimeTable:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    //如果路径存在，则加载图片。
    NSString *imagePath = [NSString creatPathInDocuments:timeTable];
    if(timeTable) {
        [self setImage:[UIImage imageWithContentsOfFile:imagePath]];
    }
}

- (void)sideAction {
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    [[MASSlideView shareYDSlideView] initSlideViewForView:self setString:adminNo eamilString:[NSString stringWithFormat:@"%@myemail.nyp.edu.sg@", adminNo]];
}

- (void)rightAction {
    //显示消息页面
    MASNewsViewController *controller = [[MASNewsViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}

- (UIBarButtonItem *)sideItem
{
    if (!_sideItem) {
        _sideItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_side"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(sideAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        btn.frame = CGRectMake(0, 0, 30, 30);
        _sideItem.customView = btn;
    }
    return _sideItem;
}

- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @"    Timetable";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:25]];
        label.frame = CGRectMake(50, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}
//设置右侧button
- (UIBarButtonItem *)rightItem
{
    if (!_rightItem) {
        _rightItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_alarm_icon"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(rightAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.frame = CGRectMake(0, 0, 30, 30);
        _rightItem.customView = btn;
    }
    return _rightItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)canlendarInsertClick:(id)sender {
    [self insertCalendar];
}
- (IBAction)addPhont:(id)sender {
    //初始化UIImagePickerController类
    UIImagePickerController * picker = [[UIImagePickerController alloc] init];
    //判断数据来源为相册
    picker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    //设置代理
    picker.delegate = self;
    //打开相册
    [self presentViewController:picker animated:YES completion:nil];
}
- (IBAction)calendarAdd:(id)sender {
    
    
    [self insertCalendar];
}
-(void)insertCalendar
{
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"Hint" message:@"Are you sure to insert？" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"Confirm" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self loadData];
    }];
    [alertVC addAction:cancelAction];
    [alertVC addAction:confirmAction];
    [self presentViewController:alertVC animated:YES completion:nil];
}

-(void)loadData
{
    G
    //请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/allModules.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"AdminNo"];
    
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if ([responseObject[@"status"] isEqualToString:@"OK"]) {
            //往日历插数据
            
            NSMutableArray *eventArray=[NSMutableArray array];
            for (int i=0; i<7; i++) {
                NSMutableArray *array = [NSMutableArray array];
                [eventArray addObject:array];
            }
            
            [[responseObject allObjects] enumerateObjectsUsingBlock:^(NSDictionary *dic, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([dic isKindOfClass:[NSDictionary class]]) {
                    NSInteger week =[dic[@"Date"] integerValue];
                    [eventArray[week] addObject:dic];
                }
            }];
            
            NSDate *date =[NSDate date];
            for (int i=0; i<90; i++) {
                date = [date dateByAddingTimeInterval:24*60*60*i];
                NSDateFormatter *mFormatter = [[NSDateFormatter alloc] init];
                [mFormatter setDateFormat:@"yyyy/MM/dd"];
                NSString *dateStr = [mFormatter stringFromDate:date];
                
                NSArray *events =eventArray[[self getWeek:date]];
                
                [events enumerateObjectsUsingBlock:^(NSDictionary * event, NSUInteger idx, BOOL * _Nonnull stop) {
                    
                    NSString *startTime = [NSString stringWithFormat:@"%@ %@",dateStr,event[@"beginTime"]];
                    NSString *endTime = [NSString stringWithFormat:@"%@ %@",dateStr,event[@"endTime"]];
                    NSString *title = [NSString stringWithFormat:@"%@ %@ %@",event[@"moduleCode"],event[@"moduleName"],event[@"teacherName"]];
                    
                    
                    
                    [self eventInsertCalendar:title beginTime:startTime endTime:endTime];
                }];
                
            }
            
            
            
            
            
            
            
            
        }
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internent Error"];
    }];
}
-(NSInteger)getWeek:(NSDate *)fromDate
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    
    NSInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |
    
    NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    
    comps = [calendar components:unitFlags fromDate:fromDate];
    
    
    return comps.weekday-1;
    
}
-(void)eventInsertCalendar:(NSString *)title beginTime:(NSString *)beginTime endTime:(NSString *)endTime
{
    
    __block NSString  *startTime = beginTime;
    __block NSString *eventEndTime = endTime;
    EKEventStore *eventStore = [[EKEventStore alloc] init];
    if ([eventStore respondsToSelector:@selector(requestAccessToEntityType:completion:)]) {
        // 这个方法在iOS6之后才有用
        [eventStore requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (error) {
                    NSLog(@"%@",error);
                } else if (!granted) {
                    //被用户拒绝，不允许访问日历
                    NSLog(@"被用户拒绝，不允许访问日历");
                } else {
                    //事件保存到日历
                    EKEvent *event = [EKEvent eventWithEventStore:eventStore]; //创建事件
                    event.title = title; // 标题
                    
                    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                    [dateFormatter setDateFormat:@"yyyy/MM/dd HH:mm:ss"];
                    
                    
                    
                    NSDate *start =[dateFormatter dateFromString:startTime];
                    NSDate *end =[dateFormatter dateFromString:eventEndTime];
                    
                    
                    //开始时间(必须传)
                    event.startDate = start;
                    //结束时间(必须传)
                    event.endDate = end;
                    event.allDay = YES;//全天
                    
                    //添加提醒
                    //第一次提醒  (几分钟后)
                    [event addAlarm:[EKAlarm alarmWithRelativeOffset:60.0 * -1.0]];
                    //第二次提醒
                    [event addAlarm:[EKAlarm alarmWithRelativeOffset:60.0f * -10.0f * 24]];
                    
                    [event setCalendar:[eventStore defaultCalendarForNewEvents]];
                    NSError *err;
                    [eventStore saveEvent:event span:EKSpanThisEvent error:&err];
                    NSLog(@"保存成功");
                }
            });
        }];
    }
    
}
//选择完成回调函数
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    //获取图片
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    [self dismissViewControllerAnimated:YES completion:nil];
    //使用数据缓冲区接收图片名字
    NSData *imgData=UIImageJPEGRepresentation(image, 1);
    NSString *imgNameStr=[NSString stringWithFormat:@"%.0f.jpg",[[NSDate date] timeIntervalSince1970]];
    NSString *imagePath = [NSString creatPathInDocuments:imgNameStr];
    [imgData writeToFile:imagePath atomically:YES];
    
    if([[MASDBHandle shareMASDBHandle] insertTimeTable:imgNameStr]){
        NSLog(@"TimeTable insert success");
    }else{
        NSLog(@"TimeTable insert fail");
    }
    [self setImage:image];
}

- (void)setImage:(UIImage *)image {
    self.bgImageView.image = image;
    self.timetable_background.hidden = YES;
    self.selectButton.hidden = YES;
    self.selectButton.enabled = NO;
    self.calendarAddButton.hidden = YES;
    self.calendarAddButton.enabled = NO;
    self.changeButton.hidden = NO;
    self.calendarButton.hidden = NO;
    self.changeImageView.hidden = NO;
    self.canlendarImageView.hidden = NO;
}

@end
