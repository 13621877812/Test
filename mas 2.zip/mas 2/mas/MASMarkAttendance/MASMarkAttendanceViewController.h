//
//  MASMarkAttendanceViewController.h
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASMarkAttendanceViewController : UIViewController

@property (nonatomic, assign) BOOL isShow;

@end
