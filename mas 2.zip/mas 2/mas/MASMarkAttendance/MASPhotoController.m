//
//  MASPhotoController.m
//  mas
//
//  Created by fpm0259 on 2018/7/31.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASPhotoController.h"
#import "PhotoHelper.h"
#import "BluetoothHelper.h"
#import "AppDelegate.h"
#import <MJHCategoriesHeader.h>
#import <UIView+Toast.h>
@interface MASPhotoController ()
@property(nonatomic,strong)NSData *imageData;
@property(nonatomic,copy)NSString *imageName;
@property (weak, nonatomic) IBOutlet UIButton *captureBtn;
@property (weak, nonatomic) IBOutlet UIButton *sendBtn;
@property (weak, nonatomic) IBOutlet UIButton *refreshBtn;
@property (weak, nonatomic) IBOutlet UIImageView *captureImageV;
@property (nonatomic, strong) UIBarButtonItem *sideItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;
@end

@implementation MASPhotoController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
    [[BluetoothHelper helper]scanForPeripherals:nil];
    //取消隐藏导航栏
    self.navigationController.navigationBar.hidden = NO;
    //加载左侧的按钮和title
    self.navigationItem.leftBarButtonItems = @[self.sideItem,self.titleItem];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initUI
{
    self.captureImageV.hidden = YES;
    self.captureBtn.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    self.captureBtn.layer.borderColor = [UIColor colorWithRed:251/255.0 green:0/255.0 blue:6/255.0 alpha:1].CGColor;//设置边框颜色
    self.captureBtn.layer.borderWidth = 2.0f;//设置边框颜色
    
    self.sendBtn.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    self.sendBtn.layer.borderColor = [UIColor colorWithRed:34/255.0 green:255/255.0 blue:4/255.0 alpha:1].CGColor;//设置边框颜色
    self.sendBtn.layer.borderWidth = 2.0f;//设置边框颜色
    
    self.refreshBtn.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    self.refreshBtn.layer.borderColor = [UIColor colorWithRed:14/255.0 green:108/255.0 blue:164/255.0 alpha:1].CGColor;//设置边框颜色
    self.refreshBtn.layer.borderWidth = 2.0f;//设置边框颜色
}

- (IBAction)captureBtnClick:(id)sender {
    //照片
    [[PhotoHelper helper]choosePhotosWithViewController:self imageBlock:^(NSData *imageData,NSString *name) {
        self.captureImageV.hidden = NO;
        self.captureImageV.image = [UIImage imageWithData:imageData];
        self.imageData = imageData;
        self.imageName = name;
    }];
}

- (IBAction)Send:(id)sender {
    //向后台发送数据
    [SVProgressHUD showWithStatus:@"Uploading..."];
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/upload.php",SERVER_URL_IP];
    NSString *device = [[BluetoothHelper helper] devices];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"adminNo"];
    
    [muParameterDic setObject:device forKey:@"device"];
    
    [[MJHAFNetworking shareMJHAFNetworking] MJHUploadFile:[urlString stringToUTF8String] parameter:muParameterDic timeOutInterval:30 uploadBody:^(id<AFMultipartFormData> formData) {
        if (self.imageData && self.imageName) {
            [formData appendPartWithFileData:self.imageData name:@"image" fileName:self.imageName mimeType:@"png"];
        }
        
    } uploadProgress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSString *response = [[NSString alloc]initWithData:(NSData *)responseObject encoding:NSUTF8StringEncoding];
        
        NSString *message = @"";
        if ([response isEqualToString:@"errora"]) {
            message = @"Not in Attendance Time";
        }else if([response isEqualToString:@"errorb"]||[response isEqualToString:@"errorc"]||[response isEqualToString:@"errord"]||[response isEqualToString:@"errore"]){
            message = @"Uploaded Failed";
        }else if([response isEqualToString:@"error1"]){
            message = @"No face";
        }else if([response isEqualToString:@"error2"]){
            message = @"Not living body";
        }else if([response isEqualToString:@"error3"]){
            message = @"Not the same person";
        }else if([response isEqualToString:@"error4"]){
            message = @"Requested failed";
        }else if([response isEqualToString:@"error5"]){
            message = @"Google sheet error";
        }else if([response isEqualToString:@"succeeded"]){
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showSuccessAndDismiss:@"succeeded"];
            return;
        }else
        {
            message = @"Uncertain error";
        }
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",message]];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internet Error"];
    }];
    
    
    
}

- (IBAction)Refresh:(id)sender {
    //刷新
    [[BluetoothHelper helper]scanForPeripherals:nil];
    [self.view makeToast:@"Refreshing..."];
}

//左侧返回按钮
- (UIBarButtonItem *)sideItem
{
    if (!_sideItem) {
        _sideItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_action_back"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(sideAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        btn.frame = CGRectMake(0, 0, 30, 30);
        _sideItem.customView = btn;
    }
    return _sideItem;
}

//左侧title按钮
- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @"    Take Photo";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:22]];
        label.frame = CGRectMake(50, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}

//返回方法
- (void)sideAction {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
