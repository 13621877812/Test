//
//  MASTeacherMarkAttendanceViewController.h
//  mas
//
//  Created by cocoa on 2018/7/31.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASTeacherMarkAttendanceViewController : UIViewController
@property (nonatomic, assign) BOOL isShow;

@end
