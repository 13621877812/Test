//
//  MASMarkAttendanceViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASMarkAttendanceViewController.h"
#import "MASSlideView.h"
#import "MASMarkAttendanceCell.h"
#import "MASNewsViewController.h"
#import <MJHCategoriesHeader.h>
#import "AppDelegate.h"
#import "MASDBHandle.h"
#import <UIView+Toast.h>
#import "MASPhotoController.h"
#import "BluetoothHelper.h"
@interface MASMarkAttendanceViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UIBarButtonItem *sideItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;
@property (nonatomic, strong) UIBarButtonItem *rightItem;

@property (nonatomic, weak) IBOutlet UIButton *centerButton;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, weak) IBOutlet UITableView *tableView;

@property (nonatomic, weak) IBOutlet UIImageView *backgroundImageView;
@property(nonatomic, strong) BluetoothHelper *helper;
@end

@implementation MASMarkAttendanceViewController

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = NO;
    self.navigationItem.leftBarButtonItems = @[self.sideItem,self.titleItem];
    self.navigationItem.rightBarButtonItem = self.rightItem;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (self.isShow) {
        [self showToast];
    }
    [self.centerButton addObserver:self forKeyPath:@"state" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.helper.centralManager stopScan];
    self.helper.centralManager = nil;
}

- (void)goBackAction {
    
}

- (IBAction)cancel:(UIButton *)sender {
    NSLog(@"%lu",(unsigned long)sender.state);
    self.backgroundImageView.hidden = YES;
}

- (IBAction)down:(UIButton *)sender {
    NSLog(@"%lu",(unsigned long)sender.state);
    self.backgroundImageView.hidden = NO;
    
}

- (IBAction)change:(UIButton *)sender {
    NSLog(@"%lu",(unsigned long)sender.state);
    self.backgroundImageView.hidden = YES;
    
    //向后台发送数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/currentModule.php",SERVER_URL_IP];
    
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"AdminNo"];
    
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:urlString parameter:muParameterDic timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        NSString *response = [[NSString alloc]initWithData:(NSData *)responseObject encoding:NSUTF8StringEncoding];
        
        NSArray *results = [response componentsSeparatedByString:@"<br>"];
        
        if([results containsObject:@"Available"]){
            
            //检测蓝牙状态
            self.helper = [BluetoothHelper helper];
            [self.helper scanForPeripherals:^(BOOL isAvailable) {
                if (isAvailable) {
                    //可用
                    MASPhotoController *photoVC = [[MASPhotoController alloc]init];
                    [self.navigationController pushViewController:photoVC animated:YES];
                } else {
                    //不可用
                    [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
                    [SVProgressHUD showInfoWithStatus:@"Please turn on bluetooth"];
                }
            }];
        }
        else {
            // [self.view makeToast:@"No available module"];
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showInfoWithStatus:@"No available module"];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internet Error"];
    }];
}

// 登录后greeting
- (void)showToast {
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    NSString *name = [[MASDBHandle shareMASDBHandle] searchName:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    if (name) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showSuccessAndDismiss:[NSString stringWithFormat:@"welcome, %@", name]];
    }
    else {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showSuccessAndDismiss:[NSString stringWithFormat:@"welcome, %@", adminNo]];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataArray = [NSMutableArray array];
    [self setImageData];
    [self loadData];
}

// 判读数据库是否有数据
- (void)setImageData {
    NSString *name = [[MASDBHandle shareMASDBHandle] searchName:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    NSString *scg = [[MASDBHandle shareMASDBHandle] searchSCG:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    NSString *timeTable = [[MASDBHandle shareMASDBHandle] searchMyprofile:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    if (!name && !scg && !timeTable) {
        [self loadSutdentInfo];
    }
}

- (void)loadSutdentInfo {
    //从接口请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/studentInfo.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"AdminNo"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if ([[responseObject objectForKey:@"status"] isEqualToString:@"OK"]) {
            NSDictionary *dic = [responseObject objectForKey:@"0"];
            if (dic) {
                NSString *image = [dic objectForKey:@"Image"];
                if (image) {
                    NSString *str = [[image componentsSeparatedByString:@","] objectAtIndex:1];
                    // 将base64字符串转为NSData
                    NSData *decodeData = [[NSData alloc]initWithBase64EncodedString:str options:(NSDataBase64DecodingIgnoreUnknownCharacters)];
                    
                    //使用数据缓冲区接收图片名字
                    NSData *imgData=UIImageJPEGRepresentation([UIImage imageWithData: decodeData], 1);
                    NSString *imgNameStr=[NSString stringWithFormat:@"%.0f.jpg",[[NSDate date] timeIntervalSince1970]];
                    NSString *imagePath = [NSString creatPathInDocuments:imgNameStr];
                    [imgData writeToFile:imagePath atomically:YES];
                    [[MASDBHandle shareMASDBHandle] insertMyprofile:imgNameStr];
                    
                }
                [[MASDBHandle shareMASDBHandle] insertSCG:[NSString stringWithFormat:@"%@",[dic objectForKey:@"SCG"]]];
                [[MASDBHandle shareMASDBHandle] insertName:[NSString stringWithFormat:@"%@",[dic objectForKey:@"Name"]]];
            }
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internet Error"];
    }];
}

- (void)loadData {
    //请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/currentModule.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"AdminNo"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if (responseObject) {
            if([responseObject isKindOfClass:[NSData class]]) {
                responseObject = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            }
            //解析数据
            NSString *dataString = responseObject;
            if (![dataString hasPrefix:@"error"]) {
                NSArray *tempArray = [dataString componentsSeparatedByString:@"<br>"];
                
                [self.dataArray addObject:[[tempArray objectAtIndex:0]componentsSeparatedByString:@","]];
                [self.dataArray addObject:[[tempArray objectAtIndex:1]componentsSeparatedByString:@","]];
                [self.dataArray addObject:[[tempArray objectAtIndex:2]componentsSeparatedByString:@","]];
                [self.dataArray addObject:[[tempArray objectAtIndex:3]componentsSeparatedByString:@","]];
                [self.dataArray addObject:[[tempArray objectAtIndex:4]componentsSeparatedByString:@","]];
                
                NSArray *statusArray = self.dataArray[4];
                for(int i=0; i<[statusArray count]; i++) {
                    if([[statusArray objectAtIndex:i] isEqualToString:@"Available"] && [statusArray count] > 1) {
                        [self.dataArray[0] insertObject:[self.dataArray[0] objectAtIndex:i] atIndex:0];
                        [self.dataArray[0] removeObjectAtIndex:i+1];
                        [self.dataArray[1] insertObject:[self.dataArray[1] objectAtIndex:i] atIndex:0];
                        [self.dataArray[1] removeObjectAtIndex:i+1];
                        [self.dataArray[2] insertObject:[self.dataArray[2] objectAtIndex:i] atIndex:0];
                        [self.dataArray[2] removeObjectAtIndex:i+1];
                        [self.dataArray[3] insertObject:[self.dataArray[3] objectAtIndex:i] atIndex:0];
                        [self.dataArray[3] removeObjectAtIndex:i+1];
                        [self.dataArray[4] insertObject:[self.dataArray[4] objectAtIndex:i] atIndex:0];
                        [self.dataArray[4] removeObjectAtIndex:i+1];
                    }
                }
                [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
            }
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internet Error"];
    }];
}

- (void)sideAction {
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    [[MASSlideView shareYDSlideView] initSlideViewForView:self setString:adminNo eamilString:[NSString stringWithFormat:@"%@myemail.nyp.edu.sg@", adminNo]];
}

- (void)rightAction {
    MASNewsViewController *controller = [[MASNewsViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}

- (UIBarButtonItem *)sideItem
{
    if (!_sideItem) {
        _sideItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_side"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(sideAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        btn.frame = CGRectMake(0, 0, 30, 30);
        _sideItem.customView = btn;
    }
    return _sideItem;
}

- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @"    MAS";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:22]];
        label.frame = CGRectMake(50, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}

- (UIBarButtonItem *)rightItem
{
    if (!_rightItem) {
        _rightItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_alarm_icon"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(rightAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.frame = CGRectMake(0, 0, 30, 30);
        _rightItem.customView = btn;
    }
    return _rightItem;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.dataArray.count) {
        return ((NSArray *)[self.dataArray objectAtIndex:0]).count;
    }else{
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MASMarkAttendanceCell *cell = [tableView dequeueReusableCellWithIdentifier:@"markCell"];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"MASMarkAttendanceCell" owner:self options:nil] objectAtIndex:0];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [cell setData:self.dataArray index:indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 150;
}

@end
