//
//  MASPhotoController.h
//  mas
//
//  Created by fpm0259 on 2018/7/31.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASPhotoController : UIViewController

@end
