//
//  MASTeacherMarkAttendanceViewController.m
//  mas
//
//  Created by cocoa on 2018/7/31.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASTeacherMarkAttendanceViewController.h"
#import "NSString+MD5.h"
#import "MASSlideView.h"
#import "MASTeacherMarkAttendanceCell.h"
#import "MASNewsViewController.h"
#import <MJHCategoriesHeader.h>
#import "AppDelegate.h"
#import "MASDBHandle.h"
#import <UIView+Toast.h>
#import "MASLoginViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import <SystemConfiguration/CaptiveNetwork.h>


#define SERVICE_UUID @"CDD1"
#define CHARACTERISTIC_UUID @"CDD2"
#define IS_IPHONE_X (Screen_Height == 812.0f) ? YES : NO
@interface MASTeacherMarkAttendanceViewController ()<UITableViewDelegate,UITableViewDataSource,CBPeripheralManagerDelegate>
@property (nonatomic, strong) UIBarButtonItem *sideItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;
@property (nonatomic, strong) UIBarButtonItem *rightItem;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *dataStateArray;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, weak) IBOutlet UIView *buttonView;
@property (nonatomic, strong)  UIButton *logOutButton;

// hash value
@property (nonatomic, copy) NSString *mac;
// real value
@property (nonatomic, copy) NSString *realMac;

@property (nonatomic, strong) CBPeripheralManager *peripheralManager;
@property (nonatomic, strong) CBMutableCharacteristic *characteristic;

@property (nonatomic, assign) BOOL isOpen;

@end

@implementation MASTeacherMarkAttendanceViewController

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = NO;
    self.navigationItem.leftBarButtonItems = @[self.titleItem];
    self.navigationItem.rightBarButtonItem = self.rightItem;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (self.isShow) {
        [self showToast];
    }
    self.isOpen = NO;
    self.buttonView.layer.borderWidth = 2;
    self.buttonView.layer.borderColor = [UIColor colorWithRed:63/255.0 green:137/255.0 blue:181/255.0 alpha:1].CGColor;
    self.buttonView.layer.cornerRadius = 10;
    self.buttonView.layer.masksToBounds = YES;
    self.logOutButton  = [UIButton buttonWithType:UIButtonTypeCustom];
    self.logOutButton.frame = CGRectMake([UIScreen mainScreen].bounds.size.width-130,([UIScreen mainScreen].bounds.size.height == 812.0f)?88:64, 120, 45);
    
    [self.logOutButton setTitle:@"  Logout" forState:UIControlStateNormal];
    self.logOutButton.backgroundColor = [UIColor blackColor];
    self.logOutButton.alpha = 0.6;
    self.logOutButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.logOutButton addTarget:self action:@selector(logoutt) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.logOutButton];
    self.logOutButton.hidden = YES;
}

- (void)logoutt {
    MASLoginViewController *controller = [[MASLoginViewController alloc] init];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"adminNo"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"password"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
    nav.navigationBar.barTintColor = [UIColor whiteColor];
    [UIApplication sharedApplication].keyWindow.rootViewController = nav;
    [[UIApplication sharedApplication].keyWindow makeKeyAndVisible];
}

// 登录后greeting
- (void)showToast {
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    NSString *name = [[MASDBHandle shareMASDBHandle] searchName:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    if (name) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showSuccessAndDismiss:[NSString stringWithFormat:@"welcome, %@", name]];
    }
    else {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showSuccessAndDismiss:[NSString stringWithFormat:@"welcome, %@", adminNo]];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataArray = [NSMutableArray array];
    self.dataStateArray = [NSMutableArray array];
    NSDictionary *dict = [self SSIDInfo];
    
    NSLog(@"dict:%@",dict);
    
#warning 这里获取无线网mac地址，如果需要自己设置，则直接可以写self.mac = @"name"
    //无线网的MAC地址
    self.mac = [dict objectForKey:@"BSSID"];
    NSString *mac1 = [[NSUserDefaults standardUserDefaults] objectForKey:@"mac"];
    if (mac1) {
        self.realMac = mac1;
        // 截取前面24个字符
        self.mac = self.mac = [[mac1 MD5String] substringToIndex:24];
    }else{
        NSMutableString *macStr = [NSMutableString string];
        for (int i =0; i<6; i++) {
            int num = (int)(0 + (arc4random() % (256)));
            if (i == 5) {
                if ([self getHexByDecimal:num].length == 1) {
                    [macStr appendFormat:@"0%@", [self getHexByDecimal:num]];
                }else{
                    [macStr appendFormat:@"%@", [self getHexByDecimal:num]];
                }
            }else{
                if ([self getHexByDecimal:num].length == 1) {
                    [macStr appendFormat:@"0%@:", [self getHexByDecimal:num]];
                }else{
                    [macStr appendFormat:@"%@:", [self getHexByDecimal:num]];
                }
            }
        }
        
        [[NSUserDefaults standardUserDefaults] setObject:macStr forKey:@"mac"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        self.realMac = macStr;
        // 截取前面24个字符
        self.mac = [[macStr MD5String] substringToIndex:24];
    }
    NSLog(@"BSSID:%@",self.mac);
    [self loadData];
}
- (NSString *)getHexByDecimal:(NSInteger)decimal {
    
    NSString *hex =@"";
    NSString *letter;
    NSInteger number;
    for (int i = 0; i<9; i++) {
        
        number = decimal % 16;
        decimal = decimal / 16;
        switch (number) {
                
            case 10:
                letter =@"A"; break;
            case 11:
                letter =@"B"; break;
            case 12:
                letter =@"C"; break;
            case 13:
                letter =@"D"; break;
            case 14:
                letter =@"E"; break;
            case 15:
                letter =@"F"; break;
            default:
                letter = [NSString stringWithFormat:@"%ld", number];
        }
        hex = [letter stringByAppendingString:hex];
        if (decimal == 0) {
            
            break;
        }
    }
    return hex;
}

- (void)loadData {
    
    //请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/moduleInfo.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"TeacherIC"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if (responseObject) {
            if([responseObject isKindOfClass:[NSData class]]) {
                responseObject = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            }
            //解析数据
            NSString *dataString = responseObject;
            if (![dataString hasPrefix:@"error"]) {
                NSArray *tempArray = [dataString componentsSeparatedByString:@"<br>"];
                [self.dataArray addObject:[[tempArray objectAtIndex:1]componentsSeparatedByString:@","]];
                [self.dataArray addObject:[[tempArray objectAtIndex:2]componentsSeparatedByString:@","]];
                [self.dataArray addObject:[[tempArray objectAtIndex:3]componentsSeparatedByString:@","]];
                [self.dataArray addObject:[[tempArray objectAtIndex:4]componentsSeparatedByString:@","]];
                [self.dataArray addObject:[[tempArray objectAtIndex:5]componentsSeparatedByString:@","]];
                [self.dataArray addObject:[[tempArray objectAtIndex:0]componentsSeparatedByString:@","]];
                for (id obj in [self.dataArray objectAtIndex:0]) {
                    [self.dataStateArray addObject:[NSNumber numberWithBool:NO]];
                }
                [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
            }
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internet Error"];
    }];
}

- (void)rightAction {
    self.logOutButton.hidden = !self.logOutButton.hidden;
}

- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @" Current Modules";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:25]];
        label.frame = CGRectMake(10, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}

- (UIBarButtonItem *)rightItem
{
    if (!_rightItem) {
        _rightItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"point"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(rightAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.frame = CGRectMake([UIScreen mainScreen].bounds.size.width-20, 0, 30, 30);
        _rightItem.customView = btn;
    }
    return _rightItem;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *str = [[self.dataArray objectAtIndex:4] objectAtIndex:indexPath.row];
    if (![str isEqualToString:@"Unavailable"]) {
        if (!self.isOpen) {
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:@"Please open bluetooth"];
            return;
        }
        if ([[self.dataStateArray objectAtIndex:indexPath.row] boolValue]) {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"Do you want to close?" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"CANCEL" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"YES" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                [self closeMac:indexPath];
            }];
            [alertController addAction:cancelAction];
            [alertController addAction:okAction];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }else{
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"Do you want to start?" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"CANCEL" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"YES" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                [self addMac:indexPath];
            }];
            [alertController addAction:cancelAction];
            [alertController addAction:okAction];
            
            [self presentViewController:alertController animated:YES completion:nil];
        }
    }
}
#pragma  mark data

- (void)addMac:(NSIndexPath *)indexPath {
    
    //请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/beginAttendance.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:self.realMac forKey:@"MacAddress"];
    [muParameterDic setObject:[[self.dataArray objectAtIndex:5]objectAtIndex:indexPath.row]  forKey:@"ModuleId"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if (responseObject) {
            if([responseObject isKindOfClass:[NSData class]]) {
                responseObject = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            }
            //解析数据
            NSString *dataString = responseObject;
            if ([dataString hasPrefix:@"succe"]) {
                [self.dataStateArray insertObject:[NSNumber numberWithBool:YES] atIndex:indexPath.row];
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
                [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
                [SVProgressHUD showSuccessAndDismiss:@"Succeeded"];
                
            }
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internet Error"];
    }];
}

- (void)closeMac:(NSIndexPath *)indexPath {
    //请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/closeAttendance.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:self.realMac forKey:@"MacAddress"];
    [muParameterDic setObject:[[self.dataArray objectAtIndex:5]objectAtIndex:indexPath.row]  forKey:@"ModuleId"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if (responseObject) {
            if([responseObject isKindOfClass:[NSData class]]) {
                responseObject = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            }
            //解析数据
            NSString *dataString = responseObject;
            if ([dataString hasPrefix:@"succe"]) {
                [self.dataStateArray insertObject:[NSNumber numberWithBool:NO] atIndex:indexPath.row];
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
                [SVProgressHUD showSuccessAndDismiss:@"Succeeded"];
            }
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internet Error"];
    }];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.dataArray.count) {
        return ((NSArray *)[self.dataArray objectAtIndex:0]).count;
    }else{
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MASTeacherMarkAttendanceCell *cell = [tableView dequeueReusableCellWithIdentifier:@"markCell"];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"MASTeacherMarkAttendanceCell" owner:self options:nil] objectAtIndex:0];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [cell setData:self.dataArray index:indexPath.row state:[[self.dataStateArray objectAtIndex:indexPath.row]boolValue]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 180;
}


- (IBAction)bluetooth:(id)sender {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Bluetooth" message:@"Application want to open Bluetooth" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self.peripheralManager stopAdvertising];
        self.peripheralManager = nil;
        self.isOpen = NO;
    }];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Open" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (!self.peripheralManager) {
            // 创建外设管理器，会回调peripheralManagerDidUpdateState方法
            self.peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:dispatch_get_main_queue()];
        }
    }];
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
}



#pragma mark

/** 设备的蓝牙状态
 CBManagerStateUnknown = 0,  未知
 CBManagerStateResetting,    重置中
 CBManagerStateUnsupported,  不支持
 CBManagerStateUnauthorized, 未验证
 CBManagerStatePoweredOff,   未启动
 CBManagerStatePoweredOn,    可用
 */
- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    if (peripheral.state == CBManagerStatePoweredOn) {
        // 创建Service（服务）和Characteristics（特征）
        [self setupServiceAndCharacteristics];
        // 根据服务的UUID开始广播
        [self.peripheralManager startAdvertising:@{CBAdvertisementDataServiceUUIDsKey:@[[CBUUID UUIDWithString:SERVICE_UUID]],CBAdvertisementDataLocalNameKey:self.mac}];
        NSLog(@"%@",peripheral.description);
        self.isOpen = YES;
    }else{
        self.isOpen = NO;
    }
}

/** 创建服务和特征 */
- (void)setupServiceAndCharacteristics {
    // 创建服务
    CBUUID *serviceID = [CBUUID UUIDWithString:SERVICE_UUID];
    CBMutableService *service = [[CBMutableService alloc] initWithType:serviceID primary:YES];
    // 创建服务中的特征
    CBUUID *characteristicID = [CBUUID UUIDWithString:CHARACTERISTIC_UUID];
    CBMutableCharacteristic *characteristic = [
                                               [CBMutableCharacteristic alloc]
                                               initWithType:characteristicID
                                               properties:
                                               CBCharacteristicPropertyRead |
                                               CBCharacteristicPropertyWrite |
                                               CBCharacteristicPropertyNotify
                                               value:nil
                                               permissions:CBAttributePermissionsReadable |
                                               CBAttributePermissionsWriteable
                                               ];
    // 特征添加进服务
    service.characteristics = @[characteristic];
    // 服务加入管理
    [self.peripheralManager addService:service];
    
    // 为了手动给中心设备发送数据
    self.characteristic = characteristic;
}

/** 中心设备读取数据的时候回调 */
- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveReadRequest:(CBATTRequest *)request {
    // 请求中的数据，这里把文本框中的数据发给中心设备
    request.value = [[NSString stringWithFormat:@"%@",self.mac] dataUsingEncoding:NSUTF8StringEncoding];
    // 成功响应请求
    [peripheral respondToRequest:request withResult:CBATTErrorSuccess];
}

/** 中心设备写入数据的时候回调 */
- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray<CBATTRequest *> *)requests {
    
}

/** 订阅成功回调 */
-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic {
    NSLog(@"%s",__FUNCTION__);
}

/** 取消订阅回调 */
-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic {
    NSLog(@"%s",__FUNCTION__);
}

/** 通过固定的特征发送数据到中心设备 */
- (void)didClickPost:(id)sender {
    BOOL sendSuccess = [self.peripheralManager updateValue:[[NSString stringWithFormat:@"%@",self.mac] dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.characteristic onSubscribedCentrals:nil];
    if (sendSuccess) {
        NSLog(@"数据发送成功");
    }else {
        NSLog(@"数据发送失败");
    }
}

- (NSDictionary *)SSIDInfo
{
    NSArray *ifs = (__bridge_transfer NSArray *)CNCopySupportedInterfaces();
    NSDictionary *info = nil;
    for (NSString *ifnam in ifs) {
        info = (__bridge_transfer NSDictionary *)CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam);
        if (info && [info count]) {
            break;
        }
    }
    return info;
}
@end
