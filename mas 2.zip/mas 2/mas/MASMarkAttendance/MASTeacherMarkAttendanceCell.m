//
//  MASTeacherMarkAttendanceCell.m
//  mas
//
//  Created by cocoa on 2018/7/31.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASTeacherMarkAttendanceCell.h"
#import "UIView+MJHView.h"

@interface MASTeacherMarkAttendanceCell ()
@property (nonatomic, strong) IBOutlet UIView *customerView;

@property (nonatomic, weak) IBOutlet UILabel *moduleLabel;
@property (nonatomic, weak) IBOutlet UILabel *beginLabel;
@property (nonatomic, weak) IBOutlet UILabel *teacherLabel;
@property (nonatomic, weak) IBOutlet UILabel *endLabel;

@property (nonatomic, weak) IBOutlet UILabel *stateLabel;

@end
@implementation MASTeacherMarkAttendanceCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setData:(NSArray *)array  index:(NSInteger )index state:(BOOL)state {
    //设置cell内容
    self.moduleLabel.text = [[array objectAtIndex:0] objectAtIndex:index];
    self.teacherLabel.text = [[array objectAtIndex:1] objectAtIndex:index];
    self.beginLabel.text = [[array objectAtIndex:2] objectAtIndex:index];
    self.endLabel.text = [[array objectAtIndex:3] objectAtIndex:index];
    NSString *str = [[array objectAtIndex:4] objectAtIndex:index];
    if ([str isEqualToString:@"Unavailable"]) {
        [self.customerView setBorderWithView:YES left:YES bottom:YES right:YES borderColor:[UIColor redColor] borderWidth:3 isShort:@""];
    }else{
        [self.customerView setBorderWithView:YES left:YES bottom:YES right:YES borderColor:[UIColor greenColor] borderWidth:3 isShort:@""];
    }
    if (state) {
        self.stateLabel.text = @"Start";
    }else{
        self.stateLabel.text = @"Stop";
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
