//
//  MASTeacherMarkAttendanceCell.h
//  mas
//
//  Created by cocoa on 2018/7/31.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASTeacherMarkAttendanceCell : UITableViewCell
- (void)setData:(NSArray *)array index:(NSInteger )index state:(BOOL)state;

@end
