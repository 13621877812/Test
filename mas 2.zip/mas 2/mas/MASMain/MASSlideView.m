//
//  YDSlideView.m
//  YDHealthy
//
//  Created by chni on 16/8/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASSlideView.h"
#import "VKSideMenu.h"

#import "MASMarkAttendanceViewController.h"
#import "MASTimeTableViewController.h"
#import "MASMyProfileViewController.h"
#import "MASTeacherInfoViewController.h"

#import "MASAboutViewController.h"
#import "MASLoginViewController.h"
#import "MASDBHandle.h"
#import <NSString+MJHHelper.h>

static MASSlideView *slideSingleton = nil;

@interface MASSlideView ()<VKSideMenuDelegate, VKSideMenuDataSource>

@property (nonatomic, strong) VKSideMenu *menuLeft;
@property (nonatomic, weak) UIViewController *holdViewContoller;

@end

@implementation MASSlideView

//设置单例
+ (MASSlideView *)shareYDSlideView {
    static dispatch_once_t slideOnceToken;
    dispatch_once(&slideOnceToken, ^{
        slideSingleton = [[self alloc]init];
    });
    return slideSingleton;
}

- (id)copyWithZone:(NSZone *)zone {
    
    return slideSingleton;;
}

+ (id)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t slideZoneOnceToken;
    dispatch_once(&slideZoneOnceToken, ^{
        slideSingleton = [super allocWithZone:zone];
    });
    return slideSingleton;
}

//初始化加载侧边栏
- (void)initSlideViewForView:(UIViewController *)viewController setString:(NSString *)nickNameString  eamilString:(NSString *)eamilString {
    static dispatch_once_t slideInitOnceToken;
    dispatch_once(&slideInitOnceToken, ^{
        self.menuLeft = [[VKSideMenu alloc] initWithSize:[UIScreen mainScreen].bounds.size.width*0.85 andDirection:VKSideMenuDirectionFromLeft];
        self.menuLeft.selectionColor   = [UIColor colorWithWhite:1 alpha:1];
        self.menuLeft.dataSource = slideSingleton;
        self.menuLeft.delegate   = slideSingleton;
        //        self.menuLeft.iconsColor = [UIColor colorWithRed:18/255.0 green:163/255.0 blue:62/255.0 alpha:1];
    });
    self.holdViewContoller = viewController;
    //    [self.menuLeft addSwipeGestureRecognition:viewController.view];
    [self.menuLeft show];
    //从userdefault加载adminNo
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    adminNo?(self.menuLeft.nickNameLabel.text = adminNo):(self.menuLeft.nickNameLabel.text = @"未知");
    adminNo?(self.menuLeft.eamilLabel.text = [NSString stringWithFormat:@"%@@mymail.nyp.edu.sg",adminNo]):(self.menuLeft.eamilLabel.text = @"未知");
    
    //    self.menuLeft.nickNameLabel.text = nickNameString;
    //    self.menuLeft.eamilLabel.text = eamilString;
    //根据adminNo获取用户头像有的话加载，没有的话不加载。
    NSString *timeTable = [[MASDBHandle shareMASDBHandle] searchMyprofile:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    NSString *imagePath = [NSString creatPathInDocuments:timeTable];
    if(timeTable) {
        [self.menuLeft.addImageButton setBackgroundImage:[UIImage imageWithContentsOfFile:imagePath] forState:UIControlStateNormal];
    }
    [self.menuLeft.addImageButton addTarget:self action:@selector(clickAction) forControlEvents:UIControlEventTouchUpInside];
}

///点击事件
- (void)clickAction {
    NSLog(@"11111");
}

#pragma mark - VKSideMenuDataSource

-(NSInteger)numberOfSectionsInSideMenu:(VKSideMenu *)sideMenu
{
    return 2;
}

-(NSInteger)sideMenu:(VKSideMenu *)sideMenu numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 4;
    }else{
        return 2;
    }
}

//设置侧边栏的标题和头像
-(VKSideMenuItem *)sideMenu:(VKSideMenu *)sideMenu itemForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // This solution is provided for DEMO propose only
    // It's beter to store all items in separate arrays like you do it in your UITableView's. Right?
    VKSideMenuItem *item = [VKSideMenuItem new];
    
    if (sideMenu == self.menuLeft) // All LEFT and TOP menu items
    {
        if (indexPath.section == 0) {
            switch (indexPath.row)
            {
                case 0:
                    item.title = @"Mark Attendance";
                    item.icon  = [UIImage imageNamed:@"ic_menu_attendance"];
                    break;
                    
                case 1:
                    item.title = @"Time Table";
                    item.icon  = [UIImage imageNamed:@"ic_menu_timetable"];
                    break;
                    
                case 2:
                    item.title = @"My Profile";
                    item.icon  = [UIImage imageNamed:@"ic_menu_myprofile"];
                    break;
                case 3:
                    item.title = @"Teacher Info";
                    item.icon  = [UIImage imageNamed:@"ic_menu_teacherinfo"];
                    break;
                default:
                    break;
            }
        }else{
            switch (indexPath.row)
            {
                case 0:
                    item.title = @"About";
                    item.icon  = [UIImage imageNamed:@"ic_menu_about"];
                    break;
                    
                case 1:
                    item.title = @"Logout";
                    item.icon  = [UIImage imageNamed:@"ic_menu_logout"];
                    break;
                    
                default:
                    break;
            }
        }
    }
    return item;
}
//设置返回section的title
#pragma mark - VKSideMenuDelegate
-(NSString *)sideMenu:(VKSideMenu *)sideMenu titleForHeaderInSection:(NSInteger)section {
    if (section == 1) {
        return @"Others";
    }else{
        return nil;
    }
}
//侧边栏点击事件
-(void)sideMenu:(VKSideMenu *)sideMenu didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        switch (indexPath.row)
        {
            case 0:
            {
                MASMarkAttendanceViewController *controller = [[MASMarkAttendanceViewController alloc] init];
                UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
                nav.navigationBar.barTintColor = [UIColor whiteColor];
                [UIApplication sharedApplication].keyWindow.rootViewController = nav;
                [[UIApplication sharedApplication].keyWindow makeKeyAndVisible];
                break;}
            case 1:
            {
                MASTimeTableViewController *controller = [[MASTimeTableViewController alloc] init];
                UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
                nav.navigationBar.barTintColor = [UIColor whiteColor];
                [UIApplication sharedApplication].keyWindow.rootViewController = nav;
                [[UIApplication sharedApplication].keyWindow makeKeyAndVisible];
                break;}
            case 2:  {
                MASMyProfileViewController *controller = [[MASMyProfileViewController alloc] init];
                UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
                nav.navigationBar.barTintColor = [UIColor whiteColor];
                [UIApplication sharedApplication].keyWindow.rootViewController = nav;
                [[UIApplication sharedApplication].keyWindow makeKeyAndVisible];
                break;}
                break;
            case 3:  {
                MASTeacherInfoViewController *controller = [[MASTeacherInfoViewController alloc] init];
                UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
                nav.navigationBar.barTintColor = [UIColor whiteColor];
                [UIApplication sharedApplication].keyWindow.rootViewController = nav;
                [[UIApplication sharedApplication].keyWindow makeKeyAndVisible];
                break;}
                break;
            default:
                break;
        }
        
    }else{
        switch (indexPath.row)
        {
            case 0:
            {
                MASAboutViewController *controller = [[MASAboutViewController alloc] init];
                [(UINavigationController *)[UIApplication sharedApplication].keyWindow.rootViewController pushViewController:controller animated:YES];
                break;}
            case 1:
            {
                MASLoginViewController *controller = [[MASLoginViewController alloc] init];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"adminNo"];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"password"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
                UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:controller];
                nav.navigationBar.barTintColor = [UIColor whiteColor];
                [UIApplication sharedApplication].keyWindow.rootViewController = nav;
                [[UIApplication sharedApplication].keyWindow makeKeyAndVisible];
                break;}
            default:
                break;
        }
    }
}

@end
