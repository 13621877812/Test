//
//  AppDelegate.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "AppDelegate.h"
#import "MASLoginViewController.h"
#import "DHLaunchDfPageHUD.h"
#import "SingleLineTextField.h"
#import <MJHFoundation/NSString+MJHHelper.h>
#import "MASMarkAttendanceViewController.h"
#import <objc/runtime.h>
#import "MASTeacherMarkAttendanceViewController.h"
@interface AppDelegate ()<NSURLSessionDelegate,NSURLSessionDataDelegate>

@end

@implementation AppDelegate



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    

    
    //创建控制器，并设置为跟控制器
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor=[UIColor whiteColor];
    
    
    // 2.包装一个导航控制器
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[MASLoginViewController alloc]init]];
    nav.navigationBar.barTintColor = [UIColor whiteColor];
    self.window.rootViewController = nav;
    [self.window makeKeyAndVisible];
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    if (adminNo) {
        if (adminNo.length > 7) {
            MASTeacherMarkAttendanceViewController *controller = [[MASTeacherMarkAttendanceViewController alloc] init];
            controller.isShow = YES;
            [nav pushViewController:controller animated:YES];
        }else{
            MASMarkAttendanceViewController *controller = [[MASMarkAttendanceViewController alloc] init];
            controller.isShow = YES;
            [nav pushViewController:controller animated:NO];
        }
 
    }
   
    
    //加载初始可以跳过的广告页
    [[DHLaunchDfPageHUD alloc] initWithFrame:CGRectMake(-[UIScreen mainScreen].bounds.size.width*0.826/4, -[UIScreen mainScreen].bounds.size.height/4, [UIScreen mainScreen].bounds.size.width*2*0.826, [UIScreen mainScreen].bounds.size.height*2) window:self.window image:[UIImage imageNamed:@"start_activity_background.jpg"] animationStyle:DDLaunchPageAnimationStyleFadeIn];
    
    //设置myprofile中的输入框的颜色等属性
    [[SingleLineTextField appearance] setLineDisabledColor:[UIColor grayColor]];
    [[SingleLineTextField appearance] setLineSelectedColor:[UIColor colorWithRed:31/255.0 green:130/255.0  blue:113/255.0 alpha:1]];
    [[SingleLineTextField appearance] setInputPlaceHolderColor:[UIColor colorWithRed:0.65 green:0.65 blue:0.65 alpha:1]];
    [[SingleLineTextField appearance] setInputFont:[UIFont boldSystemFontOfSize:15]];
    [[SingleLineTextField appearance] setPlaceHolderFont:[UIFont boldSystemFontOfSize:13]];
    
    //判断本地是否存在MAS.sqlite，不存在则从项目中拷贝到本地Document下
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString creatPathInDocuments:@"MAS.sqlite"]]) {
        NSString *dbPathStr=[[NSBundle mainBundle] pathForResource:@"MAS" ofType:@"sqlite"];
        [[NSFileManager defaultManager] copyItemAtPath:dbPathStr toPath:[NSString creatPathInDocuments:@"MAS.sqlite"] error:nil];
    }
    //判断是否存在originals文件夹，不存在则在app目录下创建originals文件夹
    //获取Document文件
    NSString * docsdir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString * rarFilePath = [docsdir stringByAppendingPathComponent:@"originals"];//将需要创建的串拼接到面
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isDir = NO;
    // fileExistsAtPath 判断一个文件或目录是否有效，isDirectory判断是否一个目录
    BOOL existed = [fileManager fileExistsAtPath:rarFilePath isDirectory:&isDir];
    if ( !(isDir == YES && existed == YES) ) {//如果文件夹不存在
        [fileManager createDirectoryAtPath:rarFilePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
  
    
 
    return YES;
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task willPerformHTTPRedirection:(NSHTTPURLResponse *)response newRequest:(NSURLRequest *)request completionHandler:(void (^)(NSURLRequest * _Nullable))completionHandler
{
    completionHandler(nil);
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
