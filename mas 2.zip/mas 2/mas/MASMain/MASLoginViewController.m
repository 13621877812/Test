//
//  MASLoginViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASLoginViewController.h"
#import "OneLoadingAnimationView.h"
#import "MASMarkAttendanceViewController.h"
#import "MASDBHandle.h"
#import <SVProgressHUD+MJHSVProgressHUDUtil.h>
#import "MASTeacherMarkAttendanceViewController.h"
#import <MJHCategoriesHeader.h>
#import "AppDelegate.h"

@interface MASLoginViewController ()
@property (nonatomic, weak) IBOutlet UITextField *accountTextField;
@property (nonatomic, weak) IBOutlet UITextField *passwordTextField;
@property (nonatomic, strong) OneLoadingAnimationView *animationView;


@end

@implementation MASLoginViewController

//view将要显示
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //接受转动完成的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadingEnd) name:@"loadingEnd" object:nil];
}


//登录
- (IBAction)SignIn:(id)sender {
    if([self.accountTextField.text isEqualToString:@""]) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD  showErrorAndDismiss:@"Please enter account"];
    }else{
        //数据库方法，MASDBhandle中有解释
        if([[MASDBHandle shareMASDBHandle] insertAdminNo:self.accountTextField.text andFirebaseToken:@"312345678"]) {
            [[NSUserDefaults standardUserDefaults] synchronize];
            if (self.accountTextField.text.length >7) {
                if ([self.passwordTextField.text isEqualToString:@""]) {
                    [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
                    [SVProgressHUD  showErrorAndDismiss:@"Please enter password"];
                }else{
                    [self loadData];
                }
            }else{
                [self getStudentLoginUrl];
            }
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:@"Database Error"];
        }
    }
}
- (void)getStudentLoginUrl {
    //请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/studentLogin.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:@"login" forKey:@"status"];
//    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"password"]  forKey:@"Password"];
    
    [[MJHAFNetworking shareMJHAFNetworking]MJHGet:[urlString stringToUTF8String] parameter:muParameterDic timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if (responseObject) {
            if([responseObject isKindOfClass:[NSData class]]) {
                responseObject = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            }
            //解析数据
            NSString *dataString = responseObject;
            [self studentLogin:dataString];
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internent Error"];
    }];
    
   
}


- (void)studentLogin:(NSString *)requestUrl {
    //请求数据
    NSArray *array = [requestUrl componentsSeparatedByString:@"_split_"];
    NSString *loginUrl=[array lastObject];
    NSString *request_id=@"";
    if (array.count == 2) {
        request_id = [array firstObject];
    }
    
    NSString *urlString = [NSString stringWithFormat:@"http://%@:8080/MASLogin/login",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:self.accountTextField.text forKey:@"username"];
    [muParameterDic setObject:self.passwordTextField.text  forKey:@"password"];
    [muParameterDic setObject:loginUrl forKey:@"loginURL"];
    [muParameterDic setObject:request_id forKey:@"request_id"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if (responseObject) {
            if([responseObject isKindOfClass:[NSData class]]) {
                responseObject = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
                if ([responseObject isEqualToString:@"true"]) {
                    [[NSUserDefaults standardUserDefaults] setObject:self.accountTextField.text forKey:@"adminNo"];
                    [[NSUserDefaults standardUserDefaults] setObject:self.passwordTextField.text forKey:@"password"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    UIView *view = [[UIView alloc] initWithFrame:self.view.bounds];
                    view.backgroundColor = [UIColor whiteColor];
                    [self.view addSubview:view];
                    self.animationView = [[OneLoadingAnimationView alloc] init];
                    [view addSubview:self.animationView];
                    [self.animationView startAnimation];
                }
                else {
                    [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
                    [SVProgressHUD showErrorAndDismiss:@"Account or password error"];
                }
            }
            else {
                [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
                [SVProgressHUD showErrorAndDismiss:@"Account or password error"];
            }
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internent Error"];
    }];
}
- (void)loadData {
    //请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/teacherLogin.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"TeacherIC"];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"password"]  forKey:@"Password"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if (responseObject) {
            if([responseObject isKindOfClass:[NSData class]]) {
                responseObject = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            }
            //解析数据
            NSString *dataString = responseObject;
            if ([dataString hasPrefix:@"succeeded"]) {
                UIView *view = [[UIView alloc] initWithFrame:self.view.bounds];
                view.backgroundColor = [UIColor whiteColor];
                [self.view addSubview:view];
                self.animationView = [[OneLoadingAnimationView alloc] init];
                [view addSubview:self.animationView];
                [self.animationView startAnimation];
            }
            else {
                [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
                [SVProgressHUD showErrorAndDismiss:@"Account or password error"];
            }
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internent Error"];
    }];
}

//转动显示完成之后首先加载MarkAttendance
- (void)loadingEnd {
    if (self.accountTextField.text.length > 7) {
        MASTeacherMarkAttendanceViewController *controller = [[MASTeacherMarkAttendanceViewController alloc] init];
        controller.isShow = YES;
        [self.navigationController pushViewController:controller animated:YES];
    }else{
        MASMarkAttendanceViewController *controller = [[MASMarkAttendanceViewController alloc] init];
        controller.isShow = YES;
        [self.navigationController pushViewController:controller animated:YES];
    }   
}


- (IBAction)Register:(id)sender {
    
}

- (IBAction)Others:(UIButton *)sender {
    NSInteger tag = sender.tag;
    if (tag == 11) {
        BOOL isInstalled = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"fb://"]];
        if (isInstalled) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"fb://"]];
        } else {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.facebook.com/nanyangpoly"]];
        }
    }else if (tag == 22) {
        BOOL isInstalled = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"fb://"]];
        if (isInstalled) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tw://"]];
        } else {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://mobile.twitter.com/nypweets"]];
        }
    }else if (tag == 33) {
        BOOL isInstalled = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"fb://"]];
        if (isInstalled) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"ins://"]];
        } else {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.instagram.com/nanyangpoly"]];
        }
    }else{
        BOOL isInstalled = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"youtube://"]];
        if (isInstalled) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"youtube://"]];
        } else {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.youtube.com/user/weareNYP"]];
        }
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
