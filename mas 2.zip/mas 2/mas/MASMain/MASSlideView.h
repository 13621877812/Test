//
//  YDSlideView.h
//  YDHealthy
//
//  Created by chni on 16/8/16.
//  Copyright © 2016年 孟家豪. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface MASSlideView : NSObject



+ (MASSlideView *)shareYDSlideView;

//加载侧边栏
- (void)initSlideViewForView:(UIViewController *)viewController setString:(NSString *)nickNameString  eamilString:(NSString *)eamilString;

@end
