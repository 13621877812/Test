//
//  MASMyProfileViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASMyProfileViewController.h"
#import "MASSlideView.h"
#import "SingleLineTextField.h"
#import "MASMapViewController.h"
#import "MASNewsViewController.h"
#import <NSString+MJHHelper.h>
#import "MASDBHandle.h"
#import <SVProgressHUD+MJHSVProgressHUDUtil.h>
#import <CoreLocation/CoreLocation.h>
#import <MJHCategoriesHeader.h>
#import "AppDelegate.h"
@interface MASMyProfileViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate,CLLocationManagerDelegate>
@property (nonatomic, strong) UIBarButtonItem *sideItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;
@property (nonatomic, strong) UIBarButtonItem *rightItem;

@property (nonatomic, weak) IBOutlet UIButton *selectButton;
@property (nonatomic, weak) IBOutlet UIButton *uploadButton;
@property (nonatomic, weak) IBOutlet UIImageView *imageIcon;
@property (nonatomic, strong) UIImage *cacheImage;

@property(nonatomic,strong) UIImagePickerController *imagePicker; //声明全局的UIImagePickerController

@property (nonatomic, weak) IBOutlet UILabel *nameLabel;
@property (nonatomic, weak) IBOutlet UILabel *emailLabel;
@property (nonatomic, weak) IBOutlet UILabel *locationLabel;


@property (nonatomic, weak) IBOutlet UIImageView *nameImageIcon;
@property (nonatomic, weak) IBOutlet UIImageView *scgImageIcon;
@property (nonatomic, weak) IBOutlet SingleLineTextField *nameTextField;
@property (nonatomic, weak) IBOutlet SingleLineTextField *scgTextField;

@property (nonatomic, strong) CLLocationManager *locationManager;

@property (nonatomic, weak) IBOutlet UIButton *map;


@end

@implementation MASMyProfileViewController
- (void)viewWillAppear:(BOOL)animated {
    //隐藏导航栏，加载左侧右侧按钮
    self.navigationController.navigationBar.hidden = NO;
    self.navigationItem.leftBarButtonItems = @[self.sideItem,self.titleItem];
    self.navigationItem.rightBarButtonItem = self.rightItem;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    //开始定位
    [self startLocation];
    //关键语句
    self.selectButton.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    self.selectButton.layer.borderColor = [UIColor colorWithRed:137/255.0 green:253/255.0 blue:43/255.0 alpha:1].CGColor;//设置边框颜色
    self.selectButton.layer.borderWidth = 2.0f;//设置边框颜色
    //关键语句
    self.uploadButton.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    self.uploadButton.layer.borderColor = [UIColor colorWithRed:137/255.0 green:253/255.0 blue:43/255.0 alpha:1].CGColor;//设置边框颜色
    self.uploadButton.layer.borderWidth = 2.0f;//设置边框颜色
    
    //根据aminNo获取用户头像，有则显示没有则不加载。
    NSString *timeTable = [[MASDBHandle shareMASDBHandle] searchMyprofile:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    NSString *imagePath = [NSString creatPathInDocuments:timeTable];
    if(timeTable) {
        [self setImage:[UIImage imageWithContentsOfFile:imagePath]];
    }
    //根据userdefaults获取adminNo
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    adminNo?(self.nameLabel.text = adminNo):(self.nameLabel.text = @"unknown");
    adminNo?(self.emailLabel.text = [NSString stringWithFormat:@"%@@mymail.nyp.edu.sg",adminNo]):(self.emailLabel.text = @"unknown");
    //设置name和scg右侧对勾可以交互。
    self.nameImageIcon.userInteractionEnabled = YES;
    self.scgImageIcon.userInteractionEnabled = YES;
    //为name和scgiamgeview加载点击事件
    UITapGestureRecognizer *tapGesture1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(editName)];
    [self.nameImageIcon addGestureRecognizer:tapGesture1];
    
    UITapGestureRecognizer *tapGesture2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(editSCG)];
    [self.scgImageIcon addGestureRecognizer:tapGesture2];
    //设置name和scg的imageView的状态
    [self setImageData];
    [self.map addTarget:self action:@selector(pushToMapView) forControlEvents:UIControlEventTouchUpInside];
}

- (void)sideAction {
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    [[MASSlideView shareYDSlideView] initSlideViewForView:self setString:adminNo eamilString:[NSString stringWithFormat:@"%@myemail.nyp.edu.sg@", adminNo]];
}

- (void)pushToMapView {
    MASMapViewController *map = [[MASMapViewController alloc] init];
    map.mylocation = self.locationLabel.text;
    [self.navigationController pushViewController:map animated:YES];
}

- (void)rightAction {
    MASNewsViewController *controller = [[MASNewsViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}


- (UIBarButtonItem *)sideItem
{
    if (!_sideItem) {
        _sideItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_side"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(sideAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        btn.frame = CGRectMake(0, 0, 30, 30);
        _sideItem.customView = btn;
    }
    return _sideItem;
}

- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @"    My Profile";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:22]];
        label.frame = CGRectMake(50, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}

- (UIBarButtonItem *)rightItem
{
    if (!_rightItem) {
        _rightItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_alarm_icon"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(rightAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.frame = CGRectMake(0, 0, 30, 30);
        _rightItem.customView = btn;
    }
    return _rightItem;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//点击选择select按钮加载图片选择器。
- (IBAction)selectPhoto:(id)sender {
    //初始化UIImagePickerController类
    UIImagePickerController * picker = [[UIImagePickerController alloc] init];
    //判断数据来源为相册
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    //设置代理
    picker.delegate = self;
    //设置可以剪裁
    picker.allowsEditing = YES;
    
    //picker.showsCameraControls = YES;
    //打开相册
    [self presentViewController:picker animated:YES completion:nil];
}

//选择完成回调函数
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    //获取图片
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    [self dismissViewControllerAnimated:YES completion:nil];
    //使用数据缓冲区接收图片名字
    NSData *imgData=UIImageJPEGRepresentation(image, 1);
    NSString *imgNameStr=[NSString stringWithFormat:@"%.0f.jpg",[[NSDate date] timeIntervalSince1970]];
    NSString *imagePath = [NSString creatPathInDocuments:imgNameStr];
    [imgData writeToFile:imagePath atomically:YES];
    //将图片相对路径保存至数据库
    if([[MASDBHandle shareMASDBHandle] insertMyprofile:imgNameStr]){
        NSLog(@"TimeTable insert success");
    }else{
        NSLog(@"TimeTable insert fail");
    }
    //设置图片
    [self setImage:image];
}

- (void)setImage:(UIImage *)image {
    //本地属性持有iamge对象，下面upload要使用
    self.cacheImage = image;
    self.imageIcon.image = image;
}

- (IBAction)upload:(id)sender {
    //判断本地持有iamge是否为空，不为空则在点击upload时上传头像至originals文件夹
    if(self.cacheImage) {
        //使用数据缓冲区接收图片名字
        NSData *imgData=UIImageJPEGRepresentation(self.cacheImage, 1);
        NSString *imgNameStr=[NSString stringWithFormat:@"%.0f.jpg",[[NSDate date] timeIntervalSince1970]];
        NSString *imagePath = [NSString creatPathInDocuments:[NSString stringWithFormat:@"originals/%@",imgNameStr]];
        [imgData writeToFile:imagePath atomically:YES];
        [self loadImage:imgData imgNameStr:imgNameStr ];
    }else{
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Please select photo"];
    }
}

- (void)loadImage:(NSData *)imgData imgNameStr:(NSString *)imgNameStr {
    [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
    [SVProgressHUD showWithStatus:@"Uploading..."];
    // 参数
    NSMutableDictionary *paras = [NSMutableDictionary dictionary];
    [paras setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"adminNo"];
    [paras setObject:imgNameStr forKey:@"image"];
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/myProfile.php",SERVER_URL_IP];
    //保存用户头像 ----YES
    [[MJHAFNetworking shareMJHAFNetworking]MJHUploadFile:[urlString stringToUTF8String] parameter:paras timeOutInterval:30 uploadBody:^(id<AFMultipartFormData> formData) {
        // 构造数据的地方
        [formData appendPartWithFileData:imgData name:@"image" fileName:imgNameStr mimeType:@"image/jpg"];
    } uploadProgress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        if (responseObject) {
            responseObject = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            NSLog(@"%@", responseObject);
        }
        if ([responseObject hasPrefix:@"succeeded"]) {
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showSuccessAndDismiss:@"Uploaded successfully!"];
        }
        else if ([responseObject hasPrefix:@"errorc"]) {
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showSuccessAndDismiss:@"Please updated after 7 days!"];
        }
        else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:@"Please upload again!"];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Uncertain error!"];
    }];
}

#pragma mark------下部相关
- (void)setImageData {
    NSString *name = [[MASDBHandle shareMASDBHandle] searchName:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    NSString *scg = [[MASDBHandle shareMASDBHandle] searchSCG:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    NSString *timeTable = [[MASDBHandle shareMASDBHandle] searchMyprofile:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    if(name) {
        self.nameTextField.text = name;
        self.nameTextField.enabled = NO;
        self.nameImageIcon.image = [UIImage imageNamed:@"ic_update"];
    };
    if(scg) {
        self.scgTextField.text = scg;
        self.scgTextField.enabled = NO;
        self.scgImageIcon.image = [UIImage imageNamed:@"ic_update"];
    };
    if (!name && !scg && !timeTable) {
        [self loadData];
    }
}

- (void)loadData {
    //从接口请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/studentInfo.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"AdminNo"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if ([[responseObject objectForKey:@"status"] isEqualToString:@"OK"]) {
            NSDictionary *dic = [responseObject objectForKey:@"0"];
            if (dic) {
                self.nameTextField.text = [dic objectForKey:@"Name"];
                self.scgTextField.text = [dic objectForKey:@"SCG"];
                NSString *image = [dic objectForKey:@"Image"];
                if (image) {
                    NSString *str = [[image componentsSeparatedByString:@","] objectAtIndex:1];
                    // 将base64字符串转为NSData
                    NSData *decodeData = [[NSData alloc]initWithBase64EncodedString:str options:(NSDataBase64DecodingIgnoreUnknownCharacters)];
                    self.imageIcon.image = [UIImage imageWithData: decodeData];
                    
                    //使用数据缓冲区接收图片名字
                    NSData *imgData=UIImageJPEGRepresentation([UIImage imageWithData: decodeData], 1);
                    NSString *imgNameStr=[NSString stringWithFormat:@"%.0f.jpg",[[NSDate date] timeIntervalSince1970]];
                    NSString *imagePath = [NSString creatPathInDocuments:imgNameStr];
                    [imgData writeToFile:imagePath atomically:YES];
                    [[MASDBHandle shareMASDBHandle] insertMyprofile:imgNameStr];
                }
                [[MASDBHandle shareMASDBHandle] insertSCG:[NSString stringWithFormat:@"%@",[dic objectForKey:@"SCG"]]];
                [[MASDBHandle shareMASDBHandle] insertName:[NSString stringWithFormat:@"%@",[dic objectForKey:@"Name"]]];
            }
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internet error"];
    }];
}

- (IBAction) textFieldDoneEditing:(id)sender {
    [sender resignFirstResponder];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}

- (void)editName {
    if(!self.nameTextField.isEnabled) {
        self.nameTextField.enabled = YES;
        self.nameImageIcon.image = [UIImage imageNamed:@"ic_tick_icon"];
        return;
    }
    
    if([self.nameTextField.text isEqualToString:@""]) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Please enter name"];
    }else{
        if([[MASDBHandle shareMASDBHandle] insertName:self.nameTextField.text]) {
            self.nameTextField.enabled = NO;
            self.nameImageIcon.image = [UIImage imageNamed:@"ic_update"];
            [self loadData:@"name" data:self.nameTextField.text];
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:@"Name modify failed"];
        }
    }
}
- (void)editSCG {
    if(!self.scgTextField.isEnabled) {
        self.scgTextField.enabled = YES;
        self.scgImageIcon.image = [UIImage imageNamed:@"ic_tick_icon"];
        return;
    }
    
    if([self.scgTextField.text isEqualToString:@""]) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Please enter SCG"];
    }else{
        if([[MASDBHandle shareMASDBHandle] insertSCG:self.scgTextField.text]) {
            self.scgTextField.enabled = NO;
            self.scgImageIcon.image = [UIImage imageNamed:@"ic_update"];
            [self loadData:@"SCG" data:self.scgTextField.text];
            
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showErrorAndDismiss:@"SCG modify failed"];
        }
    }
}

- (void)loadData:(NSString *)post data:(NSString *)data {
    //从接口请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/myProfile.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"adminNo"];
    [muParameterDic setObject:data forKey:post];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if (responseObject) {
            responseObject = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        }
        if ([responseObject hasPrefix:@"succeeded"]) {
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
            [SVProgressHUD showSuccessAndDismiss:@"Uploaded successfully!"];
        }
        else{
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 200)];
        [SVProgressHUD showErrorAndDismiss:@"Internet error"];
    }];
}


//开始定位
- (void)startLocation {
    if ([CLLocationManager locationServicesEnabled]) {
        //        CLog(@"--------开始定位");
        self.locationManager = [[CLLocationManager alloc]init];
        self.locationManager.delegate = self;
        //控制定位精度,越高耗电量越
        self.locationManager.desiredAccuracy = kCLLocationAccuracyKilometer;
        // 总是授权
        [self.locationManager requestAlwaysAuthorization];
        self.locationManager.distanceFilter = 10.0f;
        [self.locationManager requestWhenInUseAuthorization];
        [self.locationManager startUpdatingLocation];
    }
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    if ([error code] == kCLErrorDenied) {
        NSLog(@"访问被拒绝");
    }
    if ([error code] == kCLErrorLocationUnknown) {
        NSLog(@"无法获取位置信息");
    }
}
//定位代理经纬度回调
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    CLLocation *newLocation = locations[0];
    
    // 获取当前所在的城市名
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    //根据经纬度反向地理编译出地址信息
    [geocoder reverseGeocodeLocation:newLocation completionHandler:^(NSArray *array, NSError *error){
        if (array.count > 0){
            CLPlacemark *placemark = [array objectAtIndex:0];
            
            //获取城市
            NSString *city = placemark.locality;
            if (!city) {
                //四大直辖市的城市信息无法通过locality获得，只能通过获取省份的方法来获得（如果city为空，则可知为直辖市）
                city = placemark.administrativeArea;
            }
            NSLog(@"city = %@", city);// 市
            NSLog(@"--%@",placemark.name);// 号
            NSLog(@"++++%@",placemark.subLocality); // 区
            NSLog(@"country == %@",placemark.country);// 国
            NSLog(@"administrativeArea == %@",placemark.administrativeArea); // 省
            self.locationLabel.text = [NSString stringWithFormat:@"%@,%@,%@,%@%@",placemark.name,placemark.subLocality,city,(placemark.administrativeArea?[NSString stringWithFormat:@"%@,",placemark.administrativeArea]:@" "),placemark.country];
        }
        else if (error == nil && [array count] == 0)
        {
            NSLog(@"No results were returned.");
        }
        else if (error != nil)
        {
            NSLog(@"An error occurred = %@", error);
        }
    }];
    //系统会一直更新数据，直到选择停止更新，因为我们只需要获得一次经纬度即可，所以获取之后就停止更新
    [manager stopUpdatingLocation];
}

@end
