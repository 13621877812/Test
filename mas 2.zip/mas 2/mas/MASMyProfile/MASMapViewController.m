//
//  MASMapViewController.m
//  mas
//
//  Created by cocoa on 2018/7/30.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASMapViewController.h"
#import <NSString+MJHHelper.h>
#import "MASDBHandle.h"
#import <MapKit/MapKit.h>
#import "MyAnnoation.h"
#import <MapKit/MKCircle.h>
#import <MapKit/MKCircleView.h>

@interface MASMapViewController ()<MKMapViewDelegate>
@property (nonatomic, strong) UIBarButtonItem *backItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;

@property (nonatomic, weak) IBOutlet MKMapView*mapView;

@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, assign) CLLocationCoordinate2D point;
@property (nonatomic,strong)CLGeocoder * geoC;

@end

@implementation MASMapViewController

MKPointAnnotation *annotation0;
MKPointAnnotation *annotation1;
int countAnnoation = 0;
double distanceBetweenTwoPlaces = 0;
CLPlacemark *desPlacemark;
CLPlacemark *origPlacemark;

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationItem.leftBarButtonItems = @[self.backItem,self.titleItem];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [_mapView setRegion:MKCoordinateRegionMakeWithDistance(CLLocationCoordinate2DMake(1.3800709, 103.8468326), 1000, 1000) animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mapView.delegate = self;
    self.mapView.showsUserLocation = YES;
    
    //warning 学校坐标
    //self.point = CLLocationCoordinate2DMake(1.3800709,103.8468326);
    
    annotation0 = [[MKPointAnnotation alloc] init];
    [annotation0 setCoordinate:CLLocationCoordinate2DMake(1.3800709,103.8468326)];
    [annotation0 setTitle:@"Nanyang Polytechnic"];
    [annotation0 setSubtitle:@"180 Ang Mo Kio Avenue 8, Singapore"];
    [_mapView addAnnotation:annotation0];
    
    CLLocation *location =  [[CLLocation alloc] initWithLatitude:1.3800709 longitude:103.8468326];
    // 获取当前所在的城市名
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    //根据经纬度反向地理编译出地址信息
    [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *array, NSError *error)
     {
         if (array.count > 0){
             desPlacemark = [array objectAtIndex:0];
             
             //获取城市
             NSString *city = desPlacemark.locality;
             if (!city) {
                 //四大直辖市的城市信息无法通过locality获得，只能通过获取省份的方法来获得（如果city为空，则可知为直辖市）
                 city = desPlacemark.administrativeArea;
             }
         }
         else if (error == nil && [array count] == 0)
         {
             NSLog(@"No results were returned.");
         }
         else if (error != nil)
         {
             NSLog(@"An error occurred = %@", error);
         }
     }];
    
    annotation1 = [[MKPointAnnotation alloc] init];
    countAnnoation = 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (UIBarButtonItem *)backItem
{
    if (!_backItem) {
        _backItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_action_back"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        btn.frame = CGRectMake(0, 0, 30, 30);
        _backItem.customView = btn;
    }
    return _backItem;
}

- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @"    Google Map";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:22]];
        label.frame = CGRectMake(50, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}
- (void)backAction {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark MKMapViewDelegate

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    _coordinate.latitude = userLocation.location.coordinate.latitude;
    _coordinate.longitude = userLocation.location.coordinate.longitude;
    
    // 获取当前所在的城市名
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    //根据经纬度反向地理编译出地址信息
    [geocoder reverseGeocodeLocation:userLocation.location completionHandler:^(NSArray *array, NSError *error)
     {
         if (array.count > 0){
             origPlacemark = [array objectAtIndex:0];
             
             //获取城市
             NSString *city = origPlacemark.locality;
             if (!city) {
                 //四大直辖市的城市信息无法通过locality获得，只能通过获取省份的方法来获得（如果city为空，则可知为直辖市）
                 city = origPlacemark.administrativeArea;
             }
             [annotation1 setSubtitle:[NSString stringWithFormat:@"%@,%@,%@,%@%@",origPlacemark.name,origPlacemark.subLocality,city,(origPlacemark.administrativeArea?[NSString stringWithFormat:@"%@,",origPlacemark.administrativeArea]:@" "),origPlacemark.country]];
         }
         else if (error == nil && [array count] == 0)
         {
             NSLog(@"No results were returned.");
         }
         else if (error != nil)
         {
             NSLog(@"An error occurred = %@", error);
         }
     }];
    
    NSString *name = [[MASDBHandle shareMASDBHandle] searchName:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
    if (name) {
        [annotation1 setTitle:[NSString stringWithFormat:@"Hello, %@", name]];
    }
    
    if(countAnnoation == 0) {
        [annotation1 setCoordinate:CLLocationCoordinate2DMake(_coordinate.latitude+0.0001, _coordinate.longitude)];
        [_mapView addAnnotation:annotation1];
        countAnnoation++;
        
    }
    else {
        [_mapView removeAnnotation:annotation1];
        [annotation1 setCoordinate:CLLocationCoordinate2DMake(_coordinate.latitude+0.0001, _coordinate.longitude)];
        [_mapView addAnnotation:annotation1];
        countAnnoation = 0;
    }
    
    [self getRouteWithBeginPL:desPlacemark andEndPL:origPlacemark];
    MKCircle *circleTargePlace = [MKCircle circleWithCenterCoordinate:annotation0.coordinate radius:300];
    [_mapView addOverlay:circleTargePlace];
    distanceBetweenTwoPlaces = [self distanceBetweenOrderByLat1:1.3800709 andLat2:_coordinate.latitude andLng1: 103.8468326 andLng2:_coordinate.longitude];
}

- (double)distanceBetweenOrderByLat1: (double)lat1 andLat2: (double)lat2 andLng1: (double)lng1 andLng2: (double)lng2 {
    double dd = M_PI/180;
    double x1=lat1*dd,x2=lat2*dd;
    double y1=lng1*dd,y2=lng2*dd;
    double R = 6371004;
    double distance = (2*R*asin(sqrt(2-2*cos(x1)*cos(x2)*cos(y1-y2) - 2*sin(x1)*sin(x2))/2));
    //返回 m
    return distance;
}

- (void)getRouteWithBeginPL:(CLPlacemark *)beginP andEndPL:(CLPlacemark *)endPL
{
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc] init];
    
    // 起点
    CLPlacemark *clP = beginP;
    MKPlacemark *mkP = [[MKPlacemark alloc] initWithPlacemark:clP];
    MKMapItem *sourceItem = [[MKMapItem alloc] initWithPlacemark:mkP];
    request.source = sourceItem;
    
    // 终点
    CLPlacemark *clP2 = endPL;
    MKPlacemark *mkP2 = [[MKPlacemark alloc] initWithPlacemark:clP2];
    MKMapItem *endItem = [[MKMapItem alloc] initWithPlacemark:mkP2];
    request.destination = endItem;
    
    MKDirections *direction = [[MKDirections alloc] initWithRequest:request];
    
    [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) {
        [self showDirectionsOnMap:response];
        
    }];
}

-(void)showDirectionsOnMap :(MKDirectionsResponse *)respones
{
    for (MKRoute  * route  in respones.routes) {
        [_mapView addOverlay:route.polyline level:MKOverlayLevelAboveRoads];
    }
}

//遵循代理<MKMapViewDelegate>
//导入MapKit框架
-(MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay
{
    if ([overlay isKindOfClass:[MKCircle class]]) {
        MKCircleRenderer *circleR = [[MKCircleRenderer alloc] initWithOverlay:overlay];
        circleR.lineWidth = 4;
        if(distanceBetweenTwoPlaces <= 300) {
            // 设置颜色
            circleR.strokeColor = [UIColor greenColor];
        }
        else {
            // 设置颜色
            circleR.strokeColor = [UIColor redColor];
        }
        return circleR;
    }
    if ([overlay isKindOfClass:[MKPolyline class]])
    {
        MKPolylineRenderer *render = [[MKPolylineRenderer alloc] initWithOverlay:overlay];
        // 设置线宽
        render.lineWidth = 4;
        if(distanceBetweenTwoPlaces <= 300) {
            // 设置颜色
            render.strokeColor = [UIColor greenColor];
        }
        else {
            // 设置颜色
            render.strokeColor = [UIColor redColor];
        }
        return render;
    }
    return nil;
}


- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
    // If the annotation is the user location, just return nil.
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    if ([annotation isKindOfClass:[MKPointAnnotation class]]) {
        MKAnnotationView* customPinView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"MKPointAnnotation"];
        
        
        NSLog(@"%@", [NSString stringWithFormat:@"%f",annotation.coordinate.latitude]);
        NSLog(@"%@", [NSString stringWithFormat:@"%f",annotation.coordinate.longitude]);
        if (annotation.coordinate.latitude == 1.3800709 && annotation.coordinate.longitude == 103.8468326) {
            customPinView.image = [UIImage imageNamed:@"school"];
            customPinView.canShowCallout = YES;
            
            // Add a custom image to the left side of the callout.（设置弹出起泡的左面图片）
            UIImageView *myCustomImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"nyp"]];
            customPinView.leftCalloutAccessoryView = myCustomImage;
        }else {
            customPinView.image = [UIImage imageNamed:@"me"];
            customPinView.canShowCallout = YES;
            
            //根据aminNo获取用户头像，有则显示没有则不加载。
            NSString *timeTable = [[MASDBHandle shareMASDBHandle] searchMyprofile:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"]];
            NSString *imagePath = [NSString creatPathInDocuments:timeTable];
            if(timeTable) {
                CGRect rect = CGRectMake(0,0,50,50);
                UIGraphicsBeginImageContext(rect.size);
                [[UIImage imageWithContentsOfFile:imagePath] drawInRect:rect];
                UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
                NSData *imageData = UIImagePNGRepresentation(newImage);
                
                // Add a custom image to the left side of the callout.（设置弹出起泡的左面图片）
                UIImageView *myCustomImage = [[UIImageView alloc] initWithImage:[UIImage imageWithData:imageData]];
                customPinView.leftCalloutAccessoryView = myCustomImage;
            }
        }
        
        UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 90, 50)];
        rightButton.backgroundColor = [UIColor grayColor];
        [rightButton setTitle:@"Detail" forState:UIControlStateNormal];
        customPinView.rightCalloutAccessoryView = rightButton;
        
        return customPinView;
    }
    return nil;
}

#define MERCATOR_RADIUS 85445659.44705395

- (int)getZoomLevel:(MKMapView*)_mapView {
    return 21-round(log2(_mapView.region.span.longitudeDelta * MERCATOR_RADIUS * M_PI / (180.0 * _mapView.bounds.size.width)));
}

- (void)mapView:(MKMapView *)_mapView regionDidChangeAnimated:(BOOL)animated {
    // NSLog(@"zoom level %d", [self getZoomLevel:_mapView]);
}

- (CLGeocoder *)geoC
{
    if (!_geoC) {
        _geoC = [[CLGeocoder alloc] init];
    }
    return _geoC;
}
@end
