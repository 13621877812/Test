//
//  MyAnnoation.m
//  LessonMapKit
//
//  Created by lanouhn on 16/10/9.
//  Copyright © 2016年 lanouhn. All rights reserved.
//

#import "MyAnnoation.h"

@implementation MyAnnoation

@end
