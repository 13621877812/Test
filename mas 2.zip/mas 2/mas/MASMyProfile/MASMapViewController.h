//
//  MASMapViewController.h
//  mas
//
//  Created by cocoa on 2018/7/30.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASMapViewController : UIViewController
@property (nonatomic, copy)NSString *mylocation;

@end
