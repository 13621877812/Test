//
//  MASDBHandle.m
//  mas
//
//  Created by cocoa on 2018/7/26.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASDBHandle.h"
#import <MJHFoundation/NSString+MJHHelper.h>


static MASDBHandle *singleInstance=nil;

@implementation MASDBHandle

+(MASDBHandle *)shareMASDBHandle{
    @synchronized(self){
        if (singleInstance==nil) {
            singleInstance=[[self alloc] init];
        }
    }
    return singleInstance;
}


-(BOOL)insertAdminNo:(NSString *)adminNo andFirebaseToken:(NSString *)FirebaseToken {
    if([self searchAdminNo:adminNo]){
        if (![self openSQLite]) {
            return NO;
        }
        char *update = "update student set  FirebaseToken = ?  where adminNo = ?";
        
        char *errorMsg = NULL;
        sqlite3_stmt *stmt;
        
        if (sqlite3_prepare_v2(_database, update, -1, &stmt, nil) == SQLITE_OK) {
            
            //【插入数据】在这里我们使用绑定数据的方法，参数一：sqlite3_stmt，参数二：插入列号，参数三：插入的数据，参数四：数据长度（-1代表全部），参数五：是否需要回调
            sqlite3_bind_text(stmt, 1, [FirebaseToken UTF8String], -1, NULL);
            sqlite3_bind_text(stmt, 2, [adminNo UTF8String], -1, NULL);
        }
        if (sqlite3_step(stmt) != SQLITE_DONE) {
            NSLog(@"数据更新失败%s",errorMsg);
            return NO;
        }
        
        
        sqlite3_finalize(stmt);
        
        sqlite3_close(_database);
        return YES;
    }else{
        if (![self openSQLite]) {
            return NO;
        }
        char *update = "INSERT OR REPLACE INTO student(adminNo,FirebaseToken)""VALUES(?,?);";
        //上边的update也可以这样写：
        //NSString *insert = [NSString stringWithFormat:@"INSERT OR REPLACE INTO PERSIONINFO('%@','%@','%@','%@','%@')VALUES(?,?,?,?,?)",NAME,AGE,SEX,WEIGHT,ADDRESS];
        
        char *errorMsg = NULL;
        sqlite3_stmt *stmt;
        
        if (sqlite3_prepare_v2(_database, update, -1, &stmt, nil) == SQLITE_OK) {
            
            //【插入数据】在这里我们使用绑定数据的方法，参数一：sqlite3_stmt，参数二：插入列号，参数三：插入的数据，参数四：数据长度（-1代表全部），参数五：是否需要回调
            sqlite3_bind_text(stmt, 1, [adminNo UTF8String], -1, NULL);
            sqlite3_bind_text(stmt, 2, [FirebaseToken UTF8String], -1, NULL);
        }
        if (sqlite3_step(stmt) != SQLITE_DONE) {
            NSLog(@"数据更新失败%s",errorMsg);
            return NO;
        }
        
        
        sqlite3_finalize(stmt);
        
        sqlite3_close(_database);
        return YES;
    }
}

-(BOOL)searchAdminNo:(NSString *)adminNo {
    if (![self openSQLite]) {
        return NO;
    }
    BOOL isHave = NO;
    sqlite3_stmt *statement;
    NSString *sqlStr=[NSString stringWithFormat:@"SELECT * FROM student WHERE adminNo = '%@' " ,adminNo];
    int success = sqlite3_prepare_v2(_database, [sqlStr UTF8String], -1, &statement, nil);
    //如果result的值是SQLITE_OK，则表明准备好statement
    if (success != SQLITE_OK) {
        NSLog(@"查询历史记录时，statement准备失败");
        return NO;
    }
    //这个就是依次将每行的数据存在statement中，然后根据每行的字段取出数据
    while (sqlite3_step(statement) == SQLITE_ROW) {
        char *adminNo=(char *)sqlite3_column_text(statement,0);
        if(adminNo) {
            isHave = YES;
        }
    }
    
    //关闭数据库句柄
    sqlite3_finalize(statement);
    //关闭数据库
    sqlite3_close(_database);
    return isHave;
}


-(BOOL )insertTimeTable:(NSString *)imagePath {
    if (![self openSQLite]) {
        return NO;
    }
    
    char *update = "update student set  Image = ?  where adminNo = ?";
    
    char *errorMsg = NULL;
    sqlite3_stmt *stmt;
    
    if (sqlite3_prepare_v2(_database, update, -1, &stmt, nil) == SQLITE_OK) {
        
        //【插入数据】在这里我们使用绑定数据的方法，参数一：sqlite3_stmt，参数二：插入列号，参数三：插入的数据，参数四：数据长度（-1代表全部），参数五：是否需要回调
        sqlite3_bind_text(stmt, 1, [imagePath UTF8String], -1, NULL);
        sqlite3_bind_text(stmt, 2, [[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] UTF8String], -1, NULL);
    }
    if (sqlite3_step(stmt) != SQLITE_DONE) {
        NSLog(@"数据更新失败%s",errorMsg);
        return NO;
    }
    
    
    sqlite3_finalize(stmt);
    
    sqlite3_close(_database);
    return YES;
}

-(NSString *)searchTimeTable:(NSString *)adminNo {
    if (![self openSQLite]) {
        return nil;
    }
    NSString *timeTable;
    sqlite3_stmt *statement;
    NSString *sqlStr=[NSString stringWithFormat:@"SELECT image FROM student WHERE adminNo = '%@' " ,adminNo];
    int success = sqlite3_prepare_v2(_database, [sqlStr UTF8String], -1, &statement, nil);
    //如果result的值是SQLITE_OK，则表明准备好statement
    if (success != SQLITE_OK) {
        NSLog(@"查询历史记录时，statement准备失败");
        return nil;
    }
    //这个就是依次将每行的数据存在statement中，然后根据每行的字段取出数据
    while (sqlite3_step(statement) == SQLITE_ROW) {
        char *adminNo=(char *)sqlite3_column_text(statement, 0);
        if(adminNo) {
            timeTable = [NSString stringWithUTF8String:adminNo];
        }
    }
    
    //关闭数据库句柄
    sqlite3_finalize(statement);
    //关闭数据库
    sqlite3_close(_database);
    return timeTable;
    
}



-(BOOL )insertMyprofile:(NSString *)imagePath {
    if (![self openSQLite]) {
        return NO;
    }
    
    char *update = "update student set  myProfileUrl = ?  where adminNo = ?";
    
    char *errorMsg = NULL;
    sqlite3_stmt *stmt;
    
    if (sqlite3_prepare_v2(_database, update, -1, &stmt, nil) == SQLITE_OK) {
        
        //【插入数据】在这里我们使用绑定数据的方法，参数一：sqlite3_stmt，参数二：插入列号，参数三：插入的数据，参数四：数据长度（-1代表全部），参数五：是否需要回调
        sqlite3_bind_text(stmt, 1, [imagePath UTF8String], -1, NULL);
        sqlite3_bind_text(stmt, 2, [[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] UTF8String], -1, NULL);
    }
    if (sqlite3_step(stmt) != SQLITE_DONE) {
        NSLog(@"数据更新失败%s",errorMsg);
        return NO;
    }
    
    
    sqlite3_finalize(stmt);
    
    sqlite3_close(_database);
    return YES;
}

-(NSString *)searchMyprofile:(NSString *)adminNo {
    if (![self openSQLite]) {
        return nil;
    }
    NSString *timeTable;
    sqlite3_stmt *statement;
    NSString *sqlStr=[NSString stringWithFormat:@"SELECT myProfileUrl FROM student WHERE adminNo = '%@' " ,adminNo];
    int success = sqlite3_prepare_v2(_database, [sqlStr UTF8String], -1, &statement, nil);
    //如果result的值是SQLITE_OK，则表明准备好statement
    if (success != SQLITE_OK) {
        NSLog(@"查询历史记录时，statement准备失败");
        return nil;
    }
    //这个就是依次将每行的数据存在statement中，然后根据每行的字段取出数据
    while (sqlite3_step(statement) == SQLITE_ROW) {
        char *adminNo=(char *)sqlite3_column_text(statement, 0);
        if(adminNo) {
            timeTable = [NSString stringWithUTF8String:adminNo];
        }
    }
    
    //关闭数据库句柄
    sqlite3_finalize(statement);
    //关闭数据库
    sqlite3_close(_database);
    return timeTable;
    
}


-(BOOL )insertName:(NSString *)name {
    if (![self openSQLite]) {
        return NO;
    }
    
    char *update = "update student set  name = ?  where adminNo = ?";
    
    char *errorMsg = NULL;
    sqlite3_stmt *stmt;
    
    if (sqlite3_prepare_v2(_database, update, -1, &stmt, nil) == SQLITE_OK) {
        
        //【插入数据】在这里我们使用绑定数据的方法，参数一：sqlite3_stmt，参数二：插入列号，参数三：插入的数据，参数四：数据长度（-1代表全部），参数五：是否需要回调
        sqlite3_bind_text(stmt, 1, [name UTF8String], -1, NULL);
        sqlite3_bind_text(stmt, 2, [[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] UTF8String], -1, NULL);
    }
    if (sqlite3_step(stmt) != SQLITE_DONE) {
        NSLog(@"数据更新失败%s",errorMsg);
        return NO;
    }
    
    
    sqlite3_finalize(stmt);
    
    sqlite3_close(_database);
    return YES;
}

-(NSString *)searchName:(NSString *)adminNo {
    if (![self openSQLite]) {
        return nil;
    }
    NSString *timeTable;
    sqlite3_stmt *statement;
    NSString *sqlStr=[NSString stringWithFormat:@"SELECT name FROM student WHERE adminNo = '%@' " ,adminNo];
    int success = sqlite3_prepare_v2(_database, [sqlStr UTF8String], -1, &statement, nil);
    //如果result的值是SQLITE_OK，则表明准备好statement
    if (success != SQLITE_OK) {
        NSLog(@"查询历史记录时，statement准备失败");
        return nil;
    }
    //这个就是依次将每行的数据存在statement中，然后根据每行的字段取出数据
    while (sqlite3_step(statement) == SQLITE_ROW) {
        char *adminNo=(char *)sqlite3_column_text(statement, 0);
        if(adminNo) {
            timeTable = [NSString stringWithUTF8String:adminNo];
        }
    }
    
    //关闭数据库句柄
    sqlite3_finalize(statement);
    //关闭数据库
    sqlite3_close(_database);
    return timeTable;
    
}

-(BOOL )insertSCG:(NSString *)SCG {
    if (![self openSQLite]) {
        return NO;
    }
    
    char *update = "update student set  scg = ?  where adminNo = ?";
    
    char *errorMsg = NULL;
    sqlite3_stmt *stmt;
    
    if (sqlite3_prepare_v2(_database, update, -1, &stmt, nil) == SQLITE_OK) {
        
        //【插入数据】在这里我们使用绑定数据的方法，参数一：sqlite3_stmt，参数二：插入列号，参数三：插入的数据，参数四：数据长度（-1代表全部），参数五：是否需要回调
        sqlite3_bind_text(stmt, 1, [SCG UTF8String], -1, NULL);
        sqlite3_bind_text(stmt, 2, [[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] UTF8String], -1, NULL);
    }
    if (sqlite3_step(stmt) != SQLITE_DONE) {
        NSLog(@"数据更新失败%s",errorMsg);
        return NO;
    }
    
    
    sqlite3_finalize(stmt);
    
    sqlite3_close(_database);
    return YES;
}

-(NSString *)searchSCG:(NSString *)adminNo {
    if (![self openSQLite]) {
        return nil;
    }
    NSString *timeTable;
    sqlite3_stmt *statement;
    NSString *sqlStr=[NSString stringWithFormat:@"SELECT scg FROM student WHERE adminNo = '%@' " ,adminNo];
    int success = sqlite3_prepare_v2(_database, [sqlStr UTF8String], -1, &statement, nil);
    //如果result的值是SQLITE_OK，则表明准备好statement
    if (success != SQLITE_OK) {
        NSLog(@"查询历史记录时，statement准备失败");
        return nil;
    }
    //这个就是依次将每行的数据存在statement中，然后根据每行的字段取出数据
    while (sqlite3_step(statement) == SQLITE_ROW) {
        char *adminNo=(char *)sqlite3_column_text(statement, 0);
        if(adminNo) {
            timeTable = [NSString stringWithUTF8String:adminNo];
        }
    }
    
    //关闭数据库句柄
    sqlite3_finalize(statement);
    //关闭数据库
    sqlite3_close(_database);
    return timeTable;
    
}
-(BOOL)openSQLite{
    NSString *filePath = [NSString creatPathInDocuments:@"MAS.sqlite"];
    int result=sqlite3_open([filePath UTF8String], &_database);
    if (result!=SQLITE_OK) {
        NSLog(@"打开数据库失败");
        return NO;
    }
    
    return YES;
}

@end
