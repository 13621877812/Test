//
//  MASDBHandle.h
//  mas
//
//  Created by cocoa on 2018/7/26.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface MASDBHandle : NSObject
{
    //数据库对象
    sqlite3 *_database;
}
//d单例，创建一个数据库对象
+(MASDBHandle *)shareMASDBHandle;

//插入adminNo和FirebaseToekn，插入过程会先查询库中是否存在adminNo，如果存在则更新，不存在则直接插入。
-(BOOL )insertAdminNo:(NSString *)adminNo andFirebaseToken:(NSString *)FirebaseToken;


//插入timeTable中的图片路径
-(BOOL )insertTimeTable:(NSString *)imagePath;
//根据adminNo搜索timeTable图片路径，这里路径存的是相对路径，因为测试环境ios的app沙盒路径是会更改的。
-(NSString *)searchTimeTable:(NSString *)adminNo;


//插入Myprofile中的图片路径
-(BOOL )insertMyprofile:(NSString *)imagePath;
//根据adminNo搜索Myprofile图片路径，这里路径存的是相对路径，因为测试环境ios的app沙盒路径是会更改的。
-(NSString *)searchMyprofile:(NSString *)adminNo;



-(BOOL )insertName:(NSString *)name;
-(NSString *)searchName:(NSString *)adminNo;
-(BOOL )insertSCG:(NSString *)SCG;
-(NSString *)searchSCG:(NSString *)adminNo;
@end
