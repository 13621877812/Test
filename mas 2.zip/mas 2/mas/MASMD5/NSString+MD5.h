//
//  NSString+MD5.h
//  mas
//
//  Created by STUDENT on 5/8/18.
//  Copyright © 2018 mynews. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

- (NSString *)MD5String;

@end
