//
//  MASAboutInfoViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASAboutInfoViewController.h"
#import "MASSendEamilViewController.h"
@interface MASAboutInfoViewController ()

@end

@implementation MASAboutInfoViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //隐藏导航栏
    self.navigationController.navigationBar.hidden = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (IBAction)pushToPhone:(id)sender {
    NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"tel:%@",@"93799009"];
    UIWebView * callWebview = [[UIWebView alloc] init];
    [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
}

- (IBAction)pushToEmail:(id)sender {
    //跳转到发送email页面
    MASSendEamilViewController *controller = [[MASSendEamilViewController alloc] init];
    //获取当前application的跟控制器
    [(UINavigationController *)[UIApplication sharedApplication].keyWindow.rootViewController pushViewController:controller animated:YES];
}

- (IBAction)pushToWebsite:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.hjjangela.com/mass/"]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
