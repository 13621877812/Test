//
//  MASAboutViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASAboutViewController.h"
#import "MASAboutInfoViewController.h"
#import "MASSendEamilViewController.h"
@interface MASAboutViewController ()<UIScrollViewDelegate>
@property (nonatomic, strong) UIButton *backItem;
@property (nonatomic, weak) IBOutlet UIScrollView *scrollView;
@property (nonatomic, weak) IBOutlet UIPageControl *pageControl;

@end

@implementation MASAboutViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //隐藏导航栏
    self.navigationController.navigationBar.hidden = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置scrollview的内容尺寸
    self.scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width*5, [UIScreen mainScreen].bounds.size.height);
    //循环将scrollview中添加四个图片。
    NSArray *imageArray = @[@"about_page1",@"about_page2",@"about_page3",@"about_page4"];
    for (int i = 0; i < 4; i++) {
        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageArray[i]]];
        imageView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width*i, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
        imageView.backgroundColor = [UIColor colorWithRed:1 green:1 blue:50*i/255 alpha:1];
        [self.scrollView addSubview:imageView];
    }
    //设置下部页数控制器初始页数
    self.pageControl.currentPage = 0;
    self.scrollView.delaysContentTouches = NO;
}

- (void)touchHeaderImageView:(UITapGestureRecognizer *)gesture
{
    MASSendEamilViewController *controller = [[MASSendEamilViewController alloc] init];
    controller.content = @"Hello, developer";
    controller.email = @"160015Q@myemail.nyp.edu.sg";
    [(UINavigationController *)[UIApplication sharedApplication].keyWindow.rootViewController pushViewController:controller animated:YES];
}

- (void)touchPhone:(UITapGestureRecognizer *)gesture
{
    NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"tel:%@",@"93799009"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]  options:nil completionHandler:nil];
}

- (void)touchWebsite:(UITapGestureRecognizer *)gesture
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.hjjangela.com/mass/"]];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.view addSubview:self.backItem];
    //关于我的信息页
    MASAboutInfoViewController *controller = [[MASAboutInfoViewController alloc] init];
    controller.view.frame = CGRectMake([UIScreen mainScreen].bounds.size.width*4, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [self.scrollView addSubview:controller.view];
    
    UITapGestureRecognizer *tapName = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchHeaderImageView:)];
    controller.emailButton.userInteractionEnabled = YES;
    [controller.emailButton addGestureRecognizer:tapName];
    
    UITapGestureRecognizer *tapPhone = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchPhone:)];
    controller.phoneButton.userInteractionEnabled = YES;
    [controller.phoneButton addGestureRecognizer:tapPhone];
    
    UITapGestureRecognizer *tapWebsite = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchWebsite:)];
    controller.websiteButton.userInteractionEnabled = YES;
    [controller.websiteButton addGestureRecognizer:tapWebsite];
}

- (UIButton *)backItem
{
    if (!_backItem) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_action_back"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
        btn.frame = CGRectMake(20, 40, 30, 30);
        _backItem = btn;
    }
    return _backItem;
}

- (void)backAction {
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //ScrollView中根据滚动距离来判断当前页数
    int page = (int)scrollView.contentOffset.x/scrollView.frame.size.width;
    self.pageControl.currentPage = page;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
