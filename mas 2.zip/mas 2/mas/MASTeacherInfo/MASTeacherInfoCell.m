//
//  MASTeacherInfoCell.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASTeacherInfoCell.h"
@interface MASTeacherInfoCell()
@property (nonatomic, weak) IBOutlet UILabel *teacherLabel;
@property (nonatomic, weak) IBOutlet UILabel *moduleLabel;
@property (nonatomic, weak) IBOutlet UILabel *phoneLabel;
@property (nonatomic, weak) IBOutlet UILabel *emailLabel;
@property (nonatomic, weak) IBOutlet UIImageView *headImageView;

@end
@implementation MASTeacherInfoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setData:(NSDictionary *)dic {
    //设置cell的内容
    self.teacherLabel.text = [dic objectForKey:@"TeacherName"];
    self.moduleLabel.text = [dic objectForKey:@"ModuleName"];
    self.phoneLabel.text = [dic objectForKey:@"Phone"];
    self.emailLabel.text = [dic objectForKey:@"Email"];
    if([dic objectForKey:@"TeacherImage"]){
        NSString *str = [[[dic objectForKey:@"TeacherImage"] componentsSeparatedByString:@","] objectAtIndex:1];
        // 将base64字符串转为NSData
        NSData *decodeData = [[NSData alloc]initWithBase64EncodedString:str options:(NSDataBase64DecodingIgnoreUnknownCharacters)];
        self.headImageView.image = [UIImage imageWithData: decodeData];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
