//
//  MASTeacherInfoViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASTeacherInfoViewController.h"
#import "MASSlideView.h"
#import "MASTeacherInfoCell.h"
#import "MASSendEamilViewController.h"
#import "MASNewsViewController.h"
#import <MJHCategoriesHeader.h>
#import "AppDelegate.h"
@interface MASTeacherInfoViewController ()
@property (nonatomic, strong) UIBarButtonItem *sideItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;
@property (nonatomic, strong) UIBarButtonItem *rightSearchItem;
@property (nonatomic, strong) UIBarButtonItem *rightItem;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *tableViewTopConstraint;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@end

@implementation MASTeacherInfoViewController

bool hiddenFlag = true;
NSLayoutConstraint *changeTableViewTopConstraint;

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = NO;
    self.navigationItem.leftBarButtonItems = @[self.sideItem,self.titleItem];
    self.navigationItem.rightBarButtonItems = @[self.rightItem,self.rightSearchItem];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataArray = [NSMutableArray array];
    changeTableViewTopConstraint = [NSLayoutConstraint
                                    constraintWithItem:self.searchBar
                                    attribute:NSLayoutAttributeBottom
                                    relatedBy:NSLayoutRelationEqual
                                    toItem:self.tableView
                                    attribute:NSLayoutAttributeTop
                                    multiplier:1.0
                                    constant:0];
    [self loadData];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(nonnull NSString *)searchText {
    if(searchText.length == 0) {
        [self loadData];
    }
    else {
        [self filterData:searchText];
    }
}

- (void)filterData: (NSString *)searchText {
    //请求功能
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/teacherInfo.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"AdminNo"];
    [muParameterDic setObject:searchText forKey:@"SearchText"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if ([[responseObject objectForKey:@"status"] isEqualToString:@"OK"]) {
            NSMutableArray *tempArray = [NSMutableArray arrayWithArray:[responseObject allKeys]];
            [tempArray removeObject:@"status"];
            [tempArray sortUsingSelector:@selector(compare:)];
            [self.dataArray removeAllObjects];
            for (NSString *key in tempArray) {
                [self.dataArray addObject:[responseObject objectForKey:key]];
            }
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 150)];
            [SVProgressHUD showErrorAndDismiss:@"No records"];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 150)];
        [SVProgressHUD showErrorAndDismiss:@"Internet Error"];
    }];
}

- (void)loadData {
    //请求功能
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/teacherInfo.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"AdminNo"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if ([[responseObject objectForKey:@"status"] isEqualToString:@"OK"]) {
            NSMutableArray *tempArray = [NSMutableArray arrayWithArray:[responseObject allKeys]];
            [tempArray removeObject:@"status"];
            [tempArray sortUsingSelector:@selector(compare:)];
            for (NSString *key in tempArray) {
                [self.dataArray addObject:[responseObject objectForKey:key]];
            }
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
        }else{
            [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 150)];
            [SVProgressHUD showErrorAndDismiss:@"No records"];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD setOffsetFromCenter:UIOffsetMake(0, 150)];
        [SVProgressHUD showErrorAndDismiss:@"Internet Error"];
    }];
}

- (void)sideAction {
    [[MASSlideView shareYDSlideView] initSlideViewForView:self setString:@"160015Q" eamilString:@"160015Q@myemail.nyp.edu.sg"];
}

- (void)rightAction {
    MASNewsViewController *controller = [[MASNewsViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)rightSearchAction {
    
    if(hiddenFlag) {
        self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableViewTopConstraint.active = NO;
        changeTableViewTopConstraint.active = YES;
    }
    else {
        self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableViewTopConstraint.active = YES;
        changeTableViewTopConstraint.active = NO;
    }
    hiddenFlag = !hiddenFlag;
}

- (UIBarButtonItem *)sideItem
{
    if (!_sideItem) {
        _sideItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_side"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(sideAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        btn.frame = CGRectMake(0, 0, 30, 30);
        _sideItem.customView = btn;
    }
    return _sideItem;
}

- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @"    Timetable";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:25]];
        label.frame = CGRectMake(50, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}

- (UIBarButtonItem *)rightItem
{
    if (!_rightItem) {
        _rightItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_alarm_icon"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(rightAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.frame = CGRectMake(0, 0, 30, 30);
        _rightItem.customView = btn;
    }
    return _rightItem;
}


- (UIBarButtonItem *)rightSearchItem
{
    if (!_rightSearchItem) {
        _rightSearchItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_search_icon"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(rightSearchAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.frame = CGRectMake(0, 0, 30, 30);
        _rightSearchItem.customView = btn;
    }
    return _rightSearchItem;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark
//返回tableview行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}
//加载tableview内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MASTeacherInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"markCell"];
    if (!cell) {
        //从本地获取cell的样式
        cell = [[[NSBundle mainBundle] loadNibNamed:@"MASTeacherInfoCell" owner:self options:nil] objectAtIndex:0];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [cell setData:[self.dataArray objectAtIndex:indexPath.row]];
    
    return cell;
}
//返回高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 75;
}

//设置tableView的cell可编辑
- (NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewRowAction *editAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDefault title:@"             " handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
        NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
        MASSendEamilViewController *controller = [[MASSendEamilViewController alloc] init];
        controller.content = [NSString stringWithFormat:@"Hello, %@",[dic objectForKey:@"TeacherName"]];
        controller.email = [NSString stringWithFormat:@"%@",[dic objectForKey:@"Email"]];
        [self.navigationController pushViewController:controller animated:YES];
        NSLog(@"点击了邮件");
        // 收回侧滑
        [tableView setEditing:NO animated:YES];
    }];
    UIImage *image1 = [UIImage imageNamed:@"ic_email1"];
    editAction.backgroundColor = [UIColor colorWithPatternImage:image1];
    
    UITableViewRowAction *deleteAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDefault title:@"              " handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
        NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"tel:%@",[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"Phone"]];
        UIWebView * callWebview = [[UIWebView alloc] init];
        [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
        [self.view addSubview:callWebview];
        NSLog(@"点击了电话");
        // 收回侧滑
        [tableView setEditing:NO animated:YES];
    }];
    UIImage *image2 = [UIImage imageNamed:@"ic_contact1"];
    deleteAction.backgroundColor = [UIColor colorWithPatternImage:image2];
    
    NSLog(@"%@",editAction);
    return @[deleteAction, editAction];
}

@end
