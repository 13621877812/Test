//
//  MASSendEamilViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASSendEamilViewController.h"

@interface MASSendEamilViewController ()
@property (nonatomic, strong) UIBarButtonItem *sideItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;
@property (nonatomic, weak) IBOutlet UITextField *textFieldcontent;
@property (nonatomic, weak) IBOutlet UITextField *textFieldEmail;

@property (nonatomic, weak) IBOutlet UITextField *textFieldSubject;

@end

@implementation MASSendEamilViewController
- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = NO;
    self.navigationItem.leftBarButtonItems = @[self.sideItem,self.titleItem];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.textFieldEmail.text = self.email;
    self.textFieldcontent.text = self.content;
}
- (UIBarButtonItem *)sideItem
{
    if (!_sideItem) {
        _sideItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:@"ic_action_back"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(sideAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        btn.frame = CGRectMake(0, 0, 30, 30);
        _sideItem.customView = btn;
    }
    return _sideItem;
}

- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @"    Send Email";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:22]];
        label.frame = CGRectMake(50, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}

- (void)sideAction {
    [self.navigationController popViewControllerAnimated:YES];
}


- (IBAction)sendEmail:(id)sender {
    NSString *adminNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"adminNo"];
    NSString *mail = [NSString stringWithFormat:@"%@@mymail.nyp.edu.sg",adminNo];
    //创建可变的地址字符串对象
    NSMutableString *mailUrl = [[NSMutableString alloc] init];
    //添加收件人,如有多个收件人，可以使用componentsJoinedByString方法连接，连接符为","
    [mailUrl appendFormat:@"mailto:%@?", self.textFieldEmail.text];
    //添加邮件主题
    [mailUrl appendFormat:@"&subject=%@",[NSString stringWithFormat:@"%@",self.textFieldSubject.text]];
    //添加邮件内容
    [mailUrl appendString:[self.textFieldcontent.text isEqualToString:@""]?@"&body=<b>Hello</b> World!":[NSString stringWithFormat:@"&body=%@",self.textFieldcontent.text]];
    //跳转到系统邮件App发送邮件
    NSString *emailPath = [mailUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:emailPath] options:@{} completionHandler:nil];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
