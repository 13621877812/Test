//
//  MASNewsViewController.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASNewsViewController.h"
#import "MASNewsViewCell.h"
#import <MJHCategoriesHeader.h>
#import "AppDelegate.h"
@interface MASNewsViewController ()
@property (nonatomic, strong) UIBarButtonItem *sideItem;
@property (nonatomic, strong) UIBarButtonItem *titleItem;
    
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, weak) IBOutlet UITableView *tableView;

@end

@implementation MASNewsViewController
- (void)viewWillAppear:(BOOL)animated {
    //取消隐藏导航栏
    self.navigationController.navigationBar.hidden = NO;
    //加载左侧的按钮和title
    self.navigationItem.leftBarButtonItems = @[self.sideItem,self.titleItem];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataArray = [NSMutableArray array];
    //加载网络数据
    [self loadData];
}

- (void)loadData {
    //从接口请求数据
    NSString *urlString = [NSString stringWithFormat:@"http://%@/MAS/App/latestNews.php",SERVER_URL_IP];
    NSMutableDictionary *muParameterDic = [NSMutableDictionary dictionary];
    [muParameterDic setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"adminNo"] forKey:@"AdminNo"];
    [[MJHAFNetworking shareMJHAFNetworking]MJHPost:[urlString stringToUTF8String] parameter: muParameterDic  timeOutInterval:30 success:^(NSURLSessionDataTask *task, id responseObject) {
        if ([[responseObject objectForKey:@"status"] isEqualToString:@"OK"]) {
            NSMutableArray *tempArray = [NSMutableArray arrayWithArray:[responseObject allKeys]];
            [tempArray removeObject:@"status"];
            [tempArray sortUsingSelector:@selector(compare:)];
            for (NSString *key in tempArray) {
                [self.dataArray addObject:[responseObject objectForKey:key]];
            }
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
        }else{
            [SVProgressHUD showErrorAndDismiss:[NSString stringWithFormat:@"%@",responseObject]];
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [SVProgressHUD showErrorAndDismiss:@"网络错误"];
    }];
}
 
  //左侧返回按钮
- (UIBarButtonItem *)sideItem
{
    if (!_sideItem) {
        _sideItem = [[UIBarButtonItem alloc] init];
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        //这是一张“<”的图片，可以让美工给切一张
        UIImage *image = [UIImage imageNamed:@"ic_action_back"];
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(sideAction) forControlEvents:UIControlEventTouchUpInside];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:17]];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //字体的多少为btn的大小
        [btn sizeToFit];
        //左对齐
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        //让返回按钮内容继续向左边偏移15，如果不设置的话，就会发现返回按钮离屏幕的左边的距离有点儿大，不美观
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        btn.frame = CGRectMake(0, 0, 30, 30);
        _sideItem.customView = btn;
    }
    return _sideItem;
}
//左侧title按钮
- (UIBarButtonItem *)titleItem
{
    if (!_titleItem) {
        _titleItem = [[UIBarButtonItem alloc] init];
        UILabel *label = [[UILabel alloc] init];
        label.text = @"    Latest News";
        label.textColor = [UIColor blackColor];
        [label setFont:[UIFont systemFontOfSize:25]];
        label.frame = CGRectMake(50, 0, 100, 30);
        _titleItem.customView = label;
    }
    return _titleItem;
}

//返回方法
- (void)sideAction {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark
//tableview返回行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}
//tableview加载cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MASNewsViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"markCell"];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"MASNewsViewCell" owner:self options:nil] objectAtIndex:0];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    //加载数据，放在cell中进行
    [cell setData:[self.dataArray objectAtIndex:indexPath.row]];
    return cell;
}
//返回cell高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
