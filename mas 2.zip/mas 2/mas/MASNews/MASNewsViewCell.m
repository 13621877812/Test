//
//  MASNewsViewCell.m
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import "MASNewsViewCell.h"

@interface MASNewsViewCell()
    
@property (nonatomic, weak) IBOutlet UILabel *moduleNameLabel;
@property (nonatomic, weak) IBOutlet UILabel *contentLabel;
@property (nonatomic, weak) IBOutlet UILabel *timeStampLabel;

@end

@implementation MASNewsViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
//加载I数据
- (void)setData:(NSDictionary *)dic {
    self.moduleNameLabel.text = [dic objectForKey:@"ModuleName"];
    self.contentLabel.text = [dic objectForKey:@"Content"];
    self.timeStampLabel.text = [dic objectForKey:@"TimeStamp"];
}
    
    
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
