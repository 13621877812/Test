//
//  MASSendEamilViewController.h
//  mas
//
//  Created by cocoa on 2018/7/16.
//  Copyright © 2018年 mynews. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASSendEamilViewController : UIViewController
@property (nonatomic, copy) NSString  *content;
@property (nonatomic, copy)  NSString *email;

@end
