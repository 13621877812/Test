//
//  DHLaunchDfPageHUD.m
//  DHLaunchDfPageHUDExample
//
//  Created by Apple on 16/8/24.
//  Copyright © 2016年 dingding3w. All rights reserved.
//

#import "DHLaunchDfPageHUD.h"

@interface DHLaunchDfPageHUD ()
@property (nonatomic, strong) UIButton          *skipButton;        /**< 跳过按钮 */
@property (nonatomic, strong) dispatch_source_t timer;              /**< 设置定时器 */
@end

@implementation DHLaunchDfPageHUD
static UIImageView *imageView;
- (void)initWithFrame:(CGRect)frame window:(UIWindow *)window image:(UIImage *)image animationStyle:(DDLaunchPageAnimationStyle)style {
    imageView = [[UIImageView alloc] initWithFrame:frame];
    [imageView setImage:image];
    [window.rootViewController.view addSubview:imageView];
    if (!style) {
        [DHAnimationOperation dh_setLaunchPageAnimationStyle:DDLaunchPageAnimationStyleFadeOut window:window imageView:imageView];
    } else {
        [DHAnimationOperation dh_setLaunchPageAnimationStyle:style window:window imageView:imageView];
    }
    [[UIApplication sharedApplication].keyWindow addSubview:self.setUpSkipButton];

}


#pragma mark - 设置跳过按钮
- (UIButton *)setUpSkipButton {
    if (self.skipButton == nil) {
        self.skipButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.skipButton setFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-130, 30, 120, 35)];
        [self.skipButton setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.4]];
        [self.skipButton.layer setCornerRadius:15.0];
        [self.skipButton.layer setMasksToBounds:YES];
        NSInteger duration = 4.0;/**< 默认停留时间 */
        [self.skipButton setTitle:[NSString stringWithFormat:@"%lds丨Click to Skip", duration] forState:UIControlStateNormal];
        [self.skipButton.titleLabel setFont:[UIFont systemFontOfSize:13.5]];
        [self.skipButton addTarget:self action:@selector(skipButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [self dispath_timer];
    }
    return self.skipButton;
}

- (void)dispath_timer {
    NSTimeInterval period = 1.0;/**< 每秒执行 */
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    self.timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_source_set_timer(self.timer, dispatch_walltime(NULL, 0), period*NSEC_PER_SEC, 0);
    
    __block NSInteger duration = 4.0;
    
    
    dispatch_source_set_event_handler(self.timer, ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            duration--;
            if (duration > -1) {
                [self.skipButton setTitle:[NSString stringWithFormat:@"%lds丨Click to Skip", duration] forState:UIControlStateNormal];
                if (duration == 1) {
                    [self removeSkipButton];
                }
                
            } else {
                [self removeLaunchAdPageHUD];
                dispatch_source_cancel(self.timer);
            }
        });
    });
    dispatch_resume(self.timer);
}

- (void)skipButtonClick {
    [self removeLaunchAdPageHUD];
}

- (void)removeLaunchAdPageHUD {
    [UIView animateWithDuration:0.8 animations:^{
        [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
        imageView.alpha = 0.0;
        self.setUpSkipButton.alpha = 0.0;
    } completion:^(BOOL finished) {
        [imageView removeFromSuperview];
        [self.setUpSkipButton removeFromSuperview];
    }];
}
- (void)removeSkipButton {
    [UIView animateWithDuration:1 animations:^{
        [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
        self.setUpSkipButton.alpha = 0.0;
    } completion:^(BOOL finished) {
        [self.setUpSkipButton removeFromSuperview];
    }];
}


@end
