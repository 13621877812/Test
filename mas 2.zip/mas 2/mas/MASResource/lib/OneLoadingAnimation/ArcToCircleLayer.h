//
//  OneLoadingAnimation.h
//  OneLoadingAnimationStep1
//
//  Created by thatsoul on 15/11/15.
//  Copyright (c) 2015年 chenms.m2. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

@interface ArcToCircleLayer : CALayer
@property (nonatomic) CGFloat progress;
@end
