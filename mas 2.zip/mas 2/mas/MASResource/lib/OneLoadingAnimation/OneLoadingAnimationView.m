//
//  OneLoadingAnimation.m
//  OneLoadingAnimationStep1
//
//  Created by thatsoul on 15/11/15.
//  Copyright © 2015年 chenms.m2. All rights reserved.
//

#import "OneLoadingAnimationView.h"
#import "ArcToCircleLayer.h"

static CGFloat const kRadius = 25;
static CGFloat const kLineWidth = 10;
static CGFloat const kStep1Duration = 2;

@interface OneLoadingAnimationView ()<CAAnimationDelegate>
@property (nonatomic) ArcToCircleLayer *arcToCircleLayer;
@end

@implementation OneLoadingAnimationView

- (void)awakeFromNib {
    [super awakeFromNib];
}

#pragma mark - public
- (void)startAnimation {
    [self reset];
    [self doStep1];
}

#pragma mark - animation
- (void)reset {
    [self.arcToCircleLayer removeFromSuperlayer];
}

- (void)doStep1 {
    self.arcToCircleLayer = [ArcToCircleLayer layer];
    self.arcToCircleLayer.contentsScale = [UIScreen mainScreen].scale;
    [self.layer addSublayer:self.arcToCircleLayer];

    self.arcToCircleLayer.bounds = CGRectMake(0, 0, kRadius * 2 + kLineWidth, kRadius * 2 + kLineWidth);
    self.arcToCircleLayer.position = CGPointMake(CGRectGetMidX([UIScreen mainScreen].bounds), CGRectGetMidY([UIScreen mainScreen].bounds));

    // animation
    self.arcToCircleLayer.progress = 0.0; // end status

    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"progress"];
    animation.delegate = self;
    animation.duration = kStep1Duration;
    animation.fromValue = @0.8;
    animation.toValue = @0.0;
    animation.removedOnCompletion= NO;
    [self.arcToCircleLayer addAnimation:animation forKey:nil];
}

#pragma mark -CAAnimationDelegate
- (void)animationDidStart:(CAAnimation *)anim
{
    NSLog(@"animationDidStart%@",self.layer.animationKeys);
    
}
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"loadingEnd" object:nil];
    [self removeFromSuperview];
}


@end
