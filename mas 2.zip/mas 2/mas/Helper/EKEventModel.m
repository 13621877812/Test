//
//  EKEventModel.m
//  product1
//
//  Created by 西安旺豆电子 on 2017/5/11.
//  Copyright © 2017年 西安旺豆电子信息有限公司. All rights reserved.
//

#import "EKEventModel.h"

@implementation EKEventModel

@end
