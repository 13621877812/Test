//
//  BluetoothHelper.m
//  蓝牙4.0Demo
//
//  Created by sun on 2018/7/31.
//  Copyright © 2018年 lby. All rights reserved.
//

#import "BluetoothHelper.h"

@interface BluetoothHelper()<CBCentralManagerDelegate,CBPeripheralDelegate>

// 存储的设备
@property (nonatomic, strong) NSMutableArray *peripherals;
// 扫描到的设备
@property (nonatomic, strong) CBPeripheral *cbPeripheral;
// 蓝牙状态
@property (nonatomic, assign) CBManagerState peripheralState;

//用于蓝牙状态回调
@property(nonatomic,copy)void(^stateBlock)(BOOL isAvailable);
@end


@implementation BluetoothHelper
+(instancetype)helper
{
    static BluetoothHelper *helper;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        helper = [[BluetoothHelper alloc]init];
    });
    helper.centralManager = nil;
    [helper centralManager];
    return helper;
}

// 扫描设备
- (void)scanForPeripherals:(void(^)(BOOL isAvailable))stateBlock
{
    self.stateBlock = stateBlock;
    [self.centralManager stopScan];
    [self.peripherals removeAllObjects];
    NSLog(@"扫描设备");
    
    NSLog(@"%ld", (long)self.peripheralState);
    NSLog(@"%ld", (long)CBManagerStatePoweredOn);
    if (self.peripheralState ==  CBManagerStatePoweredOn)
    {
        [self.centralManager scanForPeripheralsWithServices:nil options:@{CBCentralManagerOptionShowPowerAlertKey:@1}];
    }
}
-(void)clearForPeripherals
{
    NSLog(@"清空设备");
    [self.peripherals removeAllObjects];
    
    
}
// 状态更新时调用
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    switch (central.state) {
        case CBManagerStateUnknown:{
            NSLog(@"为知状态");
            if (self.stateBlock) {
                self.stateBlock(NO);
            }
            self.peripheralState = central.state;
        }
            break;
        case CBManagerStateResetting:
        {
            NSLog(@"重置状态");
            if (self.stateBlock) {
                self.stateBlock(NO);
            }
            self.peripheralState = central.state;
        }
            break;
        case CBManagerStateUnsupported:
        {
            NSLog(@"不支持的状态");
            if (self.stateBlock) {
                self.stateBlock(NO);
            }
            self.peripheralState = central.state;
        }
            break;
        case CBManagerStateUnauthorized:
        {
            NSLog(@"未授权的状态");
            if (self.stateBlock) {
                self.stateBlock(NO);
            }
            self.peripheralState = central.state;
        }
            break;
        case CBManagerStatePoweredOff:
        {
            NSLog(@"关闭状态");
            if (self.stateBlock) {
                self.stateBlock(NO);
            }
            self.peripheralState = central.state;
        }
            break;
        case CBManagerStatePoweredOn:
        {
            NSLog(@"开启状态－可用状态");
            self.peripheralState = central.state;
            if (self.stateBlock) {
                self.stateBlock(YES);
            }
            
            [self scanForPeripherals:nil];
            
            NSLog(@"%ld",(long)self.peripheralState);
        }
            break;
        default:
            break;
    }
}
/**
 扫描到设备
 
 @param central 中心管理者
 @param peripheral 扫描到的设备
 @param advertisementData 广告信息
 @param RSSI 信号强度
 */
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI
{
    
    
    if (![self.peripherals containsObject:peripheral])
    {
        [self.peripherals addObject:peripheral];
        NSLog(@"%@",peripheral);
    }
}

- (NSMutableArray *)peripherals
{
    if (!_peripherals) {
        _peripherals = [NSMutableArray array];
    }
    return _peripherals;
}
- (CBCentralManager *)centralManager
{
    if (_centralManager==nil) {
        _centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil options:@{CBCentralManagerOptionShowPowerAlertKey:@1}];
    }
    
    
    return _centralManager;
}
-(NSString *)devices
{
    NSMutableArray *array = [NSMutableArray array];
    NSString *names = @"";
    for (CBPeripheral *peripheral  in self.peripherals) {
        if (peripheral.name == nil) {
            continue;
        }
        if ([array containsObject:peripheral.name]) {
            continue;
        }
        
        [array addObject:peripheral.name];
    }
    
    
    for (int i=0;i< array.count; i++)  {
        if (i == array.count-1) {
            names = [NSString stringWithFormat:@"%@",array[i]];
        }else
        {
            names = [NSString stringWithFormat:@"%@,",array[i]];
        }
        NSLog(@"%@", names);
        
    }
    return  names;
}
@end
