//
//  BluetoothHelper.h
//  蓝牙4.0Demo
//
//  Created by sun on 2018/7/31.
//  Copyright © 2018年 lby. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
@interface BluetoothHelper : NSObject
@property(nonatomic,copy)NSString *devices;
/// 中央管理者 -->管理设备的扫描 --连接
@property (nonatomic, strong) CBCentralManager *centralManager;
+(instancetype)helper;
- (void)scanForPeripherals:(void(^)(BOOL isAvailable))stateBlock;
@end
