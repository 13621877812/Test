//
//  PhotoHelper.m
//  tooth
//
//  Created by fpm0259 on 2018/7/31.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "PhotoHelper.h"
@interface PhotoHelper()<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property(nonatomic,copy)void(^imageBlock)(NSData *imageData,NSString *imageName);
@property(nonatomic,strong)UIViewController *viewController;
@end

@implementation PhotoHelper
+(instancetype)helper
{
    static PhotoHelper *helper;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        helper = [[PhotoHelper alloc]init];
    });
    return helper;
}
-(void)choosePhotosWithViewController:(UIViewController *)viewController imageBlock:(void(^)(NSData *imageData,NSString *imageName))imageBlock
{
    self.imageBlock = imageBlock;
    self.viewController = viewController;
    // 跳转到相机或相册页面
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    
    imagePickerController.delegate = self;
    imagePickerController.editing = YES;
    imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    
    
    [self.viewController presentViewController:imagePickerController animated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    // 显示正在上传
    [picker dismissViewControllerAnimated:YES completion:^{
        
        // 得到图片
        // UIImage * image = info[UIImagePickerControllerEditedImage];
        UIImage * image = info[UIImagePickerControllerOriginalImage];
        // 压缩图片
        image = [self imageWithImage:image scaledToSize:CGSizeMake(200, 300)];
        
        NSData *data = UIImageJPEGRepresentation(image, 0.5);
        
        
        NSString *name =[NSString stringWithFormat:@"%0.f",[[NSDate date] timeIntervalSince1970]];
        
        if (self.imageBlock) {
            self.imageBlock(data,name);
        }
    }];
    
}
-(UIImage*)imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize
{
    // Create a graphics image context
    UIGraphicsBeginImageContext(newSize);
    
    // Tell the old image to draw in this new context, with the desired
    // new size
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    
    // Get the new image from the context
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // End the context
    UIGraphicsEndImageContext();
    
    // Return the new image.
    return newImage;
}
@end
