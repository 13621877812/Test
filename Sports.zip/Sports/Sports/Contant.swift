//
//  Contant.swift
//  Running
//
//  Created by eden on 2018/10/28.
//  Copyright © 2018年 eden. All rights reserved.
//

import Foundation

let WIDTH = UIScreen.main.bounds.size.width;
let HEIGHT = UIScreen.main.bounds.size.height;
func showToast(title:String) {
    let hud:MBProgressHUD = MBProgressHUD.showAdded(to: UIApplication.shared.keyWindow, animated: true)
    hud.mode = .text
    hud.labelText = title
    hud.hide(true, afterDelay: 1)
    
}

