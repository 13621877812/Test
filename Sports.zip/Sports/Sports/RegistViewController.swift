//
//  RegistViewController.swift
//  Running
//
//  Created by eden on 2018/10/28.
//  Copyright © 2018年 eden. All rights reserved.
//

import UIKit

class RegistViewController: UIViewController {

    @IBOutlet weak var accountTextField: MyTextField!
    
    @IBOutlet weak var passwordTextField: MyTextField!
    
    @IBOutlet weak var confirmPasswordTextField: MyTextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.accountTextField.leftImage =  UIImage.init(named: "userIcon")!;
        self.passwordTextField.leftImage = UIImage.init(named: "passwordIcon")!;
        self.confirmPasswordTextField.leftImage = UIImage.init(named: "passwordIcon")!;
        self.passwordTextField.clearButtonMode = .always;
       
    }
    
    @IBAction func registClick(_ sender: Any) {
        if (self.accountTextField.text?.isEmpty)! {
            showToast(title: "userName is Empty!");
            return;
        }
        if (self.passwordTextField.text?.isEmpty)! {
            showToast(title: "password is Empty!");
            return;
        }
        if (self.confirmPasswordTextField.text?.isEmpty)! {
            showToast(title: "confirmPassword is Empty!");
            return;
        }
        if self.confirmPasswordTextField.text != self.passwordTextField.text {
            showToast(title: "confirmPassword is not equal password!");
            return;
        }
        BmobManager().getUser(self.accountTextField.text ?? " ") { (users) in
            if users.count == 0
            {
            BmobManager().registerUser(self.accountTextField.text ?? " ", password: self.passwordTextField.text ?? " ");
                 showToast(title: "regist success!");
                self.navigationController?.popViewController(animated: true)
            }else
            {
                  showToast(title: "user is already exist!");
            }
        }
        
        
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
