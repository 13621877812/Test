//
//  LoginViewController.swift
//  Running
//
//  Created by eden on 2018/10/28.
//  Copyright © 2018年 eden. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    
    @IBOutlet weak var accountTextField: MyTextField!
    
    @IBOutlet weak var passwordTextField: MyTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.accountTextField.leftImage =  UIImage.init(named: "userIcon")!;
       
       
        self.passwordTextField.leftImage = UIImage.init(named: "passwordIcon")!;
        
        self.passwordTextField.clearButtonMode = .always;
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func loginClick(_ sender: Any) {
        if (self.accountTextField.text?.isEmpty)! {
            showToast(title: "userName is Empty!");
            return;
        }
        if (self.passwordTextField.text?.isEmpty)! {
            showToast(title: "password is Empty!");
            return;
        }
        
     BmobManager().getUser(self.accountTextField.text ?? " ") { (users) in
            if(users.count == 0){
                showToast(title: "user is not exist!");
            }else{
                let user:BmobObject = users.first as! BmobObject;
                
                print(user.object(forKey: "userName"));
                
                
                if (user.object(forKey: "password")as? String == self.passwordTextField.text){
                    
                    UserDefaults.standard.setValue(user.objectId, forKey: "userId");
                    UserDefaults.standard.synchronize();
                    
                    UserDefaults.standard.setValue(self.accountTextField.text, forKey: "userName");
                    UserDefaults.standard.synchronize();
                    
                
                    let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil);
                    let main:MainController = storyBoard.instantiateViewController(withIdentifier: "MainController") as! MainController;
                    self.navigationController?.pushViewController(main, animated: true);
                    showToast(title: "login success!");
                }else
                {
                   showToast(title: "password is error!");
                }
                
                
               
                
                
                
            }
        }
       
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
