//
//  TimeViewController.swift
//  Sports
//
//  Created by sun on 2018/11/3.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class TimeViewController: UIViewController,UITableViewDataSource {

    var sport:BmobObject?
    var dataArray:Array<Any>?
    var occupiedTimes:[String]?
    @IBOutlet weak var timeTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.requestData();
       

        // Do any additional setup after loading the view.
    }
    func requestData() {
        BmobManager().getMyOccupiedTimeId { (occupiedTimes, userObject) in
            self.occupiedTimes = occupiedTimes[self.sport?.object(forKey: "objectId")as! String] as! [String];
            BmobManager().getTimes { (datas) in
                self.dataArray = datas;
                self.timeTableView.reloadData();
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataArray?.count ?? 0;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let model:BmobObject = dataArray?[indexPath.row] as! BmobObject;
        let cell:TimeCell = tableView.dequeueReusableCell(withIdentifier: "TimeCell") as! TimeCell;
        cell.timeLab.text = model.object(forKey: "time") as! String;
        cell.actionBtn.addTarget(self, action:#selector(btnClick(_:)), for:.touchUpInside)
        cell.actionBtn.tag = indexPath.row + 1;
        let state:Int = self.getState(model.object(forKey: "objectId") as! String);
        if state == 0 {
            cell.actionBtn.alpha = 1;
            cell.stateLab.text = "可利用";
        }else if(state == 1){
            cell.actionBtn.alpha = 1;
            cell.stateLab.text = "自己占用";
        }else{
            cell.actionBtn.alpha = 0;
            cell.stateLab.text = "别人占用";
        }

        return cell;
        
    }
    func getState(_ timeId:String)->Int {
        //返回状态  0 空的  1 自己占用  2  被别人占用
        let sportOccupiedTimes:[String] = self.sport?.object(forKey: "occupiedTime") as! [String];
        if sportOccupiedTimes.contains(timeId) {
            //占有
            
            if self.occupiedTimes!.contains(timeId){
                return 1;
            }
            return 2;
            
        }
        return 0;
    
    }
    @objc func btnClick(_ button:UIButton) {
       let model:BmobObject = dataArray?[button.tag - 1] as! BmobObject;
       let timeId = model.value(forKey: "objectId") as! String;
        let sportId = self.sport?.value(forKey: "objectId") as! String;
       //给sport 加上不可用状态
        BmobManager().updateTimes(timeId, sportId: sportId)
        //更新自己占有的
        BmobManager().updateTimes(timeId, sportId: sportId);
        sleep(UInt32(0.5));
        self.requestData();
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
