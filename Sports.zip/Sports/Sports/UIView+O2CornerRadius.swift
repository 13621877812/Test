//
//  UIView+CornerRadius.swift
//  OrderMenu
//
//  Created by  on 2018/7/21.
//  Copyright © 2018年 . All rights reserved.
//

import UIKit
extension UIView {
    @IBInspectable var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        // also  set(newValue)
        set {
            layer.cornerRadius = newValue
        }
    }
    @IBInspectable var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        // also  set(newValue)
        set {
            layer.borderWidth = newValue
        }
    }
    @IBInspectable var borderColor: CGColor {
        get {
            return layer.borderColor!
        }
        // also  set(newValue)
        set {
            layer.borderColor = newValue
        }
    }
}


