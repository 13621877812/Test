//
//  ItemCell.swift
//  Sports
//
//  Created by sun on 2018/11/3.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class ItemCell: UICollectionViewCell {
    @IBOutlet weak var nameLab: UILabel!
    
}
