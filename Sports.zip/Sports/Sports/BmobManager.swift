//
//  BmobManager.swift
//  Running
//
//  Created by eden on 2018/10/28.
//  Copyright © 2018年 eden. All rights reserved.
//

import UIKit

class BmobManager: NSObject {
    
    func registerUser(_ userName:String,password:String){
        //注册用户
        let object:BmobObject = BmobObject.init(outDataWithClassName: "User", objectId: "objectId");
        object.setObject(userName, forKey: "userName");
         object.setObject(password, forKey: "password");
        let dataA:[String:Any] =  [String:Any]();
        
        
        object.setObject("[]", forKey: "occupiedSport");
        
        object.saveInBackground { (isSuccess, error) in
            if((error) != nil){
                print("success");
            }else{
                print("error");
            }
        }
    }
    func getUser(_ userName:String,objectBlock:@escaping ((_ data:Array<Any>)->())){
        //查找GameScore表
        let bquery:BmobQuery = BmobQuery.init(className: "User");
        bquery.whereKey("userName", equalTo: userName);
        bquery.findObjectsInBackground { (data, error) in
            objectBlock(data ?? Array.init());
        }
    }
    func uploadData(_ timeId:String,sportId:String){
        self.getMyOccupiedTimeId { (datas, userObject) in
            var dataArray:[String:Any] = datas;
            var myTimeIds:[String] = [String]();
            if let timeids:[String] = dataArray[sportId] as! [String]{
               myTimeIds = timeids;
            }
            myTimeIds.append(timeId);
            dataArray.updateValue(myTimeIds, forKey: sportId);
            guard let uploadData = try? JSONSerialization.data(withJSONObject: dataArray, options: .prettyPrinted),
                let jsonText = String(data: uploadData, encoding: .utf8) else{
                                    fatalError("`JSON Object Encode Failed`")
                }
            print(jsonText)
            userObject.setObject(jsonText, forKey: "occupiedSport");
            userObject.updateInBackground();
        }
                

    }
    
    func getMyOccupiedTimeId(_ objectBlock:@escaping ((_ data:[String:Any],_ user:BmobObject)->())) {
        let userId = UserDefaults.standard.value(forKey: "userId") as! String;
        
        let bquery:BmobQuery = BmobQuery.init(className: "User");
        //查找GameScore表里面id为0c6db13c的数据
        bquery.getObjectInBackground(withId: userId) { (user, error) in
            if let errors = error{
                
            }else{
                
                let occupiedData:String = user?.object(forKey: "occupiedSport") as! String;
                guard let data = try? occupiedData.data(using: String.Encoding.utf8),
                    var dataArray:[String:Any] = try!JSONSerialization.jsonObject(with: data!, options:.mutableContainers) as? [String : Any]else{
                        fatalError("`JSON Object Encode Failed`")
                }
                objectBlock(dataArray,user!);
             
            }
        }
    }
  
    
    
 //add sports
    func addSports() {
        let sports:[String] = ["篮球","皮胖","足球","排球","铅球"];
        for name in sports{
            let index = sports.firstIndex(of: name);
            let indexStr = String.init(format: "%d", index ?? 0);
            let object:BmobObject = BmobObject.init(outDataWithClassName: "Sport", objectId: "objectId");
            object.setObject(name, forKey: "name");
            object.setObject(indexStr, forKey: "index");
            object.setObject([], forKey: "occupiedTime");
            object.saveInBackground();
        }
        
        
    }
    //get
    func getSports(_ objectBlock:@escaping ((_ data:Array<Any>)->())) {
       
        
        let bquery:BmobQuery = BmobQuery.init(className: "Sport");
        bquery.order(byAscending: "index");
        bquery.findObjectsInBackground { (data, error) in
            objectBlock(data ?? Array.init());
        }
    
    }
    func updateTimes(_ timeId:String,sportId:String) {
         let bquery:BmobQuery = BmobQuery.init(className: "Sport");
        //查找GameScore表里面id为0c6db13c的数据
        bquery.getObjectInBackground(withId: sportId) { (sport, error) in
            if let errors = error{
               
            }else{
                var array:Array<String> = sport?.object(forKey: "occupiedTime") as! Array<String>;
                array.append(timeId);
                sport?.setObject(array, forKey: "occupiedTime");
                sport?.updateInBackground();
            }
        }
   
        
    }
    
    
    //time
   func addTimes() {
    let times:[String] = ["9:00-10:00","10:00-11:00","11:00-12:00","12:00-13:00","13:00-14:00","14:00-15:00","15:00-16:00","16:00-17:00","17:00-18:00"];
        for time in times{
            let index = times.firstIndex(of: time);
            let indexStr = String.init(format: "%d", index ?? 0);
            
            
            let object:BmobObject = BmobObject.init(outDataWithClassName: "Time", objectId: "objectId");
            object.setObject(time, forKey: "time");
            object.setObject(indexStr, forKey: "index");
            object.saveInBackground();
        }
        
        
    }
    //get
    func getTimes(_ objectBlock:@escaping ((_ data:Array<Any>)->())) {
        
        
        let bquery:BmobQuery = BmobQuery.init(className: "Time");
        bquery.order(byAscending: "index");
        bquery.findObjectsInBackground { (data, error) in
            objectBlock(data ?? Array.init());
        }
        
    }
    
    
    
    
    
}
