//
//  FieldViewController.swift
//  Sports
//
//  Created by fpm0259 on 2018/10/29.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class FieldViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {
   
    @IBOutlet weak var sportsCollectionView: UICollectionView!
    var dataArray:Array<Any>?
    override func viewDidLoad() {
        super.viewDidLoad()
        BmobManager().getSports { (datas) in
            self.dataArray = datas;
            self.sportsCollectionView.reloadData();
        }
        

        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArray?.count ?? 0;
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let model:BmobObject = dataArray?[indexPath.row] as! BmobObject;
        let cell:ItemCell = collectionView.dequeueReusableCell(withReuseIdentifier: "itemCell", for: indexPath) as! ItemCell
        cell.nameLab.text = model.object(forKey: "name") as! String;
        return cell;
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
          let model:BmobObject = dataArray?[indexPath.row] as! BmobObject;
        let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil);
        let timeVC:TimeViewController = storyBoard.instantiateViewController(withIdentifier: "TimeViewController") as! TimeViewController;
        timeVC.sport = model;
        self.navigationController?.pushViewController(timeVC, animated: true);
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
