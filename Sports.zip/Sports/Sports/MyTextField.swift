//
//  MyTextField.swift
//  Running
//
//  Created by eden on 2018/10/28.
//  Copyright © 2018年 eden. All rights reserved.
//

import UIKit

class MyTextField: UITextField {
    
    var _leftImage: UIImage?;
    var leftImage: UIImage? {
        get {
            return _leftImage;
        }
        set {
            _leftImage = newValue;
            let leftView:UIImageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: _leftImage?.size.width ?? 0, height: leftImage?.size.height ?? 0));
            leftView.image = leftImage;
            self.leftView = leftView;
            self.leftViewMode = .always;

        }
    }
    var _leftTitle: String = String.init();
    var leftTitle: String {
        get {
            return _leftTitle;
        }
        set {
            _leftTitle = newValue;
            let leftView:UILabel = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: self.frame.size.height));
            leftView.text = leftTitle;
            self.leftView = leftView;
            self.leftViewMode = .always;
            
        }
    }
    

}
