//
//  RegistViewController.m
//  Run
//
//  Created by fpm0259 on 2018/9/10.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "RegistViewController.h"
#import "MyTextField.h"
#import "BmobManger.h"

@interface RegistViewController ()
@property (weak, nonatomic) IBOutlet MyTextField *accountTextField;
@property (weak, nonatomic) IBOutlet MyTextField *passwordTextField;
@property (weak, nonatomic) IBOutlet MyTextField *confirmPasswordTextField;

@end

@implementation RegistViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)initUI
{
    self.accountTextField.leftImage = [UIImage imageNamed:@"userIcon"];
    self.passwordTextField.leftImage = [UIImage imageNamed:@"passwordIcon"];
    self.confirmPasswordTextField.leftImage = [UIImage imageNamed:@"passwordIcon"];
    self.passwordTextField.clearButtonMode = UITextFieldViewModeAlways;

}
- (IBAction)registClick:(id)sender {
    //判断
    if (self.accountTextField.text.length == 0) {
        TOAST(@"账号不能为空！");
        return;
    }
    if (self.passwordTextField.text.length == 0) {
        TOAST(@"密码不能为空！");
        return;
    }
    if (self.confirmPasswordTextField.text.length == 0) {
        TOAST(@"确认密码不能为空！");
        return;
    }
    if (![self.confirmPasswordTextField.text isEqualToString:self.passwordTextField.text])
    {
        TOAST(@"确认密码和密码保持一致！");
        return;
    }
    
    [[BmobManger new]getObjectWithObject:@"User" key:@"account" value:self.accountTextField.text resultBlock:^(NSError *error, NSArray *data) {
        if (data.count == 0) {
            [[BmobManger new] BmobAddObject:@"User" dataDic:@{@"account":self.accountTextField.text,@"password":self.passwordTextField.text,@"status":@"0",@"seed":@"",@"point":@"",@"jp_name":@"",@"jp_create_time":@""} statusBlock:^(bool isSuccess) {
                TOASTHIDE();
                if (isSuccess) {
                    TOAST(@"注册成功!");
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        [self.navigationController popViewControllerAnimated:YES];
                    });
                }else
                {
                   TOAST(@"注册失败,请稍后重试!");
                }
            }];
        }else
        {
             TOAST(@"此账号已经存在！");
        }
    }];
    
    
   
   
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
