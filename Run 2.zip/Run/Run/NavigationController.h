//
//  FNNavigationController.h
//  FNFactoring
//
//  Created by Eastman on 2018/4/13.
//  Copyright © 2018年 FNCONN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationController : UINavigationController

@end
