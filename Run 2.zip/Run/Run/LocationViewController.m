//
//  LocationViewController.m
//  Run
//
//  Created by fpm0259 on 2018/9/11.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "LocationViewController.h"
#import <MapKit/MapKit.h>
#import "BmobManger.h"
#import "PointModel.h"
#import "BottomView.h"
#import "MKAnnotationView+Extension.h"
#import <StoreKit/StoreKit.h>
@interface LocationViewController ()<MKMapViewDelegate,CLLocationManagerDelegate,SKStoreProductViewControllerDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UIImageView *bottomClick;
@property (nonatomic, strong)CLLocation *location;
@property(nonatomic,assign)NSTimeInterval nowInterval;
@property(nonatomic,copy)NSString *speed;
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong) NSMutableArray *annotations;
@property(nonatomic,strong)NSTimer *timer;
@property(nonatomic,assign)CLLocationDirection headDirction;
@property(nonatomic,strong)CLGeocoder *geocoder;
@end

@implementation LocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    self.mapView.showsScale = YES;
    self.mapView.showsTraffic = YES;



  
    _locationManager = [[CLLocationManager alloc] init];
    _locationManager.delegate = self;
    [_locationManager requestAlwaysAuthorization];
    _locationManager.desiredAccuracy =kCLLocationAccuracyBest;
    [_locationManager startUpdatingLocation];
    [_locationManager startUpdatingHeading];

    
    __weak LocationViewController *locationVC =  (LocationViewController *)self;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:10.0 repeats:YES block:^(NSTimer * _Nonnull timer) {
        [locationVC requestData];
    }];
    [self.timer fire];
    
    
    
    
    
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}
-(void)requestData
{
    //先上传用户自己的数据
     [[BmobManger new] BmobUpdateUserLocation:self.location headDirtion:self.headDirction speed:self.speed statusBlock:^(bool isSuccess,BmobObject *user) {
        
        //获取所有用户的数据
        [[BmobManger new]getObjectWithObject:@"User" key:nil value:nil resultBlock:^(NSError *error, NSArray *data) {
            [self.mapView removeAnnotations:self.annotations];
            [self.annotations removeAllObjects];
            [data enumerateObjectsUsingBlock:^(BmobObject *obj, NSUInteger idx, BOOL * _Nonnull stop) {
                PointModel *model = [[PointModel alloc]init];
                model.user = obj;
              
                    [self.annotations addObject:model];
              
               
                
                
                if (![[user objectForKey:@"account"] isEqualToString:[obj objectForKey:@"account"]]) {
                   
                    if ([[user objectForKey:@"status"] isEqualToString:@"1"])
                    {
                        NSLog(@"当前状态:免疫");
                    }else
                    {
                        NSLog(@"当前状态:正常");
                    }
                   
                  NSArray *points = [[obj objectForKey:@"point"] componentsSeparatedByString:@","];
                    CLLocation *objectL = [[CLLocation alloc]initWithLatitude:[points[0] doubleValue] longitude:[points[1] doubleValue]];
                   double distance = [objectL distanceFromLocation:self.location];
                    if (distance <= 15 && [[user objectForKey:@"status"] isEqualToString:@"0"]) {
                        NSString *user_jp_name = [user objectForKey:@"jp_name"];
                        NSString *other_jp_name = [obj objectForKey:@"jp_name"];
                        long length = user_jp_name.length +  other_jp_name.length;
                        if ((length == user_jp_name.length||length == other_jp_name.length) && length != 0) {
                            [user setObject:@"status" forKey:@"1"];
                            [obj setObject:@"status" forKey:@"0"];
                            [user setObject:@"jp_name" forKey:other_jp_name];
                            [obj setObject:@"jp_name" forKey:user_jp_name];
                            //更新数据库
                             [obj updateInBackground];
                             [user updateInBackground];
                        }
                        
                        
                       
                    }
               
                    
                }
       
                
            }];
            [self.mapView addAnnotations:self.annotations];
            
            
            
        }];
    
    }];
    
    
    
    
 
}

#pragma mark - MKMapViewDelegate
- (void)locationManager:(CLLocationManager *)manager
     didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    // 位置发生变化调用
    CLLocation *location = locations[0];
    
    
    NSLog(@"lan = %f, long = %f", location.coordinate.latitude, location.coordinate.longitude);
    
    CLLocationCoordinate2D coordinate = location.coordinate;
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 2000, 2000);
    [self.mapView setCenterCoordinate:coordinate animated:YES];
    [self.mapView setRegion:region animated:YES];
    if (!self.location) {
        self.nowInterval = [NSDate timeIntervalSinceReferenceDate];
        self.location = location;
        return;
    }
    
    //计算距离
    double distance = [location distanceFromLocation:self.location];
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    double speed = distance/(now - self.nowInterval);
    NSString *peed = [NSString stringWithFormat:@"%ld",lround(speed)];
    self.speed = peed;
    self.location = location;
    self.nowInterval = now;
    
}
// 方向信息更新后触发
- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading
{

    // 磁北偏移量,  0  - 359.9, 顺时针增加, 磁北方向的值为0
    NSLog(@"真北: %f,", newHeading.magneticHeading);
    self.headDirction = newHeading.magneticHeading;
}


- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
//    // 位置发生变化调用
//    NSLog(@"lan = %f, long = %f", userLocation.coordinate.latitude, userLocation.coordinate.longitude);
//
//    CLLocationCoordinate2D coordinate = userLocation.location.coordinate;
//    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 250, 250);
//    [mapView regionThatFits:region];
//
//    if (!self.location) {
//        self.nowInterval = [NSDate timeIntervalSinceReferenceDate];
//        self.location = userLocation;
//        return;
//    }
//
////计算距离
//  double distance = [userLocation.location distanceFromLocation:self.location.location];
//  NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
//  double speed = distance/(now - self.nowInterval);
//  NSString *peed = [NSString stringWithFormat:@"%ld",lround(speed)];
//  self.speed = peed;
//  self.location = userLocation;
//  self.nowInterval = now;
  
    
}
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    static NSString *identifier = @"MKAnnotationView";
    PointModel *model =(PointModel *)annotation;
    MKAnnotationView *animationView = [mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    if (!animationView) {
        animationView = [[MKAnnotationView alloc]initWithAnnotation:model reuseIdentifier:identifier];
    }
    animationView.image = [UIImage imageNamed:@"red_l"];
    animationView.model = model;
    
    
    
    
    
    SKStoreProductViewController *vc = [[SKStoreProductViewController alloc]init];
    [vc loadProductWithParameters:@{SKStoreProductParameterITunesItemIdentifier:@(1403817165)} completionBlock:^(BOOL result, NSError * _Nullable error) {
        
    }];
    vc.delegate = self;
    [self presentViewController:vc animated:YES completion:nil];
    
    
    
    
    
    
    return animationView;
}
- (void)productViewControllerDidFinish:(SKStoreProductViewController *)viewController
{
    [viewController dismissViewControllerAnimated:YES completion:nil];
}
- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
    PointModel *model = view.model;
    NSString *account =@"";
    if ([model isKindOfClass:[MKUserLocation class]]) {
       account = [[NSUserDefaults standardUserDefaults] valueForKey:@"user"];
      
    }else
    {
        account =  [model.user objectForKey:@"account"];
    }
    [[NSUserDefaults standardUserDefaults]setObject:account forKey:@"other"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    BottomView *bottomV = [[BottomView alloc]initWithFrame:CGRectMake(0, SCREENHEIGHT - 200, SCREENWIDTH, 200)];
    bottomV.backgroundColor = [UIColor colorWithRed:227/255.0 green:103/255.0 blue:47/255.0 alpha:1];
    [self.view addSubview:bottomV];
    
    [self drawLineBetweenBeginCity:@"上海" endCity:@"北京"];
    
}


- (void)drawLineBetweenBeginCity:(NSString *)scourceCity endCity:(NSString *)destinationCity {
    //1.因为传入的城市名称是中文字符串.所以先进行地理编码.
    [self.geocoder geocodeAddressString:scourceCity completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        //获取起点城市地标
        CLPlacemark *mark1 = [placemarks firstObject];
        //设置路线显示范围
        [self.mapView setRegion:MKCoordinateRegionMake(mark1.location.coordinate, MKCoordinateSpanMake(10.0, 10.0)) animated:YES];
        
        //2.获取目的城市的地标对象
        [self.geocoder geocodeAddressString:destinationCity completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
            //获取地标对象
            CLPlacemark *mark2 = [placemarks firstObject];
#pragma mark -- 获取了两个城市的地标对象后.开始添加路段模型.显示路线
            [self addLineFrom:mark1 to:mark2];
            
        }];
        
    }];
}
#pragma mark - 规划路线
- (void)addLineFrom:(CLPlacemark *)from to:(CLPlacemark *)to {
    
    //2.开始路线请求
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc]init];
    //3.选择出行模式
    request.transportType = MKDirectionsTransportTypeAutomobile;//自驾
    //4.设置路线的起点
    MKPlacemark *sourcePlace = [[MKPlacemark alloc]initWithPlacemark:from];
    request.source = [[MKMapItem alloc]initWithPlacemark:sourcePlace];
    //5.设置路线的终点
    MKPlacemark *destinationPlace = [[MKPlacemark alloc]initWithPlacemark:to];
    request.destination = [[MKMapItem alloc]initWithPlacemark:destinationPlace];
    //6.根据请求对象获取路线对象
    MKDirections *direction = [[MKDirections alloc]initWithRequest:request];
    //7.计算路线(路线由一条条路段组成.而路段由一个个的轨迹点组成)
    [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"总共有%lu条路线组成", response.routes.count);
        //填充轨迹点模型.
        for (MKRoute *route in response.routes) {
            [self.mapView addOverlay:route.polyline];
        }
    }];
    

}
#pragma mark -- 绘制路线的代理方法
- (MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay {
    MKPolylineRenderer *renderer = [[MKPolylineRenderer alloc]initWithOverlay:overlay];
    //设置路线的颜色
    renderer.strokeColor = [UIColor greenColor];
    renderer.fillColor = [UIColor blueColor];
    return renderer;
    
}
- (void)resetLocation:(id)sender {
    // 定位到我的位置
    [_mapView setCenterCoordinate:_mapView.userLocation.coordinate animated:YES];
}
-(CLGeocoder *)geocoder
{
    if (_geocoder == nil) {
        _geocoder = [[CLGeocoder alloc]init];
    }
    return _geocoder;
}
-(NSMutableArray *)annotations
{
    if (_annotations == nil) {
        _annotations = [NSMutableArray array];
    }
    return _annotations;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
