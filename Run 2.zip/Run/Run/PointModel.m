//
//  PointModel.m
//  Run
//
//  Created by fpm0259 on 2018/9/12.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "PointModel.h"

@implementation PointModel
-(void)setUser:(BmobObject *)user
{
    NSString *point = [user objectForKey:@"point"];
    NSArray *array = [point componentsSeparatedByString:@","];
    if (array.count != 2) {
        NSLog(@"有问题数据，不处理");
        array = @[@"23.455",@"110.00"];
    }
    double lat = [array[0] doubleValue];
    double lng = [array[1] doubleValue];
    self.coordinate = CLLocationCoordinate2DMake(lat,lng);;
    _user = user;
}
@end
