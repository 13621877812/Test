//
//  BmobManger.h
//  Run
//
//  Created by fpm0259 on 2018/9/10.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BmobSDK/Bmob.h>
#import <MapKit/MapKit.h>
@interface BmobManger : NSObject
//添加数据
-(void)BmobAddObject:(NSString *)objectName dataDic:(NSDictionary *)dataDic statusBlock:(void(^)(bool isSuccess))statusBlock;

//获取数据
-(void)getObjectWithObject:(NSString *)objectName key:(NSString *)keyName value:(NSString *)valueName resultBlock:(void(^)(NSError *error,NSArray *data))resultBlock;

//更新我的经纬度数据
-(void)BmobUpdateUserLocation:(CLLocation *)location headDirtion:(CLLocationDirection)headDirtion speed:(NSString *)speed statusBlock:(void(^)(bool isSuccess,BmobObject *user))statusBlock;
@end
