//
//  Prefix.h
//  Run
//
//  Created by fpm0259 on 2018/9/10.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#ifndef Prefix_h
#define Prefix_h
#import "CALayer+LayerColor.h"
#import "MBProgressHUD.h"

#define TOAST(title)\
\
UIWindow *window=[UIApplication sharedApplication].keyWindow;\
MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:window animated:YES];\
hud.mode = MBProgressHUDModeText;\
hud.labelText = title;\
[hud hide:YES afterDelay:1]


#define TOASTSHOW(title)\
\
UIWindow *window=[UIApplication sharedApplication].keyWindow;\
MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:window animated:YES];\
hud.labelText = title;\

#define TOASTHIDE()\
\
UIWindow *window=[UIApplication sharedApplication].keyWindow;\
[MBProgressHUD hideHUDForView:window animated:YES]\


#define SCREENWIDTH [[UIScreen mainScreen]bounds].size.width
#define SCREENHEIGHT [[UIScreen mainScreen]bounds].size.height


#endif /* Prefix_h */
