//
//  BottomView.m
//  Run
//
//  Created by fpm0259 on 2018/9/12.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "BottomView.h"
#import "BmobManger.h"
@interface BottomView()
@property(nonatomic,strong)UILabel *nameLab;
@property(nonatomic,strong)UILabel *stateLab;
@property(nonatomic,strong)UILabel *directionLab;
@property(nonatomic,strong)UILabel *speedLab;
@property(nonatomic,strong)NSTimer *timer;
@end

@implementation BottomView
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createUI];
        self.timer = [NSTimer scheduledTimerWithTimeInterval:10 repeats:YES block:^(NSTimer * _Nonnull timer) {
            [self requestData];
        }];
        [self.timer fire];
        
    }
    return self;
}
-(void)createUI
{
    
    self.nameLab = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, SCREENWIDTH - 20, self.bounds.size.height/4.0)];
    self.nameLab.textAlignment = NSTextAlignmentCenter;
    self.nameLab.textColor = [UIColor blackColor];
    [self addSubview:self.nameLab];
    
    
    
    self.stateLab = [[UILabel alloc]initWithFrame:CGRectMake(10, self.bounds.size.height/4.0, SCREENWIDTH - 20, self.bounds.size.height/4.0)];
    self.stateLab.textAlignment = NSTextAlignmentCenter;
    self.stateLab.textColor = [UIColor blackColor];
    [self addSubview:self.stateLab];
    
    
    self.directionLab = [[UILabel alloc]initWithFrame:CGRectMake(10, self.bounds.size.height/2.0, SCREENWIDTH - 20, self.bounds.size.height/4.0)];
    self.directionLab.textAlignment = NSTextAlignmentCenter;
    self.directionLab.textColor = [UIColor blackColor];
    [self addSubview:self.directionLab];
    
    self.speedLab = [[UILabel alloc]initWithFrame:CGRectMake(10, self.bounds.size.height*3/4.0 , SCREENWIDTH - 20, self.bounds.size.height/4.0)];
    self.speedLab.textAlignment = NSTextAlignmentCenter;
    self.speedLab.textColor = [UIColor blackColor];
    [self addSubview:self.speedLab];
    
    
    
    UIButton *outBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    outBtn.frame = CGRectMake(SCREENWIDTH-100, self.bounds.size.height/2.0, 50, 50);
    [outBtn addTarget:self action:@selector(outClick) forControlEvents:UIControlEventTouchUpInside];
    [outBtn setTitle:@"取消" forState:UIControlStateNormal];
    [self addSubview:outBtn];
    
    
    UIButton *headBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    headBtn.frame = CGRectMake(10, self.bounds.size.height/2.0, 50, 50);
    [headBtn addTarget:self action:@selector(headClick) forControlEvents:UIControlEventTouchUpInside];
    [headBtn setTitle:@"head" forState:UIControlStateNormal];
    [self addSubview:headBtn];
    
}
-(void)headClick
{
    
}

-(void)outClick
{
    [self.timer invalidate];
    self.timer = nil;
    [self removeFromSuperview];
}
-(void)requestData
{
    NSString *account = [[NSUserDefaults standardUserDefaults]valueForKey:@"other"];
    [[BmobManger new] getObjectWithObject:@"User" key:@"account" value:account resultBlock:^(NSError *error, NSArray *data) {
        if (error) {
            NSLog(@"请求失败");
        }
   
        if (!error) {
            
            BmobObject *other = data[0];
            
          
            //name
            NSString *name =[other objectForKey:@"account"];
            
            //name
            NSString *state =@"已持有奖品：娃娃持有时间1545555";
            //速度
            NSString *speed = [other objectForKey:@"seed"];
            //方向
            NSString *direction = [other objectForKey:@"fangwei"];
            
            
            self.nameLab.text = name;
            self.stateLab.text = state;
            
            self.speedLab.text = [NSString stringWithFormat:@"现在的速度:%@",speed];
            self.directionLab.text = [NSString stringWithFormat:@"现在的方向:%@",direction];
        }
       
        
        
    }];
    
    
    
    
    
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
