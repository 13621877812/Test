//
//  CALayer+LayerColor.m
//  Run
//
//  Created by fpm0259 on 2018/9/10.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "CALayer+LayerColor.h"

@implementation UIView (LayerColor)
- (void)setCornerRadius:(CGFloat)cornerRadius
{
    self.layer.cornerRadius = cornerRadius;
    self.layer.masksToBounds = cornerRadius > 0;
}

- (CGFloat)cornerRadius
{
    return self.layer.cornerRadius;
}
- (void)setBorderWidth:(CGFloat)borderWidth
{
    self.layer.borderWidth = borderWidth;
 
}

- (CGFloat)borderWidth
{
    return self.layer.borderWidth;
}
- (void)setBorderColor:(UIColor *)borderColor
{
    self.layer.borderColor = borderColor.CGColor;
    
}

- (UIColor *)borderColor
{
    return [UIColor colorWithCGColor:self.layer.borderColor];
}
@end
