//
//  FNNavigationController.m
//  FNFactoring
//
//  Created by Eastman on 2018/4/13.
//  Copyright © 2018年 FNCONN. All rights reserved.
//

#import "NavigationController.h"

@interface NavigationController ()

@end

@implementation NavigationController
+(void)load
{
    [[UINavigationBar appearance] setBackgroundImage:[[UIImage alloc] init] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    
   [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];
    

}
-(void)viewDidLoad {
    [super viewDidLoad];
    self.navigationBar.translucent = NO;
    self.navigationBar.backgroundColor=[UIColor blueColor];
    self.interactivePopGestureRecognizer.delegate = (id)self;
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.childViewControllers.count >= 1) {
        viewController.hidesBottomBarWhenPushed = YES;

        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"back"] style:UIBarButtonItemStylePlain target:self action:@selector(goBack)];
    }
    [super pushViewController:viewController animated:animated];
}

-(void)goBack
{
    
    [self popViewControllerAnimated:YES];
}




@end
