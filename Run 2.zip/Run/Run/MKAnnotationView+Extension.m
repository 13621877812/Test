//
//  MKAnnotationView+Extension.m
//  Run
//
//  Created by fpm0259 on 2018/9/21.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "MKAnnotationView+Extension.h"
#import <objc/runtime.h>
@implementation MKAnnotationView (Extension)
-(void)setModel:(PointModel *)model
{
    objc_setAssociatedObject(self, "model", model, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
-(PointModel *)model
{
    return objc_getAssociatedObject(self, "model");
}
@end
