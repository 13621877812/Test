//
//  NetWorkManager.swift
//  dmit
//
//  Created by fpm0259 on 2018/7/27.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit
import Foundation
class NetWorkManager: NSObject {
   
}
