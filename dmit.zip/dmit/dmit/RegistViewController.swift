//
//  RegistViewController.swift
//  dmit
//
//  Created by fpm0259 on 2018/7/27.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class RegistViewController: UIViewController {

     @IBOutlet weak var userNameTextField: UITextField!
     @IBOutlet weak var nameTextField: UITextField!
     @IBOutlet weak var emailTextField: UITextField!
     @IBOutlet weak var ageTextField: UITextField!
     @IBOutlet weak var historyTextField: UITextField!
     @IBOutlet weak var passwordTextField: UITextField!
     @IBOutlet weak var confirTextField: UITextField!
    
    
    @IBOutlet weak var femaleBtn: RadioButton!
    
    @IBOutlet weak var maleBtn: RadioButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func initUI()  {
        //改变placehold颜色
        self.userNameTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.nameTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.emailTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.ageTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.historyTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.passwordTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.confirTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.passwordTextField.isSecureTextEntry = true
        self.confirTextField.isSecureTextEntry = true
        
        
        //添加输入框leftView
        let userNmaeLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let userNmaeLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        userNmaeLeftImg.center = CGPoint(x: 25, y: 20)
        userNmaeLeftImg.image = UIImage.init(named: "user")
        userNmaeLeftView.addSubview(userNmaeLeftImg)
        self.userNameTextField.leftView = userNmaeLeftView
        self.userNameTextField.leftViewMode = .always
        
        
        let nameLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let nameLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        nameLeftImg.center = CGPoint(x: 25, y: 20)
        nameLeftImg.image = UIImage.init(named: "firstname")
        nameLeftView.addSubview(nameLeftImg)
        self.nameTextField.leftView = nameLeftView
        self.nameTextField.leftViewMode = .always
        
        
        let emailLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let emailLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        emailLeftImg.center = CGPoint(x: 25, y: 20)
        emailLeftImg.image = UIImage.init(named: "email")
        emailLeftView.addSubview(emailLeftImg)
        self.emailTextField.leftView = emailLeftView
        self.emailTextField.leftViewMode = .always
        
        
        
        let historyLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let historyLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        historyLeftImg.center = CGPoint(x: 25, y: 20)
        historyLeftImg.image = UIImage.init(named: "mh")
        historyLeftView.addSubview(historyLeftImg)
        self.historyTextField.leftView = historyLeftView
        self.historyTextField.leftViewMode = .always
        
      
        
        
        let passwordLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let passwordLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        passwordLeftImg.center = CGPoint(x: 25, y: 20)
        passwordLeftImg.image = UIImage.init(named: "password")
        passwordLeftView.addSubview(passwordLeftImg)
        self.passwordTextField.leftView = passwordLeftView
        self.passwordTextField.leftViewMode = .always
        
        
        let confirLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let confirLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        confirLeftImg.center = CGPoint(x: 25, y: 20)
        confirLeftImg.image = UIImage.init(named: "confirm_password")
        confirLeftView.addSubview(confirLeftImg)
        self.confirTextField.leftView = confirLeftView
        self.confirTextField.leftViewMode = .always
        
        
        //性别按钮绑在一起
        self.maleBtn.groupButtons = [self.maleBtn,self.femaleBtn]
        self.femaleBtn.isSelected = true
        
    }
    
    @IBAction func registClick(_ sender: Any) {
        //对输入框数据判断
        if !(isInvalid()) {
            return
        }
        
        //注册
        //注册
        var gender = "Female"
        if self.maleBtn.isSelected {
            gender = "Male"
        }
        let params:[String : Any] = ["type":"1001","username":self.userNameTextField.text,"firstname":self.nameTextField.text,"email":self.emailTextField.text,"gender":gender,"age":self.ageTextField.text,"medical_history":self.historyTextField.text,"password":self.passwordTextField.text] as [String : Any]
        
        var paramsStr:String!
        do {
            let data:Data =
                try JSONSerialization.data(withJSONObject: params, options: .prettyPrinted)
            paramsStr = String.init(data: data, encoding: .utf8)
            
        } catch  {}
        
       
        HttpHelper.Shared.Post(path: REGISTER_URL, paras: params, success: { (response) in
            
            print(response)
            
        }) { (error) in
            print(error.localizedDescription)
        }
        
        
    }
   
        
        
        
        

    func isInvalid() -> Bool {
        if (self.userNameTextField.text?.isEmpty)! {
            return false
        }
        if (self.nameTextField.text?.isEmpty)! {
            return false
        }
        if (self.emailTextField.text?.isEmpty)! {
            return false
        }
        if (self.ageTextField.text?.isEmpty)! {
            return false
        }
        if (self.historyTextField.text?.isEmpty)! {
            return false
        }
        if (self.passwordTextField.text?.isEmpty)! {
            return false
        }
        if (self.passwordTextField.text != self.confirTextField.text){
            return false
        }
        return true
      
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
