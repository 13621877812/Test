//
//  NetUrl.swift
//  dmit
//
//  Created by macbook on 2018/7/27.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import Foundation

let API:String = "http://192.168.0.102:8888/myproject/"



//staff
let STATFF_LOGIN_URL:String = API + "retrieveStaff.php"



let USER_LOGIN_URL:String = API + "retrieve.php"

let CHECK_URL :String = API + "checkUsername.php"
let REGISTER_URL :String = API + "register.php"

let UPDATE_PROFILE_URL:String = API + "updateProfile.php"
let EVENT_STATUS_URL:String = API + "getEventStatus.php"

//start event
let START_EVENT_URL:String = API + "startEvent.php"

// event
let EVENT_URL:String = API + "retrieveEvent.php"

// accept
let ACCEPT_EVENT_URL:String = API + "acceptEvent.php"

// cancel
let DELETE_EVENT_URL:String = API + "deleteEvent.php"
