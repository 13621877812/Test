//
//  UIView+CornerRadius.swift
//  OrderMenu
//
//  Created by macbook on 2018/7/27.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import UIKit
extension UIView {
    @IBInspectable var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
      
        set {
            layer.cornerRadius = newValue
        }
    }
    @IBInspectable var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
       
        set {
            layer.borderWidth = newValue
        }
    }
    @IBInspectable var borderColor: CGColor {
        get {
            return layer.borderColor!
        }

        set {
            layer.borderColor = newValue
        }
    }
}


