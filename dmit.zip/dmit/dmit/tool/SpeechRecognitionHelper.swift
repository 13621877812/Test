//
//  SpeechRecognitionHelper.swift
//  spech
//
//  Created by macbook on 2018/7/29.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import UIKit
import Speech
class SpeechRecognitionHelper: NSObject,SFSpeechRecognizerDelegate {

   public static var Shared=SpeechRecognitionHelper();
    var recognitionTask:SFSpeechRecognitionTask?
    var recognitionRequest:SFSpeechAudioBufferRecognitionRequest?
    
    func checkAuthorization(_ errorBlock:((_ error:String)->())? = nil) {
        //开发的时候需要在info.plist里面添加
        //    Application requires iPhone environment  YES
        //    Privacy - Microphone Usage Description  App需要您的同意,才能访问麦克风
        //    Privacy - Speech Recognition Usage Description  App需要您的同意,才能使用语音识别技术
        

        SFSpeechRecognizer.requestAuthorization { (status) in
            DispatchQueue.main.async(execute: {
                switch status{
                    
                case .notDetermined:
                   errorBlock?("语音识别未授权")
                    break
                    
                case .denied:
                    errorBlock?("用户未授权使用语音识别")
                    break
                    
                case .restricted:
                    errorBlock?("语音识别在这台设备上受到限制")
                    break
                    
                case .authorized:
                    errorBlock?("语音识别在这台设备上受到限制")
                    break
             
                    
                }
            })
        }
        
        
    }
  
    func recognizeAudioFiletextBlock(_ successBlock:(()->())? = nil) {
        if (recognitionTask != nil) {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        
        let audioSession:AVAudioSession = AVAudioSession.sharedInstance()

        do{
            try
            audioSession.setCategory(AVAudioSessionCategoryRecord)
              try  audioSession.setMode(AVAudioSessionModeMeasurement)
            
             try
                 audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        }catch{}
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest.init()
        let inputNode:AVAudioInputNode = self.audioEngine.inputNode
        recognitionRequest?.shouldReportPartialResults = true
        recognitionTask = self.speechRecognizer.recognitionTask(with: recognitionRequest!, resultHandler: { (result, error) in
            var isFinal:Bool = false
            if ((result) != nil){
                let res:String = (result?.bestTranscription.formattedString)!
                if(res.contains("help")){
                   successBlock?()
                   isFinal = (result?.isFinal)!
                }
                
             
                
            }
            if((error != nil) || isFinal){
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                self.recognitionTask = nil
                self.recognitionRequest = nil
            }
        })
        
        let recordingFormat:AVAudioFormat = inputNode.outputFormat(forBus: 0)
        inputNode.removeTap(onBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            if (self.recognitionRequest != nil){
                self.recognitionRequest?.append(buffer)
                
            }
        }
        
        self.audioEngine.prepare()
        
        do {
            try
             self.audioEngine.start()
        } catch  {}
       
        
        
        
        
        
        
        
        
    }
    
    
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        
    }
    
    var _speechRecognizer:SFSpeechRecognizer?
    var speechRecognizer: SFSpeechRecognizer {
        if (_speechRecognizer == nil) {
            let local:Locale = Locale.init(identifier: "en-GB")
            _speechRecognizer = SFSpeechRecognizer.init(locale: local as Locale)
            _speechRecognizer?.delegate = self
        }
        return _speechRecognizer!
    }
    var _audioEngine:AVAudioEngine?
    var audioEngine: AVAudioEngine {
        if (_audioEngine == nil) {
            _audioEngine = AVAudioEngine.init()
        }
        return _audioEngine!
    }
    
    
    
}


