//
//  LocationManager.swift
//  dmit
//
//  Created by macbook on 2018/7/27.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation
class LocationManager: NSObject,CLLocationManagerDelegate {
  
    var manager:CLLocationManager?
    var LocationSuccess:((_ lat:Double,_ lng:Double)->(Void))?
    var LocationFailed:((_ error:NSError)->(Void))?
    
    
    //单例
    static let shared = LocationManager.init()
    
    private override init() {
        super.init()
       //打开定位
        manager = CLLocationManager.init()
        manager?.delegate = self
      //控制定位精度,越高耗电量越
        manager?.desiredAccuracy = kCLLocationAccuracyBest
        
        // 兼容iOS8.0版本
        /* Info.plist里面加上2项
         NSLocationAlwaysUsageDescription      Boolean YES
         NSLocationWhenInUseUsageDescription   Boolean YES
         */
        
        // 请求授权 requestWhenInUseAuthorization用在>=iOS8.0上
        // respondsToSelector: 前面manager是否有后面requestWhenInUseAuthorization方法
  
        // 2. 另外一种适配 systemVersion 有可能是 8.1.1
        let osVersion:Float = UIDevice.current.systemVersion._bridgeToObjectiveC().floatValue
        
     
        if (osVersion >= 8) {
            manager?.requestWhenInUseAuthorization()
            manager?.requestAlwaysAuthorization()
        }
    }
    
    
    func getMoLocationWithSuccess(_ success:@escaping (_ lat:Double,_ lng:Double)->(Void), Failure:@escaping (_ error:NSError)->(Void))  {
        
       LocationSuccess = success
       LocationFailed = Failure
        
        // 停止上一次的
        manager?.stopUpdatingLocation()
        
        // 开始新的数据定位
        manager?.startUpdatingLocation()
    }
    
  class  func getMoLocationWithSuccess(_ success:@escaping (_ lat:Double,_ lng:Double)->(Void), Failure:@escaping (_ error:NSError)->(Void)) -> Void {
        LocationManager.shared.getMoLocationWithSuccess(success, Failure: Failure)
    }
    
    func stop() {
        manager?.stopUpdatingLocation()
    }
    class func stop(){
        LocationManager.shared.stop()
    }
    
    // 每隔一段时间就会调用
    
    func locationManager(_ manager:CLLocationManager,locations:Array<CLLocation>) -> Void {
        for loc in locations {
            let l:CLLocationCoordinate2D = loc.coordinate
            let lat = l.latitude
             let lnt = l.longitude
            LocationSuccess!(lat,lnt)
            
        }
    }
    
    
    //失败代理方法
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("定位失败")
    }
    
}
