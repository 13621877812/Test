//
//  DoneViewController.swift
//  dmit
//
//  Created by macbook on 2018/7/27.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import UIKit

class DoneViewController: UIViewController {

    var eventId:String?
    @IBOutlet weak var gifWeb: UIWebView!
    
    @IBOutlet weak var statusLab: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
         initUI()
        initData()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func initUI() {
        
        let path:String = Bundle.main.path(forResource: "sosloading", ofType: "gif")!
        self.gifWeb.loadRequest(URLRequest.init(url: URL.init(string: path)!))
     
    }
    func initData()  {
        let params:[String:String] = ["type":"1002","id":self.eventId ?? "1"];
        HttpHelper.Shared.Post(path: EVENT_STATUS_URL, paras: params, success: { (res) in
            let response:[String:String] = res as![String:String]
            if (response["result"] == "Pending"){
                //移除gif  添加图片
                self.gifWeb.removeFromSuperview()
                self.gifWeb = nil
                
                
                let imageV:UIImageView = UIImageView.init(image: UIImage.init(named: "done"))
                imageV.frame = CGRect.init(x: self.view.bounds.size.width/2.0 - 50, y: 170, width: 100, height: 100)
                self.view.addSubview(imageV)
                self.statusLab.text = "Hold on \n We will come to you immediately!"
                
                
               
            }else
            {
                  self.statusLab.text = "Pending..."
               
            }
            
        }) { (error) in
            self.view.makeToast("SOS failed please try again!")
        }
        
        
    }
    @IBAction func backRoot(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
        self.navigationController?.popViewController(animated: false)
 
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
