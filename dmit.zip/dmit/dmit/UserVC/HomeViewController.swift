//
//  HomeViewController.swift
//  dmit
//
//  Created by macbook on 2018/7/27.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //语音识别，识别到help 自动跳转
        SpeechRecognitionHelper.Shared.recognizeAudioFiletextBlock {
             self.pushSosVC()
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    @IBAction func sosBtnClick(_ sender: Any) {
        self.pushSosVC()
        
    }
    func pushSosVC() {
        let story:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        let sosVC:SosViewController = story.instantiateViewController(withIdentifier: "SosViewController") as! SosViewController
        sosVC.homeVC = self
        self.present(sosVC, animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
