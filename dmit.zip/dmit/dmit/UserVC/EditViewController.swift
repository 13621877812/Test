//
//  EditViewController.swift
//  dmit
//
//  Created by macbook on 2018/7/27.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import UIKit

class EditViewController: UIViewController {


    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var historyTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirTextField: UITextField!
    var user:UserEntity?
    
    override func viewDidLoad() {
        super.viewDidLoad()
         user = UserManager.shared.getLocalUser()!
         initUI()
       
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func initUI()  {
        //改变placehold颜色
      
        self.nameTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.emailTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.historyTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.passwordTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.confirTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        self.passwordTextField.isSecureTextEntry = true
        self.confirTextField.isSecureTextEntry = true
        
        
        //添加输入框leftView
        
        
        
        let nameLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let nameLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        nameLeftImg.center = CGPoint(x: 25, y: 20)
        nameLeftImg.image = UIImage.init(named: "firstname")
        nameLeftView.addSubview(nameLeftImg)
        self.nameTextField.leftView = nameLeftView
        self.nameTextField.leftViewMode = .always
        
        
        let emailLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let emailLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        emailLeftImg.center = CGPoint(x: 25, y: 20)
        emailLeftImg.image = UIImage.init(named: "email")
        emailLeftView.addSubview(emailLeftImg)
        self.emailTextField.leftView = emailLeftView
        self.emailTextField.leftViewMode = .always
        
        
        
        let historyLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let historyLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        historyLeftImg.center = CGPoint(x: 25, y: 20)
        historyLeftImg.image = UIImage.init(named: "mh")
        historyLeftView.addSubview(historyLeftImg)
        self.historyTextField.leftView = historyLeftView
        self.historyTextField.leftViewMode = .always
        
        
        
        
        let passwordLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let passwordLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        passwordLeftImg.center = CGPoint(x: 25, y: 20)
        passwordLeftImg.image = UIImage.init(named: "password")
        passwordLeftView.addSubview(passwordLeftImg)
        self.passwordTextField.leftView = passwordLeftView
        self.passwordTextField.leftViewMode = .always
        
        
        let confirLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let confirLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        confirLeftImg.center = CGPoint(x: 25, y: 20)
        confirLeftImg.image = UIImage.init(named: "confirm_password")
        confirLeftView.addSubview(confirLeftImg)
        self.confirTextField.leftView = confirLeftView
        self.confirTextField.leftViewMode = .always
        
        
        self.nameTextField.text = self.user?.username
        self.emailTextField.text = self.user?.email
        self.historyTextField.text = self.user?.history
       self.passwordTextField.text = self.user?.password
        self.confirTextField.text = self.user?.password
    
       
        
        
    }
    @IBAction func DoneClick(_ sender: Any) {
      
        self.view.endEditing(true)
        
        
        //检查输入框的数据
        if (self.nameTextField.text?.isEmpty)! {
            self.view.makeToast("Please enter your username.")
            return
        }
        if (self.emailTextField.text?.isEmpty)! {
            self.view.makeToast("Please enter your email.")
            return
        }
        if (self.historyTextField.text?.isEmpty)! {
            self.view.makeToast("Please enter your history.")
            return
        }
        if (self.passwordTextField.text?.isEmpty)! {
            self.view.makeToast("Please enter  password.")
            return
        }
        if (self.passwordTextField.text != self.confirTextField.text) {
            self.view.makeToast("password is not equal confirm password")
            return
        }
      
        
       
        let params:[String:Any] = ["type":"1002","id":self.user!.userId!,  "username":self.nameTextField.text!,"email":self.emailTextField.text!,"medicalHistory":self.historyTextField.text!,"pw":self.passwordTextField.text!];
        if self.user?.username == self.nameTextField.text {
            editHttp(params)
        }else
        {
            checkUserNameHttp(params)
        }
        
        
        
        
    }
    func checkUserNameHttp(_ params:[String:Any]) {
        HttpHelper.Shared.Post(path: CHECK_URL, paras: params, success: { (res) in
            let response:[String:String] = res as! [String:String]
            if (response["result"] == "Unique"){
                self.editHttp(params)
                
            }else
            {
                self.view.makeToast("The username was taken, please use another one.")
            }
        }) { (error) in
           self.view.makeToast("Profile creation failed please try again later!")
        }
    }
    func editHttp(_ params:[String:Any]) {
        HttpHelper.Shared.Post(path: UPDATE_PROFILE_URL, paras: params, success: { (res) in
            let response:[String:String] = res as! [String:String]
            if (response["status"] == "OK"){
                self.user?.username = self.nameTextField.text
                self.user?.email = self.emailTextField.text
                self.user?.history = self.historyTextField.text
                self.user?.password = self.passwordTextField.text
                UserManager.shared.updateLocalUser()
                self.view.makeToast("Profile edit seccessfully!.")
            
            }
        }) { (error) in
            self.view.makeToast("Profile edition failed please try again later!")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
