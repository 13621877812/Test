//
//  AboutViewController.swift
//  dmit
//
//  Created by macbook on 2018/7/27.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import UIKit
import MessageUI
class AboutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func sendMail(_ sender: Any) {
        
        //send mail
        let btn:UIButton = sender as! UIButton
       
    
        
        let wMailViewController:MFMailComposeViewController? =  MFMailComposeViewController.init()
        if let vc = wMailViewController {
            
        }else
        {
            //手机没有登录邮箱账号
            var mailUrl:String = "mailto:" + btn.currentTitle! + "?"
            mailUrl.append("&subject=send Mail")
            mailUrl.append("&body=内容")
            mailUrl = mailUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlFragmentAllowed)!
            UIApplication.shared.open(URL.init(string: mailUrl)!, options: [:], completionHandler: nil)
            
            
            
            return
        }
        wMailViewController?.title = "send Mail"
        wMailViewController?.setToRecipients([btn.currentTitle!])
        wMailViewController?.setSubject("send Mail")
        wMailViewController?.setMessageBody("发送内容", isHTML: false)
        self.present(wMailViewController!, animated: true, completion: nil)
        
        

    }
    
    @IBAction func telClick(_ sender: Any) {
        //tel
        let btn:UIButton = sender as! UIButton
        let tel:String = String.init(format: "tel:%@", btn.currentTitle!)
        let callWebview:UIWebView = UIWebView.init()
        callWebview.loadRequest(URLRequest.init(url: URL.init(string: tel)!))
        UIApplication.shared.keyWindow?.addSubview(callWebview)
      
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
