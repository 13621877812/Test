//
//  StaffViewController.swift
//  dmit
//
//  Created by macbook on 2018/7/27.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import UIKit

class EventViewController: UIViewController {

    @IBOutlet weak var nameLab: UILabel!
    @IBOutlet weak var latitudeLab: UILabel!
    @IBOutlet weak var lngLab: UILabel!
    @IBOutlet weak var historyLab: UILabel!
    @IBOutlet weak var genderLab: UILabel!
    @IBOutlet weak var ageLab: UILabel!
    @IBOutlet weak var startTimeLab: UILabel!

    
    var eventData:[String:String]?
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Event"
         self.view.makeToast("New SOS!")
    
        self.initData()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func initData()  {
        //show
        self.nameLab.text = eventData?["firstname"]
        self.latitudeLab.text = eventData?["lat"]
        self.lngLab.text = eventData?["lng"]
        self.historyLab.text = eventData?["medical_histor"]
        self.genderLab.text = eventData?["gender"]
        self.ageLab.text = eventData?["age"]
        self.startTimeLab.text = eventData?["startTime"]
      
       
    }
    @IBAction func acceptBtnClick(_ sender: Any) {
        let params:[String:String] = ["type":"1002","id":eventData!["id"]!]
        
        HttpHelper.Shared.Post(path: ACCEPT_EVENT_URL, paras: params, success: { (res) in
            let response:[String:String] = res as! [String:String]
            if (response["status"] == "OK"){
                self.view.makeToast("Accept Success!")
            }else
            {
                self.view.makeToast("SOS Accept Error!")
            }
            
        }) { (error) in
            self.view.makeToast("SOS Accept Error!")
        }
        
        
    }
    @IBAction func cancelBtnClick(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
