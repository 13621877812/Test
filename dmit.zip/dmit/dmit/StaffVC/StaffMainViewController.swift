//
//  StaffHomeViewController.swift
//  dmit
//
//  Created by macbook on 2018/7/29.
//  Copyright © 2018 SEG-DMIT. All rights reserved.
//

import UIKit

class StaffMainViewController: UIViewController {

    @IBOutlet weak var webGif: UIWebView!
    var timer:Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "SOS Search"
        initUI()
      
        //创建定时器
        timer =  Timer.scheduledTimer(withTimeInterval: 10, repeats: true) { (timer) in
            self.view.makeToast("No SOS Now!")
            self.initData()
          
        }
        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        //关闭定时器
        timer?.fireDate = Date.distantFuture
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //开启定时器
         timer?.fireDate = Date.distantPast
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func initUI() {
        
        let path:String = Bundle.main.path(forResource: "searchhospital", ofType: "gif")!
        self.webGif.loadRequest(URLRequest.init(url: URL.init(string: path)!))
    
    }
    func initData()  {
        
        
        let staff:StaffEntity = UserManager.shared.getLocalStaff()!
        let params:[String:String]  = ["hLat":staff.lat!,"hLng":staff.lng!,"type":"1001"]
        HttpHelper.Shared.Post(path: EVENT_URL, paras: params, success: { (res) in
            let response:[String:String] = res as! [String:String]
            if (response["result"] == "Yes"){
                let story:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
               //有事件进入列表
                self.navigationController?.pushViewController(story.instantiateViewController(withIdentifier: "EventViewController"), animated: true)
            
            }
            
            
        }) { (error) in
            self.view.makeToast("error data")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
