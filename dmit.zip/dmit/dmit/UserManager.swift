//
//  UserManager.swift
//  dmit
//
//  Created by fpm0259 on 2018/7/27.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit
import CoreData
class UserManager: NSObject {
    
    let delegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var context:NSManagedObjectContext!
    
    
    static let shared = UserManager.init()
    
    private override init() {
        super.init()
        context = delegate.persistentContainer.viewContext
    }
    
    func getLocalUser() -> UserEntity? {
        let request:NSFetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "UserEntity")
        var array:Array<UserEntity> = []
        
        do {
            let results = try self.context.fetch(request)
            array = results as! [UserEntity]
           
        } catch  {
            print("查询错误...")
        }
        if (array.count > 0 )
        {
             return array[0]
        }
       
       return nil
    }
   
    
    func addLocalUser(_ dic:Dictionary<String, Any>) {
        let user:UserEntity = NSEntityDescription.insertNewObject(forEntityName: "UserEntity", into: self.context) as! UserEntity
       
        user.userId = String.init(format: "%@", dic["id"] as! String)
        
        user.username = String.init(format: "%@", dic["username"] as! String)
          user.firstname = String.init(format: "%@", dic["firstname"] as! String)
        user.history = String.init(format: "%@", dic["medical_history"] as! String)
      
        user.gender = String.init(format: "%@", dic["gender"] as! String)
        user.age = String.init(format: "%@", dic["age"] as! String)
         user.password = String.init(format: "%@", dic["password"] as! String)
        
       self.delegate.saveContext()
        
    }
    
    func deleteLocalUser() {
        let user:UserEntity? = self.getLocalUser()
        if let localUser = user {
          self.context.delete(localUser)
            self.delegate.saveContext()
        }
        
    }
    
    func updateLocalUser() {
        self.delegate.saveContext()
    }
    
    
    func getLocalStaff() -> StaffEntity? {
        let request:NSFetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "StaffEntity")
        var array:Array<StaffEntity> = []
        
        do {
            let results = try self.context.fetch(request)
            array = results as! [StaffEntity]
            
        } catch  {
            print("查询错误...")
        }
        if (array.count > 0 )
        {
            return array[0]
        }
        
        return nil
    }
    
    
    func addLocalStaff(_ dic:Dictionary<String, Any>) {
        let staff:StaffEntity = NSEntityDescription.insertNewObject(forEntityName: "StaffEntity", into: self.context) as! StaffEntity
        staff.id = String.init(format: "%@", dic["id"] as! String)
        
        staff.staffusername = String.init(format: "%@", dic["username"] as! String)
        staff.password = String.init(format: "%@", dic["password"] as! String)
        
        
        staff.lat = String.init(format: "%@", dic["lat"] as! String)
        staff.lng = String.init(format: "%@", dic["lng"] as! String)
        staff.hospitalName = String.init(format: "%@", dic["hospitalName"] as! String)
       
        
        self.delegate.saveContext()
        
    }
    
}
