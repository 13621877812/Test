//
//  StaffViewController.swift
//  dmit
//
//  Created by fpm0259 on 2018/7/27.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class StaffViewController: UIViewController {

    @IBOutlet weak var nameLab: UILabel!
    @IBOutlet weak var latitudeLab: UILabel!
    @IBOutlet weak var lngLab: UILabel!
    @IBOutlet weak var historyLab: UILabel!
    @IBOutlet weak var genderLab: UILabel!
    @IBOutlet weak var ageLab: UILabel!
    @IBOutlet weak var startTimeLab: UILabel!
    @IBOutlet weak var noMessageLab: UILabel!
    @IBOutlet weak var noMessageImage: UIImageView!
    var eventId:String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.noMessageImage.alpha = 1
        self.noMessageLab.text = "no event now"
        
        self.initData()
        Timer.scheduledTimer(withTimeInterval: 10, repeats: true) { (timer) in
            self.initData()
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func initData()  {
     
        
        let staff:StaffEntity = UserManager.shared.getLocalStaff()!
        let params:[String:String]  = ["hLat":staff.lat!,"hLng":staff.lng!,"type":"1001"]
        HttpHelper.Shared.Post(path: EVENT_URL, paras: params, success: { (res) in
            let response:[String:String] = res as! [String:String]
            if (response["result"] == "Yes"){
                //hide
                self.noMessageLab.alpha = 0
                self.noMessageImage.alpha = 0
                
                //show
                self.nameLab.text = response["firstname"]
                self.latitudeLab.text = response["lat"]
                self.lngLab.text = response["lng"]
                self.historyLab.text = response["medical_histor"]
                self.genderLab.text = response["gender"]
                self.ageLab.text = response["age"]
                self.startTimeLab.text = response["startTime"]
                
                self.eventId = response["id"]
                
            }else
            {
                //show
                self.noMessageLab.alpha = 1
                self.noMessageImage.alpha = 1
                self.noMessageLab.text = "no event now"
               
            }
            
            
        }) { (error) in
            self.view.makeToast("error data")
        }
    }
    @IBAction func acceptBtnClick(_ sender: Any) {
        let params:[String:String] = ["id":self.eventId!]
        
        HttpHelper.Shared.Post(path: ACCEPT_EVENT_URL, paras: params, success: { (res) in
            let response:[String:String] = res as! [String:String]
            if (response["status"] == "OK"){
                self.view.makeToast("event updated return display no event now")
            }else
            {
                self.view.makeToast("error data")
            }
            
        }) { (error) in
            self.view.makeToast("error data")
        }
        
        
    }
    @IBAction func cancelBtnClick(_ sender: Any) {
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
