//
//  TextFieldView.swift
//  dmit
//
//  Created by fpm0259 on 2018/7/27.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class TextFieldView: UITextField {
    var leftImg:UIImageView?
    var leftLab:UILabel?
    override init(frame: CGRect) {
        super.init(frame: frame)
        initUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
 
    func initUI() {
        self.textColor = UIColor.white
        self.borderStyle = .none
        let leftView:UIView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 50, height: self.frame.size.height))
        self.leftView = leftView
        self.leftViewMode = .always
        
        
        let leftImg:UIImageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 32, height: 32))
        leftImg.center = CGPoint.init(x: leftView.frame.size.width/2.0, y: leftView.frame.size.height/2.0)
       leftView.addSubview(leftImg)
        
        
        let bottomLine:UIView = UIView.init(frame: CGRect.init(x: 0, y: self.frame.size.height-0.5, width: self.frame.size.width, height: 0.5))
        bottomLine.backgroundColor = UIColor.white
        self.addSubview(bottomLine)
        
        
    }
  
    
    
    

}
