//
//  HttpHelper.swift
//  dmit
//
//  Created by sun on 2018/7/28.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

//
//  HttpHelper.swift
//  NavigateDemo
//
//  Created by yixin ran on 07/08/2017.
//  Copyright © 2017 yixin ran. All rights reserved.
//
import UIKit

public class HttpHelper{
    //单例
    public static var Shared=HttpHelper();
    // MARK:- get请求
    func Get(path: String,success: @escaping ((_ result: String) -> ()),failure: @escaping ((_ error: Error) -> ())) {
        
        let url = URL(string: path.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!)
        
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: url!) { (data, respond, error) in
            
            if let data = data {
                
                if let result = String(data:data,encoding:.utf8){
                    
                    success(result)
                }
            }else {
                
                failure(error!)
            }
        }
        dataTask.resume()
    }
    
    
    // MARK:- post请求
    func Post(path: String,paras: [String : Any],success: @escaping ((_ result: Any) -> ()),failure: @escaping ((_ error: Error) -> ())) {
        
        let url = URL(string: path)
        var request = URLRequest.init(url: url!)
        request.httpMethod = "POST"

        
        
        var data:Data!
        do {
          data =
                try JSONSerialization.data(withJSONObject: paras, options: .prettyPrinted)
         
            
        } catch  {}
      
        
        request.httpBody = data

        let session = URLSession.shared
        let dataTask = session.dataTask(with: request) { (data, respond, error) in

            if let data = data {
              
                var responseDic:Any?
                
                do{
                    try
                   responseDic =  JSONSerialization.jsonObject(with: data, options: .mutableContainers)
                }catch{}
                
               
              
                if let result = responseDic{

                    DispatchQueue.main.async {
                        success(result)
                    }
                    
                }else
                {
                    if let result = String(data:data,encoding:.utf8){
                        
                        DispatchQueue.main.async {
                            success(result)
                        }
                    }
                    
                }

            }else {
                DispatchQueue.main.async {
                    failure(error!)
                }
                
            }
        }
        dataTask.resume()
    }
}
class JsonHelper {
    static let Shared=JsonHelper();
    private let decoder=JSONDecoder();
    private let encoder=JSONEncoder();
    func ToJson<T:Codable>(_ obj:T) -> String {
        let data=try! self.encoder.encode(obj)
        let str=String(data:data,encoding:.utf8)!
        return str
    }
    func ToObject<T:Codable>(_ data:String) -> T{
        let obj=try! self.decoder.decode(T.self, from: data.data(using: .utf8)!)
        return obj;
    }
    func GetData(_ str:String) -> Data {
        return str.data(using: .utf8)!
    }
    func GetJson(_ data:Data) -> String {
        return String(data:data,encoding:.utf8)!
    }
}
