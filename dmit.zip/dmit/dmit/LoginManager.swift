//
//  LoginManager.swift
//  dmit
//
//  Created by fpm0259 on 2018/7/27.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class LoginManager: NSObject {
   class func switchRootViewController() -> UIViewController {
    let story:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
    let staff:StaffEntity? = UserManager.shared.getLocalStaff()
    if staff != nil {
        //不判断内容，存入的时候已经判断
        //优先进入用户
        return  NavViewController.init(rootViewController: story.instantiateViewController(withIdentifier: "StaffViewController"))
            
        
    }
    let user:UserEntity? = UserManager.shared.getLocalUser()
    
     if user != nil {
        //进入user主界面
        
        
        return   NavViewController.init(rootViewController: story.instantiateViewController(withIdentifier: "MainViewController"))
     }else
     {
        
        
        return NavViewController.init(rootViewController:story.instantiateViewController(withIdentifier: "LoginViewController") )
     }
    
    }
}
