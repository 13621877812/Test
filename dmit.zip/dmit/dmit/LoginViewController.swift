//
//  LoginViewController.swift
//  dmit
//
//  Created by fpm0259 on 2018/7/27.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
         initUI()
        // Do any additional setup after loading the view.
    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func initUI()  {
        //改变placehold颜色
       self.userNameTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
       self.passwordTextField.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
       self.passwordTextField.isSecureTextEntry = true
        
        //添加输入框leftView
        let userNmaeLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let userNmaeLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        userNmaeLeftImg.center = CGPoint(x: 25, y: 20)
        userNmaeLeftImg.image = UIImage.init(named: "user")
        userNmaeLeftView.addSubview(userNmaeLeftImg)
        self.userNameTextField.leftView = userNmaeLeftView
        self.userNameTextField.leftViewMode = .always
        
        let passwordLeftView:UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        let passwordLeftImg:UIImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        passwordLeftImg.center = CGPoint(x: 25, y: 20)
        passwordLeftImg.image = UIImage.init(named: "password")
        passwordLeftView.addSubview(passwordLeftImg)
        self.passwordTextField.leftView = passwordLeftView
        self.passwordTextField.leftViewMode = .always
        
        
        
        
        
        
        
        
    }

    @IBAction func login(_ sender: Any) {
        if (self.userNameTextField.text?.isEmpty)! {
            return
        }
        if (self.passwordTextField.text?.isEmpty)! {
            return
        }
        let params:[String : Any] = ["type":"1002","username":self.userNameTextField.text,"password":self.passwordTextField.text] as [String : Any]
        
        HttpHelper.Shared.Post(path: USER_LOGIN_URL, paras: params, success: { (response) in
            
       
            UserManager.shared.addLocalUser(response as! Dictionary<String, Any>)
            
            UIApplication.shared.keyWindow?.rootViewController = LoginManager.switchRootViewController()
            
        }) { (error) in
            print(error.localizedDescription)
        }
        
        
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
