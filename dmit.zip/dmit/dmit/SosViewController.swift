//
//  SosViewController.swift
//  dmit
//
//  Created by fpm0259 on 2018/7/27.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit
import WebKit
class SosViewController: UIViewController {

    @IBOutlet weak var gifWebView: WKWebView!
    
    @IBOutlet weak var messageLab: UILabel!
    
    @IBOutlet weak var stateLab: UILabel!
    var locationState:Bool = false
    var user:UserEntity?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        user = UserManager.shared.getLocalUser()
        LocationManager.shared
        self.location()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func cancelBtnClick(_ sender: Any) {
        
    }
    func location() {
        LocationManager.getMoLocationWithSuccess({ (lat, lng) -> (Void) in
            if (!self.locationState){
                self.locationState = true
                self.startEvent(lat, lng: lng)
                LocationManager.stop()
            }
        }) { (error) -> (Void) in
           self.location()
        }
    }
    func startEvent(_ lat:Double,lng:Double) {
        let params:[String:String] = ["type":"1001","patientId":self.user!.userId!,"patientName":self.user!.firstname!,"gender":self.user!.gender!,"age":self.user!.age!,"medicalHistory":self.user!.history!,"lat":String.init(format: "%f", lat),"lng":String.init(format: "%f", lng)];
        HttpHelper.Shared.Post(path: START_EVENT_URL, paras: params, success: { (res) in
            let response:[String:String] = res as![String:String]
            if (response["status"] == "OK"){
                var time:Int = 10
                Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: { (timer) in
                   time = time - 1
                    self.messageLab.text = String.init(format: "cancel seconds remaining: %ds", time)
                    if (time == 0){
                        DispatchQueue.main.async {
                           self.view.makeToast("SOS send successfully!")
                            self.dismiss(animated: false, completion: {
                                
                            })
                        }
                    }
                })
                
            
                
                
            }
            
            
            
            
            
        }) { (error) in
            self.view.makeToast("SOS failed please try again!")
        }
        
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
