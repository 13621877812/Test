//
//  ViewController.m
//  Run
//
//  Created by fpm0259 on 2018/9/10.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "ViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import "PointModel.h"
@interface ViewController ()<UIWebViewDelegate>

@property (weak, nonatomic) IBOutlet UIWebView *newsWebView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.newsWebView.delegate = self;
//    NSString *url =@"http://toutiao.com/group/6597641058694201869/";
//    [self.newsWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
 
    
  
    UIButton *btn=[[UIButton alloc]initWithFrame:CGRectMake(20, 300, 100, 30)];
//    [btn setBackgroundImage:[UIImage imageNamed:@"btn"] forState:UIControlStateSelected];
    [btn setBackgroundImage:[UIImage imageNamed:@"border"] forState:UIControlStateNormal];
    
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
}


-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSString *js =@"var title = document.getElementsByClassName('news-banner-container')[0];title.remove();var authorName = document.getElementsByClassName('author-name')[0];authorName.innerText='Pan news';var recommendation = document.getElementsByClassName('recommendation-container')[0];recommendation.parentElement.remove();var download = document.getElementsByClassName('unfold-field-download')[0];download.remove();var content = document.getElementsByClassName('article__content')[0];content.style.height='auto';var embedded = document.getElementsByClassName('img-wrapper-embedded')[0];embedded.style.backgroundImage = \"url('')\";";
    
  
    [webView stringByEvaluatingJavaScriptFromString:js];
    JSContext *context = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    context[@"errorimg"] = ^() {
        
    };
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
