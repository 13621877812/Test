//
//  LocationViewController.m
//  Run
//
//  Created by fpm0259 on 2018/9/11.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "LocationViewController.h"
#import <MapKit/MapKit.h>
#import "BmobManger.h"
#import "PointModel.h"
#import "BottomView.h"
#import "MKAnnotationView+Extension.h"
@interface LocationViewController ()<MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UIImageView *bottomClick;
@property (nonatomic, strong) MKUserLocation *location;
@property(nonatomic,assign)NSTimeInterval nowInterval;
@property(nonatomic,copy)NSString *speed;
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong) NSMutableArray *annotations;
@property(nonatomic,strong)NSTimer *timer;
@end

@implementation LocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mapView.delegate = self;
//    self.mapView.showsUserLocation = YES;
    self.mapView.showsScale = YES;
    self.mapView.showsTraffic = YES;
    

   [self.mapView  setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
  
    _locationManager = [[CLLocationManager alloc] init];
    [_locationManager requestAlwaysAuthorization];
   

    UITapGestureRecognizer *tapG = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(bottomClick1)];
    [self.bottomClick addGestureRecognizer:tapG];
    self.bottomClick.userInteractionEnabled = YES;
    
    
    __weak LocationViewController *locationVC =  (LocationViewController *)self;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:5.0 repeats:YES block:^(NSTimer * _Nonnull timer) {
        [locationVC requestData];
    }];
    
    
    
}

-(void)requestData
{
    //先上传用户自己的数据
    [[BmobManger new]BmobUpdateUserLocation:self.location speed:self.speed statusBlock:^(bool isSuccess,BmobObject *user) {
        
        //获取所有用户的数据
        [[BmobManger new]getObjectWithObject:@"User" key:nil value:nil resultBlock:^(NSError *error, NSArray *data) {
            [self.mapView removeAnnotations:self.annotations];
            [self.annotations removeAllObjects];
            [data enumerateObjectsUsingBlock:^(BmobObject *obj, NSUInteger idx, BOOL * _Nonnull stop) {
                PointModel *model = [[PointModel alloc]init];
                model.user = obj;
                [self.annotations addObject:model];
                
                
                if (![[user objectForKey:@"account"] isEqualToString:[obj objectForKey:@"account"]]) {
                   
                    if ([[user objectForKey:@"status"] isEqualToString:@"1"])
                    {
                        NSLog(@"当前状态:免疫");
                    }else
                    {
                        NSLog(@"当前状态:正常");
                    }
                   
                  NSArray *points = [[obj objectForKey:@"point"] componentsSeparatedByString:@","];
                    CLLocation *objectL = [[CLLocation alloc]initWithLatitude:[points[0] doubleValue] longitude:[points[1] doubleValue]];
                   double distance = [objectL distanceFromLocation:self.location.location];
                    if (distance <= 15 && [[user objectForKey:@"status"] isEqualToString:@"0"]) {
                        NSString *user_jp_name = [user objectForKey:@"jp_name"];
                        NSString *other_jp_name = [obj objectForKey:@"jp_name"];
                        long length = user_jp_name.length +  other_jp_name.length;
                        if ((length == user_jp_name.length||length == other_jp_name.length) && length != 0) {
                            [user setObject:@"status" forKey:@"1"];
                            [obj setObject:@"status" forKey:@"0"];
                            [user setObject:@"jp_name" forKey:other_jp_name];
                            [obj setObject:@"jp_name" forKey:user_jp_name];
                            //更新数据库
                             [obj updateInBackground];
                             [user updateInBackground];
                        }
                        
                        
                       
                    }
               
                    
                }
       
                
            }];
            [self.mapView addAnnotations:self.annotations];
            
            
            
        }];
    
    }];
    
    
    
    
 
}

#pragma mark - MKMapViewDelegate
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    // 位置发生变化调用
    NSLog(@"lan = %f, long = %f", userLocation.coordinate.latitude, userLocation.coordinate.longitude);
    
    CLLocationCoordinate2D coordinate = userLocation.location.coordinate;
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 250, 250);
    [mapView regionThatFits:region];
    
    if (!self.location) {
        self.nowInterval = [NSDate timeIntervalSinceReferenceDate];
        self.location = userLocation;
        return;
    }
   
//计算距离
  double distance = [userLocation.location distanceFromLocation:self.location.location];
  NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
  double speed = distance/(now - self.nowInterval);
  NSString *peed = [NSString stringWithFormat:@"%ld",lround(speed)];
  self.speed = peed;
  self.location = userLocation;
  self.nowInterval = now;
  
    
}
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    static NSString *identifier = @"MKAnnotationView";
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;
    }
    
    PointModel *model =(PointModel *)annotation;
    MKAnnotationView *animationView = [mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    if (!animationView) {
        animationView = [[MKAnnotationView alloc]initWithAnnotation:model reuseIdentifier:identifier];
    }
    animationView.image = [UIImage imageNamed:@"red_l"];
    animationView.model = model;
    return animationView;
}
- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
    PointModel *model = view.model;
    [[NSUserDefaults standardUserDefaults]setObject:[model.user objectForKey:@"account"] forKey:@"other"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    BottomView *bottomV = [[BottomView alloc]initWithFrame:CGRectMake(0, SCREENHEIGHT - 200, SCREENWIDTH, 200)];
    bottomV.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:bottomV];
    
    
    
}

- (void)resetLocation:(id)sender {
    // 定位到我的位置
    [_mapView setCenterCoordinate:_mapView.userLocation.coordinate animated:YES];
}
-(NSMutableArray *)annotations
{
    if (_annotations == nil) {
        _annotations = [NSMutableArray array];
    }
    return _annotations;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
