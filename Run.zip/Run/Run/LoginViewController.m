//
//  LoginViewController.m
//  Run
//
//  Created by fpm0259 on 2018/9/10.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "LoginViewController.h"
#import "MyTextField.h"
#import "BmobManger.h"
@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet MyTextField *accountTextField;
@property (weak, nonatomic) IBOutlet MyTextField *passwordTextField;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    
    
    
}
-(void)initUI
{
 self.accountTextField.leftImage = [UIImage imageNamed:@"userIcon"];
 self.passwordTextField.leftImage = [UIImage imageNamed:@"passwordIcon"];
 self.passwordTextField.clearButtonMode = UITextFieldViewModeAlways;
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)loginClick:(id)sender {
    
    [[BmobManger new] getObjectWithObject:@"User" key:@"account" value:self.accountTextField.text resultBlock:^(NSError *error, NSArray *data) {
        if (error) {
            TOAST(@"登录失败，稍后重试!");
        }else
        {
            if (data.count == 0) {
                TOAST(@"此账号还没有注册!");
            }else
            {
                BmobObject *user = data[0];
                NSString *pass = [user objectForKey:@"password"];
                if (![pass isEqualToString:self.passwordTextField.text]) {
                      TOAST(@"密码错误!");
                }else
                {
                     TOAST(@"登录成功!");

                    [[NSUserDefaults standardUserDefaults]setObject:self.accountTextField.text forKey:@"user"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    UITabBarController *mainVC = [storyboard instantiateViewControllerWithIdentifier:@"mainVC"];
                    [UIApplication sharedApplication].keyWindow.rootViewController = mainVC;
                }
            }
        }
    }];
    
    
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
