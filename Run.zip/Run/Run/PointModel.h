//
//  PointModel.h
//  Run
//
//  Created by fpm0259 on 2018/9/12.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BmobSDK/Bmob.h>
#import <MapKit/MapKit.h>
@interface PointModel : MKPointAnnotation
@property(nonatomic,strong)BmobObject *user;
@end
