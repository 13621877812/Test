//
//  BmobManger.m
//  Run
//
//  Created by fpm0259 on 2018/9/10.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "BmobManger.h"

@implementation BmobManger

-(void)BmobAddObject:(NSString *)objectName dataDic:(NSDictionary *)dataDic statusBlock:(void(^)(bool isSuccess))statusBlock
{
    //往GameScore表添加一条playerName为小明，分数为78的数据
    BmobObject *object = [BmobObject objectWithClassName:objectName];
    [dataDic enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
         [object setObject:obj forKey:key];
    }];
  
    [object saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
        statusBlock(isSuccessful);
        if (isSuccessful) {
            NSLog(@"保存成功");
            
        }else
        {
           NSLog(@"保存失败");
        }
        //进行操作
    }];
}
-(void)getObjectWithObject:(NSString *)objectName key:(NSString *)keyName value:(NSString *)valueName resultBlock:(void(^)(NSError *error,NSArray *data))resultBlock
{
    //查找GameScore表
    BmobQuery   *bquery = [BmobQuery queryWithClassName:objectName];
    if (keyName) {
       [bquery whereKey:keyName equalTo:valueName];
    }
    [bquery findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        NSLog(@"%@",array);
   
        resultBlock(error,array);
    }];
  
}
//更新我的经纬度数据
-(void)BmobUpdateUserLocation:(MKUserLocation *)location speed:(NSString *)speed statusBlock:(void(^)(bool isSuccess,BmobObject *user))statusBlock
{
    //速度
  NSObject
    NSLog(@"你的速度%@",speed);
    NSString *direction = [self strToHeadDirection:location.heading.magneticHeading];
    
    //方向
    if (location.heading) {
       NSLog(@"你的方向：%f----%@",location.heading.magneticHeading,[self strToHeadDirection:location.heading.magneticHeading]);
        
    }
    
   
    
    
    
    
    //经纬度
    CLLocationCoordinate2D coordinate = location.location.coordinate;
    double lat = coordinate.latitude;
    double lng = coordinate.longitude;
    NSString *point = [NSString stringWithFormat:@"%f,%f",lat,lng];
    NSString *account = [[NSUserDefaults standardUserDefaults]valueForKey:@"user"];
    speed = [NSString stringWithFormat:@"%@m/s",speed];
    [self getObjectWithObject:@"User" key:@"account" value:account resultBlock:^(NSError *error, NSArray *data) {
        if (!error) {
            BmobObject *user =data[0];
            [user setObject:point forKey:@"point"];
            [user setObject:direction forKey:@"fangwei"];
            [user setObject:speed forKey:@"seed"];
            [user updateInBackground];
            statusBlock(YES,user);
        }
    }];
 
}
-(NSString *)strToHeadDirection:(double)direction
{
    if (direction > 5 && direction < 85) {
        return @"东北方";
    }else if (direction >= 85 && direction <= 95)
    {
        return @"正东方";
    }else if (direction >  95 && direction < 175)
    {
        return @"东南方";
    }else if (direction >=  175 && direction <= 185)
    {
        return @"正南方";
    }else if (direction >  185 && direction < 265)
    {
        return @"西南方";
    }else if (direction >=  265 && direction <= 275)
    {
        return @"正西方";
    }else if (direction >  275 && direction < 355)
    {
        return @"西北方";
    }else
    {
        return @"正北方";
    }
    
    
}
@end
