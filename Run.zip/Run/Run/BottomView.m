//
//  BottomView.m
//  Run
//
//  Created by fpm0259 on 2018/9/12.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "BottomView.h"
#import "BmobManger.h"
@interface BottomView()
@property(nonatomic,strong)UILabel *directionLab;
@property(nonatomic,strong)UILabel *speedLab;
@property(nonatomic,strong)NSTimer *timer;
@end

@implementation BottomView
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createUI];
        self.timer = [NSTimer scheduledTimerWithTimeInterval:10 repeats:YES block:^(NSTimer * _Nonnull timer) {
            [self requestData];
        }];
        [self.timer fire];
        
    }
    return self;
}
-(void)createUI
{
    self.directionLab = [[UILabel alloc]initWithFrame:CGRectMake(10, 10, SCREENWIDTH - 20, 60)];
    self.directionLab.textColor = [UIColor blackColor];
    self.directionLab.backgroundColor = [UIColor greenColor];
    [self addSubview:self.directionLab];
    
    self.speedLab = [[UILabel alloc]initWithFrame:CGRectMake(10, self.directionLab.frame.origin.y + self.directionLab.frame.size.height , SCREENWIDTH - 20, 60)];
    self.speedLab.textColor = [UIColor blackColor];
    self.speedLab.backgroundColor = [UIColor yellowColor];
    [self addSubview:self.speedLab];
    
}
-(void)requestData
{
    NSString *account = [[NSUserDefaults standardUserDefaults]valueForKey:@"other"];
    [[BmobManger new] getObjectWithObject:@"User" key:@"account" value:account resultBlock:^(NSError *error, NSArray *data) {
        if (error) {
            NSLog(@"请求失败");
        }
   
        if (!error) {
            
            BmobObject *other = data[0];
            //速度
            NSString *speed = [other objectForKey:@"seed"];
            //方向
            NSString *direction = [other objectForKey:@"fangwei"];
            self.speedLab.text = [NSString stringWithFormat:@"现在的速度:%@",speed];
            self.directionLab.text = [NSString stringWithFormat:@"现在的方向:%@",direction];
        }
       
        
        
    }];
    
    
    
    
    
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
