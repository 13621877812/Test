//
//  ImageManager.swift
//  OrderMenu
//
//  Created by fpm0259 on 2018/7/18.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class ImageManager: NSObject {
  
    class func saveImg(image:UIImage) {
        
   
//        var path:String = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
//        let time:TimeInterval = Date.timeIntervalBetween1970AndReferenceDate
//        let timeStr:String = String.init(format: "%ld", time)
//
//        path = path  + "/" + timeStr + ".plist"
//
//         saveImage(currentImage: image, persent: 3, path)
//
//        return path
    }
    private func saveImage(currentImage: UIImage, persent: CGFloat, path: String){
//        if let imageData = UIImageJPEGRepresentation(currentImage, persent) as NSData? {
//            let fullPath = NSHomeDirectory().appending("/Documents/").appending(imageData)
//            imageData.write(toFile: fullPath, atomically: true)
//            print("fullPath=\(fullPath)")
//        }
    }
    
}
