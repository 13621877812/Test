//
//  AddFoodViewController.swift
//  OrderMenu
//
//  Created by fpm0259 on 2018/7/18.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class AddFoodViewController: UIViewController {
   @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var priceTextField: UITextField!
    @IBOutlet weak var descriptionTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func saveBtnClick(_ sender: Any) {
        if (self.nameTextField.text?.isEmpty)! {
            return;
        }
        if (self.priceTextField.text?.isEmpty)! {
            return;
        }
        if (self.descriptionTextField.text?.isEmpty)! {
            return;
        }
        
        FoodManager.addFood(self.nameTextField.text!,price: self.priceTextField.text!,description:self.descriptionTextField.text! )
        self.navigationController?.popViewController(animated: true)

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
