//
//  AddFoodViewController.swift
//  OrderMenu
//
//  Created by fpm0259 on 2018/7/18.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class AddFoodViewController: UIViewController ,TZImagePickerControllerDelegate{
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var priceTextField: UITextField!
    @IBOutlet weak var descriptionTextField: UITextField!
    @IBOutlet weak var foodImageView: UIImageView!

    
    var food:FoodEntity?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.nameTextField.text = food?.name
        self.priceTextField.text = food?.price
        self.descriptionTextField.text = food?.description
    
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func uploadClick(_ sender: Any) {
        let imagePickerVC = TZImagePickerController.init(maxImagesCount: 1, delegate: self as TZImagePickerControllerDelegate)
        imagePickerVC?.didFinishPickingPhotosHandle = { photos,assets, isSelectOriginalPhoto   in
        self.foodImageView.image = photos?[0];
           
            
            
        }

        self.present(imagePickerVC!, animated: true) {
            
        }
        
    }
    @IBAction func saveBtnClick(_ sender: Any) {
        if (self.nameTextField.text?.isEmpty)! {
            return;
        }
        if (self.priceTextField.text?.isEmpty)! {
            return;
        }
        if (self.descriptionTextField.text?.isEmpty)! {
            return;
        }
        if (self.foodImageView.image == nil) {
            return;
        }
       
   
        
        FoodManager.addFood(self.nameTextField.text!,price: self.priceTextField.text!,description:self.descriptionTextField.text!,image:self.foodImageView.image!)
       self.navigationController?.popViewController(animated: true)

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
