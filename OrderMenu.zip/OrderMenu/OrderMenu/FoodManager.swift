//
//  FoodManager.swift
//  OrderMenu
//
//  Created by fpm0259 on 2018/7/17.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class FoodManager: NSObject {
   
    class func addFood(_ name:String,price:String,description:String,image:UIImage) {
        let time:TimeInterval = Date.timeIntervalBetween1970AndReferenceDate
        let timeID:String = "\(time)"
    
        let food:FoodEntity = FoodEntity .mr_createEntity()!
        food.id = timeID
        food.name = name
        food.price = price
        food.fooddescription = description
        food.image = UIImagePNGRepresentation(image)
    NSManagedObjectContext.mr_default().mr_saveToPersistentStoreAndWait()
        
        
    }
   class func findAllFoods() -> Array<FoodEntity> {
        // 查找数据库中的所有数据
        // 查找所有的Person并按照firstName排序
        let foods:Array<FoodEntity> = FoodEntity.mr_findAllSorted(by: "id", ascending: true)! as! Array<FoodEntity>
        return foods;
    }
    class func deleteFood(food:FoodEntity) {
  
       
        food.mr_deleteEntity()
   NSManagedObjectContext.mr_default().mr_saveToPersistentStoreAndWait()
    }
    class func updateFood(food:FoodEntity) {
   NSManagedObjectContext.mr_default().mr_saveToPersistentStoreAndWait()
    }
    
}
