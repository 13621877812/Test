//
//  FoodCell.swift
//  OrderMenu
//
//  Created by fpm0259 on 2018/7/17.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class FoodCell: UITableViewCell {

    
    @IBOutlet weak var nameLab: UILabel!
    
    var _food:FoodEntity?
    var food: FoodEntity? {
        get {
            return _food
        }
        set {
            _food = newValue
            
            nameLab.text = _food?.name
            
            
        }
    }
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
