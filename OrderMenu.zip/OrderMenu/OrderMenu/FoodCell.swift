//
//  FoodCell.swift
//  OrderMenu
//
//  Created by fpm0259 on 2018/7/17.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class FoodCell: UITableViewCell {

    
    @IBOutlet weak var nameLab: UILabel!
    @IBOutlet weak internal var foodImage: UIImageView!
    var _food:FoodEntity?
    var food: FoodEntity? {
        get {
            return _food
        }
        set {
            _food = newValue
            
            nameLab.text = _food?.name
            foodImage.image = UIImage.init(data: (_food?.image)!)
        }
    }
    
    
    var deleteBlock:((_ model:FoodEntity)->())?
    var editBlock:((_ model:FoodEntity)->())?
    
    @IBAction func editClick(_ sender: Any) {
        editBlock?(self.food!)
        
        
    }
    @IBAction func deleteClick(_ sender: Any) {
        deleteBlock?(self.food!)
    }
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
