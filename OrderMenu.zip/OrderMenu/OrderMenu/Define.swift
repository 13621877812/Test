//
//  Define.swift
//  OrderMenu
//
//  Created by fpm0259 on 2018/7/17.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import Foundation
import UIKit

let WIDTH:CGFloat = UIScreen.main.bounds.size.width
let HEIGHT:CGFloat = UIScreen.main.bounds.size.height
let COREDATA_NAME:String = "Recipes.sqlite"
