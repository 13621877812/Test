//
//  OrderCell.swift
//  OrderMenu
//
//  Created by fpm0259 on 2018/7/17.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit

class OrderCell: UITableViewCell {

    @IBOutlet weak var foodNameLab: UILabel!
    @IBOutlet weak var priceLab: UILabel!
    @IBAction func optoionBtnClick(_ sender: Any) {
    }
    @IBAction func deleteBtnClick(_ sender: Any) {
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
