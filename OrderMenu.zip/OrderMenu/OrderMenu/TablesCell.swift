//
//  TablesCell.swift
//  OrderMenu
//
//  Created by fpm0259 on 2018/7/17.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit
typealias funcBlock = (_ name:String) -> ()
class TablesCell: UITableViewCell {
    
    @IBOutlet weak var tableName: UILabel!
    @IBOutlet weak var tableStatus: UILabel!
    @IBOutlet weak var orderBtn: UIButton!
    var btnBlock:funcBlock?
    

    
    
    var _name:String?
    var name:String?{
        set{
           _name = newValue
        }
        get{
           
            return _name
        }
    }
    
    
    @IBAction func orderClick(_ sender: Any) {
        btnBlock?(name!)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
