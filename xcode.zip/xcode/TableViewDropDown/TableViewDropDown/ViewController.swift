//
//  ViewController.swift
//  TableViewDropDown
//
//  Created by YAU YAT LONG on 21/9/2018.
//  Copyright © 2018年 YAU YAT LONG. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, ExpandableHeaderViewDelegate {
   
    @IBOutlet weak var tableView: UITableView!
    
    var sections = [
        Section(genre: "1. Introduction and basic concept",
                movies: ["Constituent of concrete", "Advantages of concrete"],
                expanded: false),
        Section(genre: "2. Cement",
                movies: ["Manufacture of Portland cement", "Chemical composition of cement", "Hydration", "Heat of hydration and strength","Test on cement","Types of Portland Cement"],
                expanded: false),
        Section(genre: "3. Aggregate",
                movies: ["General classification of aggregate", "Mechanical properties of aggregate", "Physical properties of aggregate","Size and Grading of Aggregates"],
                expanded: false),
        Section(genre: "4. Fresh Concrete",
                movies: ["Workability", "Factors affecting workability", "Measurement of workability","Problems in fresh concrete","Mixing","Placing","Compaction"],
                expanded: false),
        Section(genre: "5. Harden Concrete",
                movies: ["Strength development", "Factors affecting strength", "Tensile strength", "Bond strength"],
                expanded: false),
        Section(genre: "6. Test for harden concrete",
                movies: ["Cube test", "Equivalent cube test", "Cylinder test", "Tensile strength test","Flexural strength test","Bond strength test","Rebound hammer test","Penetration resistance test","Pull-out test","Ultra sonic pulse velocity test","Core test"],
                expanded: false),
        Section(genre: "7. Admixtures",
                movies: ["Definition", "Accelerators", "Set-retarders", "Water-reducers and superplasticizers","Water-repellents","Minieral admixtures"],
                expanded: false),
        Section(genre: "8. Durability of concrete",
                movies: ["Permeability", "Sulfate attack", "Attack by sea water", "Acid attack","Alkali-aggregate reaction","Corrosion of reinforcement"],
                expanded: false),
        Section(genre: "9. Special concrete",
                movies: ["High performance concrete", "Fiber reinforced concrete", "Polymer-concrete compoites", "Roller compacted concrete","Ferrocement","Self-consolidating concrete"],
                expanded: false),
        Section(genre: "10. Concrete Mix Design",
        movies: ["Signcificance and objectives", "Design perameters", "Design method"],
        expanded: false)
        
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].movies.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (sections[indexPath.section].expanded) {
            return 44
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 2
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = ExpandableHeaderView()
        header.customInit(title: sections[section].genre, section: section, delegate: self)
        return header
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "labelCell")!
        cell.textLabel?.text = sections[indexPath.section].movies[indexPath.row]
        return cell
}
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let rows:Array<String> = ["a","b","c","d","e","f","g","h","i","j","k"]
        let path:String = String.init(format: "%d%@",indexPath.section + 1, rows[indexPath.row])
        let title:String = sections[indexPath.section].movies[indexPath.row];
        let detailVC:DetailViewController = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailVC.path = path
        detailVC.title = title;
        self.navigationController?.pushViewController(detailVC, animated: true)
        
        
    }
    func toggleSection(header: ExpandableHeaderView, section: Int) {
        sections[section].expanded = !sections[section].expanded
        
        
        tableView.beginUpdates()
        for i in 0 ..< sections[section].movies.count {
            tableView.reloadRows(at: [IndexPath(row: i, section: section)], with: .automatic)
        }
        tableView.endUpdates()
}
}
