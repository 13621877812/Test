//
//  DetailViewController.swift
//  TableViewDropDown
//
//  Created by YAU YAT LONG on 9/10/2018.
//  Copyright © 2018年 YAU YAT LONG. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {


    @IBOutlet weak var detailWebView: UIWebView!
    var path:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        print(self.path)
        let path:String = Bundle.main.path(forResource: self.path, ofType: "html") ?? ""
        self.detailWebView.loadRequest(URLRequest.init(url: URL.init(fileURLWithPath: path)))
        self.detailWebView.scalesPageToFit = true
        self.detailWebView.scrollView.bounces = false
        
        
//        self.detailImg.image = UIImage.init(named: self.path)
       
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
