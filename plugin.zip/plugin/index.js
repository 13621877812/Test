setTimeout(function(){
	var total = document.getElementsByClassName('rate-summary')[0];
	var haoping = total.getElementsByTagName('strong')[0];
	haoping.onclick = function(){
      updategrade();
     }
	
	//修改table
	var table =  document.getElementsByClassName('tb-rate-table align-c thm-plain')[0];
	var tr1 = table.getElementsByTagName('tr')[0];
	var tr4 = table.getElementsByTagName('tr')[3];
	
	var tds1 = tr1.getElementsByTagName('td');
	for (var i=1;i<5;i++) {
		var td11 = tds1[i];
		td11.onclick = function(){
			var td21 = tr2.getElementsByTagName('td')[i];
			var name=prompt("Please enter your name","");
			 if (name!=null && name!=""){
			 	var num = parseInt(name);
			 	var oNum = parseInt(td11.innerText);
			 	var cha = oNum - num;
			 	td11.innerText = num;
			 	td21.innerText = num;
			 	var td15 = tr1.getElementsByTagName('td')[4];
			 	var td24 = tr2.getElementsByTagName('td')[4];
			 	td14.innerText = parseInt(td14.innerText) + cha;
			 	td24.innerText = parseInt(td24.innerText) + cha;
			 }
		}
	}
	
	

	
	
	
	
},1000);

function updategrade(){
	var name=prompt("Please enter your name","")
       if (name!=null && name!="")
        {
     	var h4 = document.getElementsByClassName('tb-rate-ico-bg ico-buyer')[0];
     	var a1 = h4.getElementsByTagName('a')[0];
      var sum = parseInt(name);
       
        var cha = sum - parseInt(a1.innerText);
         a1.innerText = name;
         var a2 = h4.getElementsByTagName('a')[1]; 
       
        var number = 0;
       if(sum>=4 && sum<=10){
    	  //一个心
    	  number = 1;
    	  //img.alicdn.com/newrank/b_blue_1.gif
    }else if (sum>=11 && sum<=40) {
    	 //两个心
    	 number = 2;
    }else if (sum>=41 && sum<=90) {
    	 //三个心
    	 number = 3;
    }else if (sum>=91 && sum<=150) {
    	 //四个心
    	 number = 4;
    }else if (sum>=151 && sum<=250) {
    	//五个心
    	 number = 5;
    }else if (sum>=251 && sum<=500) {
    		//一个钻
    		 number = 1;
    }else if (sum>=501 && sum<=1000) {
    	//连个钻
    	 number = 2;
    	
    }else if (sum>=1001 && sum<=2000) {
    	//三个钻
    	 number = 3;
    }else if (sum>=2001 && sum<=5000) {
    		//四个钻
    		 number = 4;
    }else if (sum>=5001 && sum<=10000) {
    	//五个钻
    	 number = 5;
    }else
    {
    	 alert('数值太大，容易被怀疑');
    	 return;
    }
       alert('s5')
   
    var image ="";
   if(sum>=251){
   	image =  "<img src=\"//img.alicdn.com/newrank/b_blue_" + number + ".gif\" title=\"251－500个买家信用积分，请点击查看详情\" border=\"0\" align=\"absmiddle\" class=\"rank\" data-spm-anchor-id=\"a1z0b.3.5920761.i1.42741d90xjOXts\">"
   }else
   {
   	image =  "<img src=\"//img.alicdn.com/newrank/b_red_"  + number  + ".gif\" title=\"251－500个买家信用积分，请点击查看详情\" border=\"0\" align=\"absmiddle\" class=\"rank\" data-spm-anchor-id=\"a1z0b.3.5920761.i1.42741d90xjOXts\">"
   }
  

   a2.innerHTML = image;
  var table =  document.getElementsByClassName('tb-rate-table align-c thm-plain')[0];
  var tr1 = table.getElementsByTagName('tr')[1];
  var tr2 = table.getElementsByTagName('tr')[4];
  alert(tr1)
  
  var td14 = tr1.getElementsByTagName('td')[4];
  var td24 = tr2.getElementsByTagName('td')[4];
  
  var td15 = tr1.getElementsByTagName('td')[5];
    alert(td14)
    alert(td14.innerText)
  var td25 = tr2.getElementsByTagName('td')[5];
  alert(td15.innerText)
  td15.innerText = sum;
  td25.innerText = sum;
   
if (parseInt(td14.innerText) + cha < 0) {
	td14.innerText = td24.innerText = 0;
	var cha1 = -(parseInt(td14.innerText) + cha);
	 var td13 = tr1.getElementsByTagName('td')[3];
     var td23 = tr2.getElementsByTagName('td')[3];
     td13.innerText = parseInt(td13.innerText) - cha1;
    td23.innerText = parseInt(td23.innerText) - cha1;
     
     
}else
{
	td14.innerText = parseInt(td14.innerText) + cha;
    td24.innerText = parseInt(td24.innerText) + cha;
}
  
  
    }
}
