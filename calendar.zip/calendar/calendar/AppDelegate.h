//
//  AppDelegate.h
//  calendar
//
//  Created by fpm0259 on 2018/8/6.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

