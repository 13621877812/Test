//
//  ViewController.m
//  calendar
//
//  Created by fpm0259 on 2018/8/6.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "ViewController.h"
#import <EventKit/EventKit.h>
#import "EKEventTool.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    NSDictionary *responseObject = @{@"status":@"OK",@"0":@{@"ModuleCode":@"AB1234",@"ModuleName":@"OOAD",@"TeacherName":@"HU JIA JUN",@"Date":@"1",@"BeginTime":@"08:00:00",@"EndTime":@"10:00:00"},@"1":@{@"ModuleCode":@"CD5678",@"ModuleName":@"WDD",@"TeacherName":@"Angela Quek",@"Date":@"1",@"BeginTime":@"10:30:00",@"EndTime":@"12:00:00"},@"2":@{@"ModuleCode":@"QW6789",@"ModuleName":@"OSWSD",@"TeacherName":@"HU JIA JUN",@"Date":@"1",@"BeginTime":@"12:00:00",@"EndTime":@"14:00:00"},@"3":@{@"ModuleCode":@"TY9988",@"ModuleName":@"STAD",@"TeacherName":@"HU JIA JUN",@"Date":@"1",@"BeginTime":@"14:00:00",@"EndTime":@"16:00:00"},@"4":@{@"ModuleCode":@"CV6755",@"ModuleName":@"WAD",@"TeacherName":@"Angela Quek",@"Date":@"1",@"BeginTime":@"16:00:00",@"EndTime":@"18:00:00"},@"5":@{@"ModuleCode":@"KJ2321",@"ModuleName":@"ISS",@"TeacherName":@"Angela Quek",@"Date":@"2",@"BeginTime":@"08:00:00",@"EndTime":@"10:00:00"},@"6":@{@"ModuleCode":@"RT5624",@"ModuleName":@"CM1",@"TeacherName":@"Angela Quek",@"Date":@"2",@"BeginTime":@"12:00:00",@"EndTime":@"14:00:00"},@"7":@{@"ModuleCode":@"IO1367",@"ModuleName":@"TPSS",@"TeacherName":@"Angela Quek",@"Date":@"3",@"BeginTime":@"10:00:00",@"EndTime":@"12:00:00"},@"8":@{@"ModuleCode":@"NT2342",@"ModuleName":@"DF",@"TeacherName":@"Angela Quek",@"Date":@"3",@"BeginTime":@"16:00:00",@"EndTime":@"18:00:00"},@"9":@{@"ModuleCode":@"FJ1684",@"ModuleName":@"UXDM",@"TeacherName":@"Angela Quek",@"Date":@"4",@"BeginTime":@"08:00:00",@"EndTime":@"10:00:00"},@"10":@{@"ModuleCode":@"SK3576",@"ModuleName":@"SEP",@"TeacherName":@"Angela Quek",@"Date":@"4",@"BeginTime":@"12:00:00",@"EndTime":@"14:00:00"},@"11":@{@"ModuleCode":@"TR2352",@"ModuleName":@"CM2",@"TeacherName":@"Angela Quek",@"Date":@"4",@"BeginTime":@"16:00:00",@"EndTime":@"18:00:00"},@"12":@{@"ModuleCode":@"ER3734",@"ModuleName":@"OOP",@"TeacherName":@"Angela Quek",@"Date":@"5",@"BeginTime":@"14:00:00",@"EndTime":@"16:00:00"},@"13":@{@"ModuleCode":@"HW5242",@"ModuleName":@"NT",@"TeacherName":@"HU JIA JUN",@"Date":@"2",@"BeginTime":@"10:00:00",@"EndTime":@"12:00:00"},@"14":@{@"ModuleCode":@"FT8743",@"ModuleName":@"NS",@"TeacherName":@"HU JIA JUN",@"Date":@"2",@"BeginTime":@"16:00:00",@"EndTime":@"18:00:00"},@"15":@{@"ModuleCode":@"WE8673",@"ModuleName":@"CS2",@"TeacherName":@"HU JIA JUN",@"Date":@"3",@"BeginTime":@"08:00:00",@"EndTime":@"10:00:00"},@"16":@{@"ModuleCode":@"GH3576",@"ModuleName":@"MAD",@"TeacherName":@"HU JIA JUN",@"Date":@"3",@"BeginTime":@"12:00:00",@"EndTime":@"14:00:00"},@"17":@{@"ModuleCode":@"AQ2246",@"ModuleName":@"GAB",@"TeacherName":@"HU JIA JUN",@"Date":@"4",@"BeginTime":@"14:00:00",@"EndTime":@"16:00:00"},@"18":@{@"ModuleCode":@"WJ6944",@"ModuleName":@"DSA",@"TeacherName":@"HU JIA JUN",@"Date":@"5",@"BeginTime":@"08:00:00",@"EndTime":@"10:00:00"},@"19":@{@"ModuleCode":@"TY5257",@"ModuleName":@"HOA",@"TeacherName":@"HU JIA JUN",@"Date":@"5",@"BeginTime":@"12:00:00",@"EndTime":@"14:00:00"},@"20":@{@"ModuleCode":@"SY6476",@"ModuleName":@"AC",@"TeacherName":@"HU JIA JUN",@"Date":@"5",@"BeginTime":@"16:00:00",@"EndTime":@"18:00:00"}};
    


    
    if ([responseObject[@"status"] isEqualToString:@"OK"]) {
        //删除日历
         [[EKEventTool sharedEventTool] deleteAllCreatedEvent];
        
        //往日历插数据
        NSMutableArray *eventArray=[NSMutableArray array];
        for (int i=0; i<7; i++) {
            NSMutableArray *array = [NSMutableArray array];
            [eventArray addObject:array];
        }
        
        [[responseObject allValues] enumerateObjectsUsingBlock:^(NSDictionary *dic, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([dic isKindOfClass:[NSDictionary class]]) {
                NSInteger week =[dic[@"Date"] integerValue];
                [eventArray[week] addObject:dic];
            }
        }];
        
        
        for (int i=0; i<90; i++) {
            NSDate *date =[NSDate date];
            date = [date dateByAddingTimeInterval:24*60*60*i];
            NSLog(@"%@",date);
            NSDateFormatter *mFormatter = [[NSDateFormatter alloc] init];
            [mFormatter setDateFormat:@"yyyy/MM/dd"];
            NSString *dateStr = [mFormatter stringFromDate:date];
            
            NSArray *events =eventArray[[self getWeek:date]];
            
            [events enumerateObjectsUsingBlock:^(NSDictionary * event, NSUInteger idx, BOOL * _Nonnull stop) {
               
                
                
                NSString *startTime = [NSString stringWithFormat:@"%@ %@",dateStr,event[@"BeginTime"]];
                NSString *endTime = [NSString stringWithFormat:@"%@ %@",dateStr,event[@"EndTime"]];
                NSString *title = [NSString stringWithFormat:@"%@ %@ %@",event[@"ModuleCode"],event[@"ModuleName"],event[@"TeacherName"]];
                
                
                
                [self eventInsertCalendar:title beginTime:startTime endTime:endTime];
            }];
            
        }
        
        
        
        
        
        
        
        
    }
}

-(NSInteger)getWeek:(NSDate *)fromDate
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    
    NSInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |
    
    NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    
    comps = [calendar components:unitFlags fromDate:fromDate];
    
    
    return comps.weekday-1;
    
}
-(void)eventInsertCalendar:(NSString *)title beginTime:(NSString *)beginTime endTime:(NSString *)endTime
{
    
  
                           
    
//
//    __block NSString  *startTime = beginTime;
//    __block NSString *eventEndTime = endTime;
//    EKEventStore *eventStore = [[EKEventStore alloc] init];
//    if ([eventStore respondsToSelector:@selector(requestAccessToEntityType:completion:)]) {
//        // 这个方法在iOS6之后才有用
//        [eventStore requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                if (error) {
//                    NSLog(@"%@",error);
//                } else if (!granted) {
//                    //被用户拒绝，不允许访问日历
//                    NSLog(@"被用户拒绝，不允许访问日历");
//                } else {
//                    //事件保存到日历
//                    EKEvent *event = [EKEvent eventWithEventStore:eventStore]; //创建事件
//                    event.title = title; // 标题
//
//                    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//                    [dateFormatter setDateFormat:@"yyyy/MM/dd HH:mm:ss"];
//
//
//
//                    NSDate *start =[dateFormatter dateFromString:startTime];
//                    NSDate *end =[dateFormatter dateFromString:eventEndTime];
//
//
//                    //开始时间(必须传)
//                    event.startDate = start;
//                    //结束时间(必须传)
//                    event.endDate = end;
//                    event.allDay = YES;//全天
//
//                    //添加提醒
//                    //第一次提醒  (几分钟后)
//                    [event addAlarm:[EKAlarm alarmWithRelativeOffset:60.0 * -1.0]];
//                    //第二次提醒
//                    [event addAlarm:[EKAlarm alarmWithRelativeOffset:60.0f * -10.0f * 24]];
//
//                    [event setCalendar:[eventStore defaultCalendarForNewEvents]];
//                    NSError *err;
//                    [eventStore saveEvent:event span:EKSpanThisEvent error:&err];
//                    NSLog(@"保存成功");
//                }
//            });
//        }];
//    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
