//
//  ViewController.swift
//  Swift&JS
//
//  Created by fpm0259 on 2018/10/29.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

import UIKit
import JavaScriptCore
class ViewController: UIViewController,UIWebViewDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
      //MARK -- WebView
    //这句是找到本地html的绝对路径  名字  类型
        let path:String = Bundle.main.path(forResource: "html", ofType: "html")!;
       
        //用UIWebView 加载html页面
        
        //创建webView
        let webView:UIWebView = UIWebView.init(frame:CGRect(x: 0, y: 0, width: 414, height: 200));
        self.view.addSubview(webView);
        webView.scalesPageToFit = true;
        webView.delegate = self;
        
        
        //加载html
        webView.loadRequest(URLRequest(url: URL(fileURLWithPath: path)));
        
        
       //MARK -- MapView
        let mapView:BMKMapView = BMKMapView.init(frame: CGRect(x: 0, y: 300, width: 414, height: 200));

        self.view.addSubview(mapView);
  
    }

    func webViewDidFinishLoad(_ webView: UIWebView) {
        
        let context:JSContext = webView.value(forKeyPath: "documentView.webView.mainFrame.javaScriptContext") as! JSContext;
        let model:ImageModel = ImageModel();
        
        context.setObject(model, forKeyedSubscript: "WebViewJavascriptBridge" as NSCopying & NSObjectProtocol);
        
        webView.stringByEvaluatingJavaScript(from: "var images = document.getElementsByTagName('img');var imageNames = [];for (var i=0;i<images.length;i++) {var image = images[i];var array = image.src.split('/');var name = array[array.length - 1];imageNames.push(name);image.onclick = function(){var myPath = this.src.split('/');var  myName = myPath[myPath.length - 1];var index = imageNames.indexOf(myName); WebViewJavascriptBridge.imageClickIndex(imageNames,index);}}");
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

//定义协议SwiftJavaScriptDelegate 该协议遵守JSExport协议
@objc protocol SwiftJavaScriptDelegate:JSExport{
   //点击图片事件
    func imageClick(_ images:Array<String>,index:NSInteger);
}
@objc class ImageModel:NSObject,SwiftJavaScriptDelegate{
    func imageClick(_ images:Array<String>, index:NSInteger) {
       print("收到js的召唤%@--%d",images[0],index);
    }
}






