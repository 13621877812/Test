//
//  main.m
//  Running
//
//  Created by fpm0259 on 2018/10/26.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
