//
//  ViewController.m
//  Running
//
//  Created by fpm0259 on 2018/10/26.
//  Copyright © 2018年 fpm0259. All rights reserved.
//

#import "ViewController.h"
#import <CoreMotion/CoreMotion.h>
@interface ViewController ()
@property(nonatomic,strong)CMPedometer *pedometer;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _pedometer = [[CMPedometer alloc]init];
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *now = [NSDate date];
    NSDateComponents *components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:now];
    // 开始日期
    NSDate *startDate = [calendar dateFromComponents:components];
    // 结束日期
    NSDate *endDate = [calendar dateByAddingUnit:NSCalendarUnitDay value:1 toDate:startDate options:0];
    
    //判断记步功能
    if ([CMPedometer isStepCountingAvailable]) {
        [_pedometer queryPedometerDataFromDate:startDate toDate:endDate withHandler:^(CMPedometerData * _Nullable pedometerData, NSError * _Nullable error) {
            if (error) {
                NSLog(@">>>error====%@",error);
            }else {
                NSLog(@"步数====%@",pedometerData.numberOfSteps);
                NSLog(@"距离====%@",pedometerData.distance);
            }
        }];
    }else{
        NSLog(@"记步功能不可用");
    }
    
  
}


@end
